'use strict';

exports.user = [
  {
    "lastName": "mock lastName",
    "firstName": "mock firstName",
    "authenticated": true,
    "mail": "mock@ag2rlamondiale.fr"
  }
]

import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { FileUploadModel } from '../models/client/file-upload.model';
import { IdentiteNum, PrevalidationIdentNumResult } from '../models/client/identite-num.model';
import { Action } from '@ngrx/store';


export const CREATE_IDENTITE_NUM = '[IDENTITE]_CREATE';
export const SELECTED_PIECE_IDENTITE = '[IDENTITE]_SELECTED_PIECE_IDENTITE';
export const START_IDENTITE_NUM = '[IDENTITE]_START';
export const PREVALIDATE_PIECE_IDENTITE = '[IDENTITE]_PREVALIDATE';

export type PieceIdentite = 'PASSEPORT' | 'CIN';

export class SelectedPieceIdentiteAction implements Action {
  type = SELECTED_PIECE_IDENTITE;

  constructor(public payload: PieceIdentite) {
  }
}


export class StartIdentiteNumPayload {
  fonctionnaliteAppelante?: string;
  urlRetourOk: string;
  urlRetourCancel?: string;
}

export class StartIdentiteNumAction implements Action {
  type = START_IDENTITE_NUM;

  constructor(public payload: StartIdentiteNumPayload) {
    this.payload = payload;
  }
}

export class CreateIdentitePayload {
  doc1: FileUploadModel;
  doc2: FileUploadModel;
  cleValidation: string;
  typePieceIdentite: string;
}

export class CreateIdentiteNumAction extends ApiAction<CreateIdentitePayload> {

  constructor(body: CreateIdentitePayload) {
    super(CREATE_IDENTITE_NUM, 'backend/creationPieceIdentite', body);
    this.payload.method = 'POST';
    this.payload.requestData = body;
  }
}

export class PrevalidatePieceIdentite extends ApiAction<PrevalidationIdentNumResult> {

  constructor(body: IdentiteNum) {
    super(PREVALIDATE_PIECE_IDENTITE, 'backend/prevalidatePieceIdentite', body);
    this.payload.method = 'POST';
    this.payload.requestData = body;
  }
}


// rajouter les classes d'actions exposées pour le reducer
export type IdentiteNumActions =
  SelectedPieceIdentiteAction
  | CreateIdentiteNumAction
  | StartIdentiteNumAction
  | PrevalidatePieceIdentite;

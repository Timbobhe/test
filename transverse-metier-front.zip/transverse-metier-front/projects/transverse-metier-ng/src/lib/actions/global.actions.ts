import { GlobalState } from '../reducers/global.state';
import { Action } from '@ngrx/store';

export const CHAIN_ACTION = '[GLOBAL]_CHAIN_ACTION';
export const EXECUTE_ACTION = '[GLOBAL]_EXECUTE_ACTION';
export const RESET_STATE = '[GLOBAL]_RESET_STATE';
export const NOOP_ACTION = '[GLOBAL]_NOOP_ACTION';

export class ChainAction implements Action {
  type = CHAIN_ACTION;

  constructor(public payload: Array<Action>) {
  }
}

export function chainAction(...actions: Array<Action>) {
  return new ChainAction(actions);
}

export class ExecuteAction implements Action {
  type = EXECUTE_ACTION;

  constructor(public payload: () => any) {
  }
}

export type ResetStateValue = ((state: any) => any) | any;

export class ResetStateAction<S extends GlobalState> implements Action {
  type = RESET_STATE;

  constructor(public payload: Partial<{ [id in keyof S]: ResetStateValue }>) {
  }
}

export function executeAction(payload: () => any) {
  return new ExecuteAction(payload);
}

export const NoopAction: Action = {type: NOOP_ACTION};

export type GlobalActions = ChainAction | ExecuteAction | ResetStateAction<any>;



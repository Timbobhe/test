import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { UrlUtils } from '../shared/utils/url-utils';

export const CANCEL_DEM_SIGELEC = '[SIGELEC]_CANCEL_DEM_SIGELEC';
export const GET_DEM_SIGELEC = '[SIGELEC]_GET_DEM_SIGELEC';

export class CancelSigElecDemPayload<T = string> {
  idDemande: string;
  operationType: T;
}

export class CancelSigElecDem<T = string> extends ApiAction {
  constructor(payload: CancelSigElecDemPayload<T>) {
    super(CANCEL_DEM_SIGELEC, 'backend/sigElec', payload);
    this.payload.url = `/${payload.idDemande}`;
    this.payload.method = 'DELETE';
  }
}

export class DemandeSigElec<T = string> {
  idDemande: number;
  idExt: string;
  operationType: T;
  idContrats: string[];
  dateCreation: Date;
  idTransaction: string;
  urlPageSignature: string;
}

export class GetSigElecDemEnCours<T = string> extends ApiAction<DemandeSigElec> {
  constructor(typeDemande: T) {
    super(GET_DEM_SIGELEC, 'backend/sigElec', typeDemande);
    this.payload.url = `?operation=${typeDemande}`;
  }
}

export class PostSigelecTerminate<I = any> extends ApiAction<string, I> {
  constructor(label: string, endpoint: string, param: any) {
    super(label, endpoint, param);
    this.payload.url = `/terminate?frame=${!!UrlUtils.getSearchParam('frame')}`;
    this.payload.method = 'POST';
    this.payload.responseType = 'text';
  }
}


export type SigElecActions = GetSigElecDemEnCours | CancelSigElecDem | PostSigelecTerminate;

import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { CoordonneesClient } from '../models/client/coordonnees-client.model';

export const GET_COORDONNEES_CLIENT = '[COORDONNEES_CLIENT]_GET';
export const UPDATE_COORDONNEES_CLIENT = '[COORDONNEES_CLIENT]_UPDATE';
export const CLEARCACHE_COORDONNEES_CLIENT = '[COORDONNEES_CLIENT]_CLEARCACHE';



export class GetCoordonneesClientPayload {
  keepMdproData?: boolean;
}

export class GetCoordonneesClient extends ApiAction<CoordonneesClient> {
  constructor(payload: GetCoordonneesClientPayload = {keepMdproData: false}) {
    super(GET_COORDONNEES_CLIENT, 'backend/getCoordonneesClient', payload);
    this.payload.method = 'POST';
    this.payload.requestData = payload;
  }
}

export interface ModificationCoordonneesClient {
  result: boolean;
}

export class UpdateCoordonneesClient extends ApiAction<ModificationCoordonneesClient> {
  constructor(body: CoordonneesClient) {
    super(UPDATE_COORDONNEES_CLIENT, 'backend/updateCoordonneesClient', body);
    this.payload.method = 'PUT';
    this.payload.requestData = body;
  }
}


export class ClearCacheCoordonneesClient extends ApiAction<any> {
  constructor() {
    super(CLEARCACHE_COORDONNEES_CLIENT, 'backend/clearCacheCoordonneesClient', null);
  }
}



// rajouter les classes d'actions exposées pour le reducer
export type CoordonneesClientActions = UpdateCoordonneesClient
  | GetCoordonneesClient
  | ClearCacheCoordonneesClient
  | ApiActions;

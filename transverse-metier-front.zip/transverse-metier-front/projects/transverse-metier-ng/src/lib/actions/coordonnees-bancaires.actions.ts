import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { Action } from '@ngrx/store';
import {
  CoordonneesBancaires,
  CoordonneesBancairesResponseModel,
  ModificationCoordonneesBancairesDto
} from '../models';
import { PostSigelecTerminate } from './sig-elec.actions';

export const GET_COORDONNEES_BANCAIRES = '[COORDONNEES_BANCAIRES]_GET';
export const POST_COORDONNEES_BANCAIRES = '[COORDONNEES_BANCAIRES]_POST';
export const PUSH_COORDONNEES_BANCAIRES = '[COORDONNEES_BANCAIRES]_PUSH';
export const PUSH_MODIFICATION_COORDONNEES_BANCAIRES = '[COORDONNEES_BANCAIRES]_MODIF_PUSH';

const EndpointCoordonneesBancaires = 'backend/coordonneesBancaires';

export class GetModifierCoordonneesBancairesStart extends ApiAction<CoordonneesBancaires> {
  constructor() {
    super(GET_COORDONNEES_BANCAIRES, EndpointCoordonneesBancaires, null);
    this.payload.url = '/start';
  }
}

export class ModifierCoordonneesBancaires extends ApiAction<CoordonneesBancairesResponseModel> {
  constructor(body: PushModifierCoordonneesBancairesPayload) {
    super(POST_COORDONNEES_BANCAIRES, EndpointCoordonneesBancaires, body);
    this.payload.method = 'POST';
    this.payload.requestData = body.demandeModificationCoordonneesBancaires;
  }
}

export class TerminateModifierCoordonneesBancaires extends PostSigelecTerminate<ModificationCoordonneesBancairesDto[]> {
  constructor(body: ModificationCoordonneesBancairesDto[]) {
    super(POST_COORDONNEES_BANCAIRES, EndpointCoordonneesBancaires, body);
    this.payload.requestData = body;
  }
}

export class PushSelectedCoordonneesBancairesPayload {
  currentCoordonneesBancaires: CoordonneesBancaires;
}

export class PushSelectedCoordonneesBancaires implements Action {
  type = PUSH_COORDONNEES_BANCAIRES;

  constructor(public payload: PushSelectedCoordonneesBancairesPayload) {
  }
}

export class PushModifierCoordonneesBancairesPayload {
  demandeModificationCoordonneesBancaires: ModificationCoordonneesBancairesDto[];
}

export class PushModifierCoordonneesBancaires implements Action {
  type = PUSH_MODIFICATION_COORDONNEES_BANCAIRES;

  constructor(public payload: PushModifierCoordonneesBancairesPayload) {
  }
}


// rajouter les classes d'actions exposées pour le reducer
export type CoordonneesBancairesActions = GetModifierCoordonneesBancairesStart
  | PushSelectedCoordonneesBancaires
  | ModifierCoordonneesBancaires
  | PushModifierCoordonneesBancaires
  | TerminateModifierCoordonneesBancaires;

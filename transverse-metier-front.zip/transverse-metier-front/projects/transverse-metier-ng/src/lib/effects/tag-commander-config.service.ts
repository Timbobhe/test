import { Inject, Injectable } from '@angular/core';
import { TRACKING_CONFIG, TrackingConfig } from '../models/client/tracking.model';
import { compile, findVars, FlatVarsPath } from '../shared/utils/pathvars.utils';

@Injectable({
  providedIn: 'root'
})
export class TagCommanderConfigService {
  private readonly varsPath: FlatVarsPath[];
  private readonly categoriesPath: FlatVarsPath[];

  constructor(
    @Inject(TRACKING_CONFIG) private readonly trackingConfig: TrackingConfig) {
    this.varsPath = compile(this.trackingConfig.varsPath);
    this.categoriesPath = compile(this.trackingConfig.categoriesPath);

    console.groupCollapsed('varsPath');
    this.varsPath.forEach(e => console.log(e));
    console.groupEnd();

    console.groupCollapsed('categoriesPath');
    this.categoriesPath.forEach(e => console.log(e));
    console.groupEnd();
  }

  get appNameContext() {
    return this.trackingConfig.appNameContext;
  }

  /**
   * Retrouver les VARIABLES associées à un PATH (URL).
   * @param path
   */
  varsFromUrl(path: string) {
    return findVars(path, this.varsPath);
  }

  /**
   * Retrouver la CATEGORIE associée à un PATH (URL).
   * @param path
   */
  categoryFromUrl(path: string) {
    const vars = findVars(path, this.categoriesPath);
    const category = vars.category;
    if (category) {
      return category;
    }

    if (path.startsWith('/')) {
      return path.substring(1);
    }
    return path;
  }

}

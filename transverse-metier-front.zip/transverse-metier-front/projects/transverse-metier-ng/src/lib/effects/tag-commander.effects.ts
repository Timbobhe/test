import { EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { buildUrl } from '@ag2rlamondiale/redux-api-ng';
import { Injectable, NgZone } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TRACKING_ACTION, TrackingActionPayload } from '../actions/tracking.action';
import { ActionWithPayload } from '../actions/_index';
import { selectNavigationTracking } from '../reducers/transverse-metier.selectors';
import { NavigationState } from '../reducers/navigation.reducer';
import { TrackingState } from '../reducers/tracking.reducer';
import { GlobalState } from '../reducers/global.state';
import { TagCommanderService } from '../shared/services/tag-commander/tag-commander.service';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { EMPTY, forkJoin, Observable, of, pipe } from 'rxjs';
import { catchError, distinctUntilChanged, filter, map, mergeMap, switchMap, take, tap } from 'rxjs/operators';
import { TagCommanderConfigService } from './tag-commander-config.service';


export interface PageChangeValue {
  vars: any;
  page_path: string;
}

/**
 * Il faudrait que le page_path reprenne cette valeur ci : /retraite-supplementaire/synthese-des-comptes
 * Et pour les événements : synthese-des-comptes (pas de /)
 * Dans le dataLayer il faut également modifier le env_template = synthese-des-comptes
 */
@Injectable({
  providedIn: 'root'
})
export class TagCommanderEffect {
  sendEvent$ = pipe(
    map((action: ActionWithPayload<TrackingActionPayload>) => action.payload),
    filter(info => info.tc_action && info.by_user !== false),
    tap(info => {
        this.zone.runOutsideAngular(() =>
          selectNavigationTracking(this.store).pipe(
            take(1),
            map(s => this.handleActionTrigger(info, s.navigation.url)),
            catchError((err) => {
              console.error('handleActionTrigger error', err);
              return EMPTY;
            })
          ).subscribe()
        );
      }
    )
  );
  @Effect({dispatch: false})
  trackingAction$ = this.actions$.pipe(
    ofType(TRACKING_ACTION),
    filter(e => this.tcService.isActive),
    this.sendEvent$
  );
  private readonly tcVars: any;

  constructor(
    private readonly actions$: Actions,
    private readonly titleService: Title,
    private readonly tcService: TagCommanderService,
    private readonly envSpec: EnvSpecificService,
    private readonly store: Store<GlobalState>,
    private readonly trackingConfig: TagCommanderConfigService,
    private readonly zone: NgZone) {

    this.tcVars = this.envSpec.getConfig().tc_vars;

    if (this.tcService.isActive) {
      this.zone.runOutsideAngular(() => {

        selectNavigationTracking(this.store).pipe(
          distinctUntilChanged((prev, curr) => {
            return `${prev.navigation.navigationId}-${prev.tracking.envTemplate}` === `${curr.navigation.navigationId}-${curr.tracking.envTemplate}`;
          }),
          mergeMap(s => this.handlePageChange(s)),
        ).subscribe(
          (s) => {
            console.log(`##handlePageChange : ${s.page_path}`, s.vars);
            this.tcService.setTcVars(s.vars);
            this.tcService.sendPageView(null, s.page_path);
          },
          (err) => console.error('handlePageChange error', err));
      });
    }

  }

  /**
   * Variable spéciale +notag+ pour bypasser TagCo
   * @param s
   */
  handlePageChange(s: { tracking: TrackingState, navigation: NavigationState }): Observable<PageChangeValue> {
    const path = s.navigation.url;
    let page_path = buildUrl(this.trackingConfig.appNameContext, path);
    const vars_page = this.trackingConfig.varsFromUrl(path);
    if (vars_page.notag) {
      return;
    }

    delete vars_page['notag'];


    const vars = Object.assign({}, this.tcVars, s.tracking.info, {
      page_path,
      page_name: this.titleService.getTitle(),
      client_profil: 'particuliers'
    }, vars_page);

    if (s.tracking.envTemplate && s.tracking.envTemplate.length > 0) {
      vars['env_template'] = s.tracking.envTemplate.join('/');
      // une précision sur l’ERE, on ne précise pas la cible dans le page path puisqu’on a généralement 2 cibles
      if (vars['env_template'] === 'MDP') {
        page_path = buildUrl('/particulier', page_path);
      }
    }

    return of({page_path, vars}).pipe(
      switchMap(e => {
        let resVars = {};
        Object.entries(e.vars).forEach(([k, v]) => {
          if (k.endsWith('$') && typeof v === 'function') {
            resVars[k.substr(0, k.length - 1)] = v(this.store);
          } else {
            resVars[k] = of(v);
          }
        });
        return forkJoin({
          vars: forkJoin(resVars), page_path: of(page_path)
        });
      })
    );
  }


  handleActionTrigger(info: TrackingActionPayload, url: string) {
    console.log(`##handleActionTrigger : ${url}`, info);
    if (info && info.tc_action) {
      const category = info.tc_category || this.trackingConfig.categoryFromUrl(url);
      this.tcService.sendEvent(info.from, category, info.tc_action, info.tc_label);
    }
  }
}




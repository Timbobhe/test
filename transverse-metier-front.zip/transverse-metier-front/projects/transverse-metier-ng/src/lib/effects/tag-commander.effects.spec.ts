import { TestBed, waitForAsync } from '@angular/core/testing';

import { TagCommanderConfigService } from './tag-commander-config.service';
import { BaseTrackingInfo, TRACKING_CONFIG, TrackingConfig } from '../models/client/tracking.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '../reducers/global.state';
import { Observable, of } from 'rxjs';
import { TagCommanderEffect } from './tag-commander.effects';
import { testingModule } from '../test/testing-module';
import { delay } from 'rxjs/operators';


fdescribe('TagCommanderEffect', () => {

  let tagco: TagCommanderConfigService;
  let tagcoEffect: TagCommanderEffect;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      providers: [
        TagCommanderConfigService,
        {provide: TRACKING_CONFIG, useValue: MockEcrsTrackingConfig},
        TagCommanderEffect
      ]
    })
      .compileComponents();
    tagco = TestBed.inject(TagCommanderConfigService);
    tagcoEffect = TestBed.inject(TagCommanderEffect);
  }));


  it('handlePageChange /coordonnees-bancaires/consultation', waitForAsync(() => {
    const vars = tagcoEffect.handlePageChange({
      navigation: {
        url: '/coordonnees-bancaires/consultation',
        navigationId: 0,
        navigate: true,
        navigationEvent: 'navigated'
      },
      tracking: {
        info: new BaseTrackingInfo(),
        envTemplate: null,
        tagCommanderDispo: true
      }
    }).subscribe(e => {
      console.log('handlePageChange /coordonnees-bancaires/consultation', e);
      expect(e.vars).toEqual(jasmine.objectContaining<any>({
        client_profil: 'particuliers'
        , form_step: 'consultation'
        , nombres_contrats: 2
      }));
    });

  }));
});


/**
 * --- EVENT : pageview ----
 */
const TC_VARS = [
  {
    path: '/synthese-des-comptes',
    vars: {
      client_profil: 'particuliers'
    }
  },
  {
    path: '/accueil',
    vars: {
      form_profil: 'particuliers',
    },
    children: [
      {
        path: 'configurer-votre-espace',
        vars: {
          notag: true
        },
        children: [
          {
            path: 'beneficiaires',
            vars: {
              notag: false,
              form_step: 'beneficiaires'
            }
          },
          {
            path: 'gestion-financiere',
            vars: {
              notag: false,
              form_step: 'gestion-financiere'
            }
          },
          {
            path: 'objectifs',
            vars: {
              notag: false,
              form_step: 'objectifs'
            }
          }
        ]
      }
    ]
  },
  {
    path: '/nous-contacter',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'type-demande',
        vars: {
          notag: false,
          form_step: 'type-demande'
        }
      },
      {
        path: 'contact',
        vars: {
          notag: false,
          form_step: 'contact'
        }
      },
      {
        path: 'reclamation',
        vars: {
          notag: false,
          form_step: 'reclamation'
        }
      }
    ]
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'consultation',
        vars: {
          notag: false,
          form_step: 'consultation',
          nombres_contrats$: (store: Store<GlobalState>): Observable<number> =>
            of(2).pipe(delay(1000))
        }
      },
      {
        path: 'modification',
        vars: {
          notag: false,
          form_step: 'modification'
        }
      },
      {
        path: 'verification-donnees-personnelles',
        vars: {
          notag: false,
          form_step: 'verification'
        }
      },
    ]
  }
];


/**
 * --- EVENT : eventGA ----
 */
const TC_CATEGORY_URL = [
  {
    path: '/accueil',
    vars: {
      category: 'onboarding'
    }
  },
  {
    path: '/synthese-des-comptes',
    vars: {
      category: 'synthese'
    }
  },
  {
    path: '/modifier-objectif',
    vars: {
      category: 'modificationObjectif'
    }
  },
  {
    path: '/bulletin-affiliation',
    vars: {
      category: 'bia'
    }
  },
  {
    path: '/nous-contacter',
    vars: {
      category: 'contact'
    }
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      category: 'coordonneesBancaires'
    }
  },
  {
    path: '/clause-beneficiaire',
    vars: {
      category: 'modificationClauseBeneficiaire'
    }
  },
  {
    path: '/modification-gestion-financiere',
    vars: {
      category: 'arbitrage'
    }
  },

];

const MockEcrsTrackingConfig: TrackingConfig = {
  appNameContext: '/retraite-supplementaire',
  varsPath: TC_VARS,
  categoriesPath: TC_CATEGORY_URL
};

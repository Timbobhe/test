import { InjectionToken } from '@angular/core';

export interface FeatureMap {
  [key: string]: { libelle: string, dico: string, image: string };
}

export interface AppConfig {
  homeRoute: string;
  featureMap?: FeatureMap;
}

export const APP_CONFIG = new InjectionToken<AppConfig>('Configuration de l application');

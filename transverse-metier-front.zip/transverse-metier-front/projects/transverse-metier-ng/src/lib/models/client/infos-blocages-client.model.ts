export class InfosBlocagesClient {
  personneTotalementBloquee: boolean;
  toutLesContratsTotalementsBloques: boolean;
  fonctionnalitesBloqueesALaPersonne: Array<string>;
  fonctionnalitesBloqueesPartenaire: Array<string>;
  fonctionnalitesBloqueesContrats: Map<string, Array<string>>;

  fonctionnalitesBloqueesTousContrats: Array<string>;

  fonctionnalitesBloquees() {
    let res = [];
    if (this.fonctionnalitesBloqueesALaPersonne) {
      res = res.concat(res, this.fonctionnalitesBloqueesALaPersonne);
    }
    if (this.fonctionnalitesBloqueesPartenaire) {
      res = res.concat(this.fonctionnalitesBloqueesPartenaire);
    }
    if (this.fonctionnalitesBloqueesTousContrats) {
      res = res.concat(this.fonctionnalitesBloqueesTousContrats);
    }
    return res;
  }

  isFonctionnaliteBloqueePourContrat(nomContrat: string, codeFonctionnalite: string) {
    if (this.personneTotalementBloquee || this.toutLesContratsTotalementsBloques) {
      return true;
    }
    if (
      this.fonctionnalitesBloqueesPartenaire != null &&
      this.fonctionnalitesBloqueesPartenaire.indexOf(codeFonctionnalite) > -1
    ) {
      return true;
    }
    if (
      this.fonctionnalitesBloqueesTousContrats != null &&
      this.fonctionnalitesBloqueesTousContrats.indexOf(codeFonctionnalite) > -1
    ) {
      return true;
    }
    if (
      this.fonctionnalitesBloqueesALaPersonne != null &&
      this.fonctionnalitesBloqueesALaPersonne.indexOf(codeFonctionnalite) > -1
    ) {
      return true;
    }

    if (this.fonctionnalitesBloqueesContrats != null && nomContrat != null) {
      const codes = this.fonctionnalitesBloqueesContrats[nomContrat];
      return (codes && codes.length < 1) || (codes && codes.indexOf(codeFonctionnalite) > -1);
    }

    return false;
  }

  contratsNonBloques<T extends { nomContrat: string }>(contrats: T[], fonctionnaliteBloquee: string): T[] {
    const contratsFiltres: T[] = [];
    contrats.forEach(i => {
      if (!this.isFonctionnaliteBloqueePourContrat(i.nomContrat, fonctionnaliteBloquee)) {
        contratsFiltres.push(i);
      }
    });

    return contratsFiltres;
  }

  contratsBloques<T extends { nomContrat: string }>(contrats: T[], fonctionnaliteBloquee: string): T[] {
    const contratsFiltres: T[] = [];
    contrats.forEach(i => {
      if (this.isFonctionnaliteBloqueePourContrat(i.nomContrat, fonctionnaliteBloquee)) {
        contratsFiltres.push(i);
      }
    });

    return contratsFiltres;
  }
}

import { MiniContrat } from './contrat.model';
import { FileUploadModel } from './file-upload.model';

export class CoordonneesBancaires {
  contrat: MiniContrat;
  titulaire: string;
  bic: string;
  iban: string;
  idMessage: string;
  modificationRibPossible: boolean;
  rib?: FileUploadModel;
  modificationRibBloquee: boolean;
}

export class ModificationCoordonneesBancairesDto {
  contratSelected: MiniContrat;

  coordonneesBancairesActuelles: {
    titulaireCompte: string;
    codeBIC: string;
    codeIBAN: string;
  };
  coordonneesBancairesModifiees: {
    titulaireCompte: string;
    codeBIC: string;
    codeIBAN: string;
  };
  fichiersJoint: Array<FileUploadModel>;
}

export class CoordonneesBancairesModel {
  coordonneesBancairesMetierPrincipal: CoordonneesBancaires[];
  coordonneesBancairesAutresMetiers: CoordonneesBancaires[];
}

export interface CoordonneesBancairesResponseModel {
  state: string;
  errorTag: string;
}

export interface CoordBancairesAutorizedModification {
  cb: CoordonneesBancaires;
  modifieOption: boolean;
}

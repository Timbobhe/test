export class CoordonneesClient {
  email: string;
  telPortable: string;
}

import { CoordonneesClient } from './coordonnees-client.model';

export class DonneesIdNum extends CoordonneesClient {
  nom: string;
  prenom: string;
}

export class IdentiteNumerique {
  matchAccount: boolean;
  identiteNumeriqueExist: boolean;
  ag2r: DonneesIdNum;
  universign: DonneesIdNum;
  donnneesPersoConfirmees: boolean;
}

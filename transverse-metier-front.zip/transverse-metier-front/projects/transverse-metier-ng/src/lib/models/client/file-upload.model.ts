export class FileUploadModel {
  fileName: string = null;
  fileContent: string = null;

  constructor( name: string, flux: string) {
    this.fileName = name;
    this.fileContent = flux;
  }
}

export interface FileUploadResponseModel {
  fileName: string;
  fileContent: string;
  state: string;
  errorTag: string;
}

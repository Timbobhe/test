export class BackErrorModel {
  errorLevel = '';
  errorCode = '';
  additionnalMessages: Array<string>;
  constructor(errorLevel: string, errorCode: string, additionnalMessages: Array<string>) {
    this.errorLevel = errorLevel;
    this.errorCode = errorCode;
    this.additionnalMessages = additionnalMessages;
  }
}

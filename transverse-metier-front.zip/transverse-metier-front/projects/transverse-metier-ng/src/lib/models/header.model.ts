export class DropDownItem {
  title: string;
  shortTitle?: string;
  urlToRedirect?: string;
  selectionColor?: string;

  /**
   * Classe de l'icone
   */
  cssClassName?: string;
  functionName?: string;
  onExecute?: () => any;
}

export class ImageData {
  alt: string;
  url: string;
  urlMobile?: string;
  urlToRedirect: string;
}

export interface UserHeaderData {
  dropDown: DropDownItem[];
}

export interface HeaderTitle {
  display: boolean;
  url?: string;
  label?: string;
  iconClass?: string;
}

export interface HeaderData {
  /**
   * Logo
   */
  image?: ImageData;

  user: UserHeaderData;
  title?: HeaderTitle;
}

import { Message } from 'primeng/api';

export interface BasicMessage {
  label?: string;
  jahiaDicoEntry?: string;
  jahiaContribId?: string;
  jahiaContext?: Map<string, string>;
}

export class JahiaDicoEntry {
  dicoId: string;
  key: string;
  defaultValue?: string;
}

export class MessageModel implements Message {
  severity?: string;
  summary?: string;
  detail?: string;
  id?: any;
  key?: string;
  life?: number;
  sticky?: boolean;
  closable?: boolean;
  data?: any;

  jahiaSummary?: JahiaDicoEntry;
  jahiaDetail?: JahiaDicoEntry;
}

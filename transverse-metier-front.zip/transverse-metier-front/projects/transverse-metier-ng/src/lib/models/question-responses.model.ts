import { BasicMessage } from './message.model';


export class Reponse<T = any> implements BasicMessage {
  id?: string;
  label?: string;
  jahiaDicoEntry?: string;
  value: T;
  warningMessage?: BasicMessage;
  disabled?: boolean;
  preSelected?: boolean;
}

import { ActionTester, ApiActionPayload } from '@ag2rlamondiale/redux-api-ng';
import { ActionWithPayload, CANCEL_DEM_SIGELEC, CancelSigElecDem, RESET_STATE, ResetStateAction } from '../actions';
import { CoordonneesBancaires, CoordonneesBancairesModel, ModificationCoordonneesBancairesDto } from '../models';
import * as CoordonneesBancairesActions from '../actions/coordonnees-bancaires.actions';

export class CoordonneesBancairesState {
  data: CoordonneesBancairesModel;
  currentCoordonneesBancaires: CoordonneesBancaires;
  demandeModificationCoordonneesBancaires: ModificationCoordonneesBancairesDto[];
  isFetched = false;
  loading = false;
}

const initialState = new CoordonneesBancairesState();


export function coordonneesBancairesReducer(
  state: CoordonneesBancairesState = initialState, action: ActionWithPayload) {

  const tester = new ActionTester(action);

  if (action.type === RESET_STATE) {
    const acn = action as ResetStateAction<any>;
    if (acn.payload.coordonneesBancaires) {
      return Object.assign(new CoordonneesBancairesState(), {...acn.payload.coordonneesBancaires});
    }
  }

  if (tester.isStart(CoordonneesBancairesActions.GET_COORDONNEES_BANCAIRES)) {
    return Object.assign(new CoordonneesBancairesState(), {...state, loading: true});
  }

  if (tester.isSuccess(CoordonneesBancairesActions.GET_COORDONNEES_BANCAIRES)) {
    const result = (action.payload as ApiActionPayload<any>).data as CoordonneesBancaires;
    return Object.assign(new CoordonneesBancairesState(), {data: result, isFetched: true, loading: false});
  }

  if (tester.isError(CoordonneesBancairesActions.GET_COORDONNEES_BANCAIRES)) {
    return Object.assign(new CoordonneesBancairesState(), {...state, loading: false});
  }

  if (action.type === CoordonneesBancairesActions.PUSH_COORDONNEES_BANCAIRES) {
    const p = action.payload as CoordonneesBancairesActions.PushSelectedCoordonneesBancairesPayload;
    return Object.assign(new CoordonneesBancairesState(),
      {...state, currentCoordonneesBancaires: p.currentCoordonneesBancaires});
  }

  if (action.type === CoordonneesBancairesActions.PUSH_MODIFICATION_COORDONNEES_BANCAIRES) {
    const p = action.payload as CoordonneesBancairesActions.PushModifierCoordonneesBancairesPayload;
    return Object.assign(new CoordonneesBancairesState(),
      {...state, demandeModificationCoordonneesBancaires: p.demandeModificationCoordonneesBancaires, isFetched: true});
  }

  if (tester.isSuccess(CANCEL_DEM_SIGELEC)) {
    const operationType: string = (action as CancelSigElecDem).payload.inputParams.operationType;
    if (operationType === 'RIBA') {
      return new CoordonneesBancairesState();
    }
  }

  return state;
}

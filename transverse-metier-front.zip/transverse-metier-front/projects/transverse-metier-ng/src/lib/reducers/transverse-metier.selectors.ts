import { createSelector, select } from '@ngrx/store';
import { pipe } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MiniContrat } from '../models';
import { CoordonneesBancairesState } from './coordonnees-bancaires.reducer';
import { GlobalState } from './global.state';
import { TrackingState } from './tracking.reducer';

export const selectTracking = (state: GlobalState) => state.tracking;
export const selectRouter = (state: GlobalState) => state.router;
export const selectNavigation = (state: GlobalState) => state.navigation;
export const selectInfoClient = (state: GlobalState) => state.clientInfos;
export const selectCoordonneesClient = (state: GlobalState) => state.coordonneesClient;
export const selectIdentNumMatchAccount = (state: GlobalState) => state.identNumMatchAccount;
export const selectUiToastMessage = (state: GlobalState) => state.ui.toastMessages;
export const selectDemSigElec = (state: GlobalState) => state.sigElec;
export const selectCoordonneesBancaires = (state: GlobalState) => state.coordonneesBancaires;

export const selectNavigationTracking = pipe(
  select(
    createSelector(
      selectTracking,
      selectNavigation,
      (tracking: TrackingState, navigation) => {
        if (!tracking.info || !tracking.tagCommanderDispo || navigation.navigationEvent !== 'navigated') {
          return null;
        }
        return {tracking, navigation};
      })
  ),
  filter(x => !!x),
);



export const selectInfoClientAndCoordonneesBancaires = pipe(
  select(
    createSelector(
      selectInfoClient,
      selectCoordonneesBancaires,
      selectRouter,
      selectDemSigElec,
      (infoClient, coordonneesBancaires, router, sigElec) => {
        return {infoClient, coordonneesBancaires, router, sigElec};
      }
    )
  ),
  filter(x => !!x)
);


export const selectCurrentContratAndCoordonneesBancairesAndInfoClient = pipe(
  select(
    createSelector(
      selectInfoClient,
      selectCoordonneesBancaires,
      (infoClient, coordonneesBancaires: CoordonneesBancairesState) => {

        let currentContrat: MiniContrat = null;
        if (coordonneesBancaires.currentCoordonneesBancaires) {
          currentContrat = coordonneesBancaires.currentCoordonneesBancaires.contrat;
        }

        return {infoClient, coordonneesBancaires, currentContrat};
      }
    )
  ),
  filter(x => !!x)
);

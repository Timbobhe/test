import { RESET_STATE, ResetStateAction } from '../actions/global.actions';
import * as identNumAction from '../actions/identite-num.actions';
import { PieceIdentite, StartIdentiteNumPayload } from '../actions/identite-num.actions';

export class IdentiteNumState {
  pieceIdentite: PieceIdentite;
  contexteAppel: StartIdentiteNumPayload;
}

const initState = new IdentiteNumState();

export function identitenumReducer(state: IdentiteNumState = initState, action: identNumAction.IdentiteNumActions) {
  if (action.type === identNumAction.START_IDENTITE_NUM) {
    const p = (action as identNumAction.StartIdentiteNumAction).payload;
    return {
      ...state,
      contexteAppel: p
    };
  }
  if (action.type === identNumAction.SELECTED_PIECE_IDENTITE) {
    const p = (action as identNumAction.SelectedPieceIdentiteAction).payload;
    return {
      ...state,
      pieceIdentite: p
    };
  }

  if (action.type === RESET_STATE) {
    const acn = action as ResetStateAction<any>;
    if (acn.payload.identiteNum) {
      return Object.assign(new IdentiteNumState(), {...acn.payload.identiteNum});
    }
  }
  return state;
}

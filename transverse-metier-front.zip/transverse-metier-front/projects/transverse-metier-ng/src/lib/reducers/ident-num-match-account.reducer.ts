import { ActionTester, ApiActionPayload } from '@ag2rlamondiale/redux-api-ng';
import * as coordonneesAction from '../actions/coordonnees-client.actions';
import { RESET_STATE, ResetStateAction } from '../actions/global.actions';
import * as identNumMatchAccountActions from '../actions/ident-num-match-account.actions';
import { IdentiteNumerique } from '../models/client/identiteNumerique.model';
import { CREATE_IDENTITE_NUM } from '../actions/identite-num.actions';

export class IdentNumMatchAccountState {
  identiteNumerique: IdentiteNumerique;
  isFetched = false;
  loading = false;
  error?: Error;
}

const initialState = new IdentNumMatchAccountState();

export function identNumMatchAccountReducer(state: IdentNumMatchAccountState = initialState,
                                            action: identNumMatchAccountActions.IdentNumMatchAccountActions | coordonneesAction.CoordonneesClientActions) {
  const apiTester = new ActionTester(action);

  if (apiTester.isStart(identNumMatchAccountActions.GET_IDENT_NUM_MATCH_ACCOUNT)) {
    return Object.assign(new IdentNumMatchAccountState(), {...state, loading: true});
  }

  if (apiTester.isSuccess(identNumMatchAccountActions.GET_IDENT_NUM_MATCH_ACCOUNT)) {
    const result = (action.payload as ApiActionPayload<any>).data as IdentiteNumerique;
    return Object.assign(new IdentNumMatchAccountState(),
      {...state, identiteNumerique: result, isFetched: true, loading: false});
  }

  if (apiTester.isError(identNumMatchAccountActions.GET_IDENT_NUM_MATCH_ACCOUNT)) {
    const error = (action.payload as ApiActionPayload<any>).error;
    return Object.assign(new IdentNumMatchAccountState(), {...state, isFetched: true, loading: false, error});
  }


  if (apiTester.isSuccess(coordonneesAction.UPDATE_COORDONNEES_CLIENT) || apiTester.isSuccess(coordonneesAction.CLEARCACHE_COORDONNEES_CLIENT)) {
    return new IdentNumMatchAccountState();
  }

  if (apiTester.isSuccess(CREATE_IDENTITE_NUM)) {
    return Object.assign(new IdentNumMatchAccountState(),
      {
        ...state,
        identiteNumerique: {...state.identiteNumerique, identiteNumeriqueExist: true}
      });
  }


  if (action.type === RESET_STATE) {
    const acn = action as ResetStateAction<any>;
    if (acn.payload.identNumMatchAccount) {
      return Object.assign(new IdentNumMatchAccountState(), {...acn.payload.identNumMatchAccount});
    }
  }
  return state;
}

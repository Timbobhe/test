import { Injectable } from '@angular/core';
import { PartenaireInfo, STEPS_PARCOURS } from '../../../models/client/partenaire.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../reducers/global.state';
import { filter, takeUntil } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { UrlService } from '../../../shared/utils/url-utils';
import { selectInfoClient } from '../../../reducers/transverse-metier.selectors';

@Injectable({
  providedIn: 'root'
})
export class PartenaireIframeService {

  private _partenaireInfo: PartenaireInfo = undefined;
  private activeSubject$ = new BehaviorSubject<boolean>(null);

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly urlService: UrlService) {

    this.store.select(selectInfoClient).pipe(
      filter(x => x.isFetched && x.partenaire !== undefined),
      takeUntil(this.activeSubject$.pipe(filter(e => e !== null)))
    ).subscribe(x => {
      this.activeSubject$.next(!!x.partenaire);
      this._partenaireInfo = x.partenaire;
      console.log('PartenaireIframeService init', this.partenaireInfo);
    });
  }

  get partenaireInfo(): PartenaireInfo {
    return this._partenaireInfo;
  }

  postStep(step: STEPS_PARCOURS) {
    console.log('PartenaireIframeService postStep', step);
    if (this.urlService.isFrame && this.partenaireInfo) {
      PartenaireIframeService.postMessage(step, this.partenaireInfo.baseUrl);
    }
  }

  inactive$(): Observable<boolean> {
    return this.activeSubject$.pipe(filter(e => e === false));
  }

  private static postMessage(status: STEPS_PARCOURS, targetOrigin: string) {
    window.parent.postMessage({status}, targetOrigin);
  }
}

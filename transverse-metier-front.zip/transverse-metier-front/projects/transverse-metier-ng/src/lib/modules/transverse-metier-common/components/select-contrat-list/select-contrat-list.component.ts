import { Component, Input, OnInit, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CodeSiloType, MiniContrat } from '../../../../models';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../../reducers/global.state';
import { tap } from 'rxjs/operators';
import { SetTrackingEnvTemplate } from '../../../../actions';

@Component({
  selector: 'trm-select-contrat-list',
  templateUrl: './select-contrat-list.component.html',
  styleUrls: ['./select-contrat-list.component.scss']
})
export class SelectContratListComponent implements OnInit {

  @Input() listContratsChoix: MiniContrat[] = [];
  @Input() choixUnique = false;
  @Output() onSelectContrat = new BehaviorSubject<MiniContrat[] | MiniContrat>([]);

  selectedContrats: MiniContrat[] = [];

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit(): void {
    this.onSelectContrat.pipe(
      tap(x => {
        let payload: (CodeSiloType | string)[] = null;
        if (x) {
          payload = Array.isArray(x) ? x.map(e => e.codeSilo) : [x.codeSilo];
        }
        this.store.dispatch(new SetTrackingEnvTemplate(payload));
      })
    );
  }


  selectContrat(contrat: MiniContrat) {
    if (this.choixUnique) {
      return this.selectContratUnique(contrat);
    }
    this.selectContratMultiple(contrat);
  }

  selectContratMultiple(contrat: MiniContrat) {
    const indexIfContrat = this.selectedContrats.indexOf(contrat);
    if (indexIfContrat === -1) {
      this.selectedContrats.push(contrat);
    } else {
      this.selectedContrats = this.selectedContrats.filter(c => c !== contrat);
    }
    this.onSelectContrat.next(this.selectedContrats);
  }

  selectContratUnique(contrat: MiniContrat) {
    const prev = this.onSelectContrat.getValue();
    if (Array.isArray(prev) || prev !== contrat) {
      this.onSelectContrat.next(contrat);
      this.selectedContrats = [contrat];
    } else {
      this.onSelectContrat.next(null);
      this.selectedContrats = [];
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { ThemeType } from '../../services/theme.config';
import { ThemeService } from '../../services/theme.service';

@Component({
  selector: 'trm-theme-selector',
  templateUrl: './theme-selector.component.html',
  styleUrls: ['./theme-selector.component.scss']
})
export class ThemeSelectorComponent implements OnInit {

  constructor(private readonly themeService: ThemeService) {
  }

  ngOnInit() {
    this.selectTheme('ag2r');
  }

  get currentTheme(): ThemeType {
    return this.themeService.currentThemeType;
  }

  selectTheme(name: ThemeType, isFilialeAcaFlag: boolean = false) {
    let logo: string;
    if (name === 'ag2r') {
     logo = isFilialeAcaFlag ? 'aca' : 'ag2r';
    } else if (name === 'nie') {
      logo = 'nie';
    } else if (name === 'adding') {
      logo = 'adding';
    }
    this.themeService.changeTheme(name, logo);
  }
}

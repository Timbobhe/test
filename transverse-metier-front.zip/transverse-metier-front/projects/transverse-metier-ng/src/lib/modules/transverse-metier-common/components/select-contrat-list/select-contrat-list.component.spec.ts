import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { SelectContratListComponent } from './select-contrat-list.component';
import { By } from '@angular/platform-browser';
import { ContratComponent } from '../contrat/contrat.component';
import { testingModule } from '../../../../test/testing-module';


describe('EcrsSelectContratListComponent', () => {
  let component: SelectContratListComponent;
  let fixture: ComponentFixture<SelectContratListComponent>;
  let debugElement: DebugElement;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [SelectContratListComponent, ContratComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectContratListComponent);
    component = fixture.componentInstance;
    component.listContratsChoix = [
      {nomContrat: '1', codeSilo: 'ERE', description: 'Contrat 1', affichageType: 'NORMAL'},
      {nomContrat: '2', codeSilo: 'ERE', description: 'Contrat 2', affichageType: 'NORMAL'},
      {nomContrat: '3', codeSilo: 'ERE', description: 'Contrat 3', affichageType: 'NORMAL'},
    ];
    component.choixUnique = false;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should show 3 contrats', waitForAsync(() => {
    debugElement = fixture.debugElement;

    fixture.whenStable().then(() => {
      const elements = debugElement.queryAll(By.css('ecrs-contrat'));
      expect(elements.length).toEqual(3);
    });
  }));


  it('should select contrat 2', waitForAsync(() => {
    debugElement = fixture.debugElement;
    const contratsWrapper = debugElement.queryAll(By.css('.contrat-wrapper'));

    fixture.whenStable().then(() => {
      contratsWrapper[1].nativeElement.click();

      expect(component.onSelectContrat.getValue()).toContain(jasmine.objectContaining({
        nomContrat: '2',
        codeSilo: 'ERE',
        description: 'Contrat 2'
      }));
    });
  }));

  it('should select only contrat 3', waitForAsync(() => {
    component.choixUnique = true;
    fixture.detectChanges();
    debugElement = fixture.debugElement;
    const contratsWrapper = debugElement.queryAll(By.css('.contrat-wrapper'));

    fixture.whenStable().then(() => {
      contratsWrapper[2].nativeElement.click();

      expect(component.onSelectContrat.getValue()).toEqual(jasmine.objectContaining({
        nomContrat: '3',
      }));
    });
  }));

  it('should select contrat 2 et 3', waitForAsync(() => {
    debugElement = fixture.debugElement;
    const contratsWrapper = debugElement.queryAll(By.css('.contrat-wrapper'));

    fixture.whenStable().then(() => {
      contratsWrapper[1].nativeElement.click();
      contratsWrapper[2].nativeElement.click();

      expect(component.onSelectContrat.getValue()).toContain(jasmine.objectContaining({
        nomContrat: '2',
        codeSilo: 'ERE',
        description: 'Contrat 2'
      }));
      expect(component.onSelectContrat.getValue()).toContain(jasmine.objectContaining({
        nomContrat: '3',
        codeSilo: 'ERE',
        description: 'Contrat 3'
      }));
    });
  }));


});

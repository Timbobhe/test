import { Theming } from '../../../models';
import { baseColors } from './theme-ag2r';
import { icones } from './theme-base';


export const nieColors = {
  /* Couleurs NIE */
  violetNie: '#581D74',
  violetClairNie: '#9406c0', // #9856B4
  violetClaieNieUser: '#9856B4',
  blueNie: '#06A3BF',
  brunNie: '#000',
  violetNieText: '#411555'
};


export const NieTheme = Theming.Theme.from({
  name: 'nie',
  palette: {
    primary: {main: nieColors.violetNie, contrastText: 'white'},
    secondary: {main: nieColors.blueNie, contrastText: 'white'},
    text: {primary: nieColors.brunNie, disabled: baseColors.greyAg2r},
    link: {active: nieColors.violetNie, hover: nieColors.brunNie, visited: nieColors.brunNie},
    actionPrimary: {
      active: {main: nieColors.violetNie, contrastText: 'white', light: '#77279D'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'},
      hover: {main: nieColors.violetClairNie, contrastText: 'white'}
    },
    actionSecondary: {
      active: {main: 'white', contrastText: nieColors.brunNie, border: nieColors.brunNie},
      disabled: {main: baseColors.greyAg2r},
      hover: {main: nieColors.violetClairNie, contrastText: 'white'}
    },
    background: {default: baseColors.lightGreyAg2r, paper: 'white'},
    info1: {
      active: {main: nieColors.blueNie, contrastText: 'white'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'}
    },
    info2: {
      active: {main: nieColors.violetClairNie, contrastText: 'white'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'}
    },
    info3: {
      active: {main: nieColors.violetClairNie, contrastText: 'white'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'}
    },
    info4: {
      active: {main: nieColors.violetNie, contrastText: 'white'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'}
    },

    error: {main: baseColors.redAg2r, contrastText: 'white'},
    success: {main: '#4CE686', contrastText: nieColors.brunNie},
    warning: {main: '#e6864c', contrastText: 'white'},
    info: {main: baseColors.yellowAg2r, contrastText: nieColors.brunNie},
  },
  typography: {
    default: {
      fontFamily: 'Relative',
      fontSize: '1rem',
      fontWeight: 'normal',
      lineHeight: '1.25rem'
    },
    h1: {
      fontSize: '2.15rem',
      fontWeight: '700',
      lineHeight: '2.2rem'
    },
    h2: {
      fontSize: '1.75rem',
      lineHeight: '1.88rem'
    },
    h3: {
      fontSize: '1.5rem',
      lineHeight: '1.88rem'
    },
    h4: {
      fontSize: '1.25rem',
      lineHeight: 'normal'
    },
    h5: {
      fontSize: '1rem',
      lineHeight: '1.5rem'
    },
    subtitle1: {
      fontSize: '1.25rem',
      lineHeight: '1.375rem'
    },
    caption: {
      fontSize: '1rem',
      lineHeight: '1.5rem'
    }
  },
  variables: {
    /* styles/ag2rlm-theme-2018.scss */
    '--ag2r-primayColor': baseColors.brunAg2r,
    '--ag2r-secondaryColor': baseColors.blueAg2r,
    '--ag2r-thirdColor': baseColors.lightGreyAg2r,
    '--ag2r-fourthColor': baseColors.redAg2r,

    /* styles/jahiacontrib.scss */
    '--jahia-contrib-txt-greenColor': '#47d5cd',
    '--jahia-contrib-txt-blueColor': '#00b9e4',
    '--jahia-contrib-txt-underline_blueColor': '#9FBFFF',

    /* styles/prime-ng-custom-theme.scss */
    '--primeng-primaryColor': 'white',
    '--primeng-secondaryColor': baseColors.blueAg2r,
    '--primeng-thirdColor': baseColors.brunAg2r,
    '--primeng-fourthColor': '#333333',
    '--primeng-fifthColor': '#eaeaea',
    '--primeng-sixthColor': '#d8dae2',
    '--primeng-seventhColor': '#c6c6c6',
    '--primeng-eighthColor': '#868686',
    '--primeng-ninthColor': '#a6a6a6',
    '--primeng-tenthColor': '#d0d0d0',
    '--primeng-eleventhColor': '#b7b7b7',
    '--primeng-twelfth': baseColors.lightGreyAg2r,
    '--primeng-thirteenthColor': 'rgba(0, 0, 0, 0.16)',

    /* AutresContratComponent */
    '--autresContrat-primaryColor': 'white',
    '--autresContrat-secondaryColor': baseColors.lightGreyAg2r,

    /* BreadcrumbComponent */
    '--breadcrumb-primaryColor': baseColors.brunAg2r,

    /* BubbleComponent */
    '--bubble-primaryColor': nieColors.violetNie,
    '--bubble-secondaryColor': 'white',
    '--bubble-textColor': baseColors.brunAg2r,
    '--bubble-selectedTextColor': 'white',


    /* DetailsCompartimentComponent */
    '--detailCompartiment-principalColor': 'white',

    /* DetailContratComponent */
    '--detailContrat-primaryColor': baseColors.brunAg2r,
    '--detailContrat-secondaryColor': nieColors.violetNie,
    '--detailContrat-thirdColor': '#c9c9c9',
    '--detailContrat-fourthColor': '#a7a7a7',
    '--detailContrat-fifthColor': 'white',
    '--detailContrat-sixthColor': baseColors.lightGreyAg2r,
    '--detailContrat-hoverColor': nieColors.blueNie,

    /* DoughnutComponent */
    '--doughnut': {
      'bgColor': nieColors.blueNie,
      'textColor': nieColors.brunNie,
      'primaryColor': nieColors.blueNie,
      'secondaryColor': 'white',
      'thirdColor': nieColors.blueNie,
      'fourthColor': nieColors.violetClairNie
    },

    /* EvenementComponent */
    '--evenement-primaryColor': baseColors.blueAg2r,

    /* FormCheckboxComponent */
    '--formCheckbox-primaryColor': baseColors.blueAg2r,
    '--formCheckbox-secondaryColor': '#c6c6c6',

    /* NavMenuComponent */
    '--nav-menu-primaryColor': baseColors.brunAg2r,
    '--nav-menu-secondaryColor': 'white',
    '--nav-menu-thirdColor': baseColors.lightGreyAg2r,
    '--nav-menu-fourthColor': nieColors.violetNie,
    '--nav-menu-primaryColor-hover': nieColors.violetClairNie,
    '--nav-menu-selected-active': nieColors.violetClairNie,
    '--nav-menu-secondaryColor-hover': 'white',

    /*TrmHeaderMenu*/
    '--trm-header-menu-primaryColor': nieColors.violetNieText,
    '--trm-header-menu-user-color': nieColors.violetNie,
    '--trm-header-menu-user-color-textColor': 'white',
    '--trm-header-menu-user-contact-button-text-color': nieColors.blueNie,
    '--trm-header-menu-user-contact-button-text-color-hover': nieColors.violetNie,
    '--trm-header-menu-user-hover': nieColors.blueNie,
    '--trm-header-menu-nav-contrat-text': baseColors.superHeaderText,
    '--trm-header-menu-nav-border': baseColors.greyAg2r,
    '--trm-header-menu-nav-selected-active': nieColors.blueNie,
    '--trm-header-menu-user-acount': nieColors.violetClaieNieUser,

    /* OngletCompartiment */
    '--onglet-primaryColor': 'rgba(6, 163, 191, .90)',
    '--onglet-secondaryColor': 'white',
    '--onglet-thirdColor': nieColors.violetNie,
    '--onglet-fourthColor': nieColors.blueNie,
    '--onglet-fifthColor': baseColors.lightGreyAg2r,
    '--onglet-textColor': baseColors.brunAg2r,

    /* PostLazyLoaderComponent */
    '--postLazyLoader-primaryColor': '#f6f7f8',
    '--postLazyLoader-secondaryColor': 'white',

    /* ScrollableComponent */
    '--scrollable-primaryColor': baseColors.brunAg2r,
    '--scrollable-secondaryColor': baseColors.lightGreyAg2r,
    '--scrollable-thirdColor': '#f4f4f4',

    /* SimulateurComponent */
    '--simulateur-primaryColor': nieColors.violetNie,
    '--simulateur-secondaryColor': nieColors.blueNie,
    '--simulateur-thirdColor': '#c9c9c9',
    '--simulateur-fourthColor': 'white',
    '--simulateur-fifthColor': baseColors.brunAg2r,
    '--simulateur-textRightColor': 'white',

    /* SyntheseComponent */
    '--synthese-primaryColor': baseColors.lightGreyAg2r,
    '--synthese-secondaryColor': 'white',
    '--synthese-thirdColor': baseColors.brunAg2r,
    '--synthese-fourthColor': 'lightgrey',
    '--synthese-textErrorColor': baseColors.redAg2r,


    /* VosActionsComponent */
    '--vosAction-primaryColor': 'white',
    '--vosAction-secondaryColor': nieColors.violetNie,
    '--vosAction-thirdColor': '#cccccc',
    '--vosAction-fourthColor': baseColors.brunAg2r,

    /* EcrsObjectifComponent */
    '--objectif-primaryColor': 'white',
    '--objectif-secondaryColor': baseColors.blueAg2r,
    '--objectif-thirdColor': '#cccccc',
    '--objectif-fourthColor': baseColors.brunAg2r,

    /* OnboardingConfigComponent */
    '--onboardingConfig-primaryColor': 'white',
    '--onboardingConfig-secondaryColor': baseColors.yellowAg2r,
    '--onboardingConfig-thirdColor': '#e5e5e5',
    '--onboardingConfig-fourthColor': baseColors.blueAg2r,

    /* EcrsArticleTemplateComponent */
    '--articleTemplate-contentBackgroundColor': 'white',
    '--articleTemplate-backgroundColor': baseColors.lightGreyAg2r,
    '--articleTemplate-hashtagBackgroundColor': nieColors.violetNie,
    '--articleTemplate-hashtagTextColor': 'white',
    '--articleTemplate-dateTextColor': 'rgba(56, 26, 10, 0.7)',


    /* EcrsBadgeComponent */
    '--badge-primaryColor': 'white',
    '--badge-secondaryColor': baseColors.brunAg2r,
    '--badge-thirdColor': '#939393',
    '--badge-fourthColor': baseColors.blueAg2r,

    /* EcrsErrorMajeureComponent*/
    '--erreurMajeure-principalColor': 'white',

    /* EcrsErrorMineureComponent*/
    '--erreurMineure-principalColor': 'white',
    '--erreurMineure-secondaryColor': baseColors.redAg2r,

    /* EcrsErrorModereeComponent*/
    '--erreurModeree-principalColor': 'white',
    '--erreurModeree-secondaryColor': baseColors.redAg2r,

    /* StepperComponent */
    '--stepper-primaryColor': nieColors.violetNie,
    '--stepper-actionColor': nieColors.blueNie,
    '--stepper-secondaryColor': 'white',
    '--stepper-disabledColor': '#939393',
    '--stepper-disabledSecondaryColor': '#c9c9c9',

    /* EcrsProgressBarComponent */
    '--progressBar-primaryColor': nieColors.blueNie,

    /* SpinnerComponent */
    '--spinner-primaryColor': nieColors.blueNie,


    /* ContactReclamationComponent */
    '--contactReclamation-backgroundColor': 'white',
    '--contactReclamation-inputbackgroundColor': '#f2f2f2',
    '--contactReclamation-msgErreurColor': baseColors.redAg2r,
    '--contactReclamation-calendarbackgroundColor': '#dee2e6',
    '--contactReclamation-dateColor': 'black',
    '--contactReclamation-listeDeroulanteColor': '#848484',
    '--contactReclamation-listeDeroulanteIconColor': '#868686',
    '--contactReclamation-toastSuccesColor': '#008000',
    '--contactReclamation-selectionButtonColor': '#0000FF',

    /* CoordonneesBancairesComponent */
    '--coordonneesBancaires-primaryColor': 'white',
    '--coordonneesBancaires-secondaryColor': '#381a0a',
    '--coordonneesBancaires-thirdColor': '#0052ff',
    '--coordonneesBancaires-fourthColor': '#5e5e5e',
    '--coordonneesBancaires-fifthColor': '#c9c9c9',
    /* QAD */
    '--gestFinQad-primaryColor': '#ffffff',
    '--gestFinQad-secondaryColor': nieColors.blueNie,
    '--gestFinQad-thirdColor': '#47d5cd',
    '--gestFinQad-fifthColor': '#a6a6a6',

    /* EcrsTableauRepartFinanciereComponent */
    '--tableauRepartFin-ligneBgColor': 'white',
    '--tableauRepartFin-ligneBorderColor': '#939393',
    '--tableauRepartFin-totalBgColor': '#c9c9c9',
    '--tableauRepartFin-fieldsetBorderColor': '#c9c9c9',
    '--tableauRepartFin-actionColor': '#0052ff',
    '--tableauRepartFin-secondaryColor': baseColors.brunAg2r,
    '--tableauRepartFin-fontColor': baseColors.brunAg2r,
    '--tableauRepartFin-noneColor': '#000',
    '--tableauRepartFin-partialColor': '#000',
    '--tableauRepartFin-completeColor': '#000',
    '--tableauRepartFin-selectionBgColor': nieColors.blueNie,
    '--tableauRepartFin-selectionColor': 'white'
    ,
    /* EcrsRepartitionFinanciereContratComponent */
    '--repartFinanciere-tagBackgroundColor': '#fff',
    '--repartFinanciere-tagBorderColor': nieColors.blueNie,
    '--repartFinanciere-iconDownloadColor': nieColors.violetNie,
    '--repartFinanciere-tagFontColor': baseColors.brunAg2r,

    '--typeSujet': {
      COMPRENDRE: {couleur: nieColors.blueNie, contrastText: 'white', icone: icones.idea},
      ESTIMER: {couleur: nieColors.blueNie, contrastText: 'white', icone: icones.additionalPension},
      AMELIORER: {couleur: nieColors.violetClairNie, contrastText: 'white', icone: icones.trackProgress},
      DEFISCALISER: {
        couleur: nieColors.violetClairNie,
        contrastText: 'white',
        icone: icones.speedWeighBoost
      },
      DECOUVRIR: {couleur: nieColors.violetClairNie, contrastText: 'white', icone: icones.multiscreens},
      BIA: {couleur: nieColors.blueNie, contrastText: 'white', icone: icones.multiscreens},
      VERIFICATIONIDENTITE: {
        couleur: nieColors.blueNie,
        contrastText: 'white',
        icone: icones.multiscreens
      },

      default: {couleur: nieColors.blueNie, contrastText: 'white', icone: icones.multiscreens}
    },

    /* Parcours manuscrit Confirmation */
    '--manuscrit-confirmation-picto': {
      verifier: {bgcolor: nieColors.violetClairNie, color: '#381a0a'},
      imprimer: {bgcolor: nieColors.violetClairNie, color: '#381a0a'},
      envoyer: {bgcolor: nieColors.violetClairNie, color: '#381a0a'},
    }
  }
});

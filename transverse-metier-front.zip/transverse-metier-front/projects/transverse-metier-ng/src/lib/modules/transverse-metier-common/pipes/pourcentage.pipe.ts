import { Pipe, PipeTransform } from '@angular/core';
import { PercentPipe } from '@angular/common';

@Pipe({
  name: 'pourcentage'
})
export class PourcentagePipe implements PipeTransform {


  constructor(private readonly percentPipe: PercentPipe) {
  }

  transform(value: any, digitsInfo: string = '.2', locale: string = 'fr'): string | null {
    const res = this.percentPipe.transform(value, digitsInfo, locale);
    if (res.match(/(\d+)[.|,]00(.*)/)) {
      return res.replace(/(\d+)[.|,]00(.*)/, '$1$2');
    }
    return res;
  }

}

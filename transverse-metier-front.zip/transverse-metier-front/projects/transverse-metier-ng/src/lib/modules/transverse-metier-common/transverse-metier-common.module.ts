import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { SharedModule } from '../../shared/shared.module';
import { ContratComponent } from './components/contrat/contrat.component';
import { HeaderMenuContainerComponent } from './components/header-menu/header-menu-container/header-menu-container.component';
import { HeaderMenuPopupComponent } from './components/header-menu/header-menu-popup/header-menu-popup.component';
import { HeaderMenuDropdownComponent } from './components/header-menu/header-menu-user/header-menu-dropdown/header-menu-dropdown.component';
import { HeaderMenuUserComponent } from './components/header-menu/header-menu-user/header-menu-user.component';
import { HeaderMenuComponent } from './components/header-menu/header-menu.component';
import { HeaderNavMenuComponent } from './components/header-menu/header-nav-menu/header-nav-menu.component';
import { LayoutFunctionalityComponent } from './components/layout-functionality/layout-functionality.component';
import { LayoutPopInMenuComponent } from './components/layout-pop-in-menu/layout-pop-in-menu.component';
import { LayoutPopInComponent } from './components/layout-pop-in/layout-pop-in.component';
import { TrmMenubar, TrmMenubarSub } from './components/menu/menu.component';
import { TrmPanelMenu, TrmPanelMenuSub } from './components/panelmenu/panelmenu.component';
import { ContainerCardWithPictoComponent } from './components/picto-card/container-card-with-picto.component';
import { SelectContratListComponent } from './components/select-contrat-list/select-contrat-list.component';
import { LargeTitleParagComponent } from './components/large-title-parag/large-title-parag.component';
import { LayoutSyntheseComponent } from './components/layout-synthese/layout-synthese.component';
import { SigElecRedirectionComponent } from './components/sigelec-redirection/sigelec-redirection.component';
import { DemsigelecRepriseComponent } from './components/sigelec-reprise/demsigelec.component';
import { ThemeSelectorComponent } from './components/theme-selector/theme-selector.component';
import { InViewDirective } from './directives/in-view.directive';
import { PourcentagePipe } from './pipes/pourcentage.pipe';
import { SafeHtmlPipe } from './pipes/safeHtml.pipe';
import { SafeResourceUrlPipe } from './pipes/safeResourceUrl.pipe';

@NgModule({
  imports: [
    CommonModule,
    DialogModule,
    ButtonModule,
    JahiaNgModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [
    LargeTitleParagComponent,
    SigElecRedirectionComponent,
    LayoutFunctionalityComponent,
    DemsigelecRepriseComponent,
    PourcentagePipe,
    SafeHtmlPipe,
    SafeResourceUrlPipe,
    ContratComponent,
    SelectContratListComponent,
    ThemeSelectorComponent,
    LayoutSyntheseComponent,
    LayoutPopInComponent,
    InViewDirective,
    HeaderMenuComponent,
    HeaderMenuUserComponent,
    HeaderMenuPopupComponent,
    HeaderMenuContainerComponent,
    HeaderNavMenuComponent,
    HeaderMenuDropdownComponent,
    LayoutPopInMenuComponent,
    TrmMenubar,
    TrmMenubarSub,
    TrmPanelMenu,
    TrmPanelMenuSub,
    ContainerCardWithPictoComponent
  ],
  exports: [
    LargeTitleParagComponent,
    SigElecRedirectionComponent,
    LayoutFunctionalityComponent,
    DemsigelecRepriseComponent,
    PourcentagePipe,
    SafeHtmlPipe,
    SafeResourceUrlPipe,
    ContratComponent,
    SelectContratListComponent,
    ThemeSelectorComponent,
    LayoutSyntheseComponent,
    LayoutPopInComponent,
    InViewDirective,
    HeaderMenuComponent,
    HeaderMenuUserComponent,
    HeaderMenuPopupComponent,
    HeaderMenuContainerComponent,
    HeaderNavMenuComponent,
    HeaderMenuDropdownComponent,
    LayoutPopInMenuComponent,
    TrmMenubar,
    TrmPanelMenu,
    ContainerCardWithPictoComponent
  ],
  providers: [
    {
      provide: PourcentagePipe,
      useClass: PourcentagePipe,
    },
  ],
})
export class TransverseMetierCommonModule {
}

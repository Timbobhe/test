export const icones = {
  idea: 'ag2r-036-idea',
  additionalPension: 'ag2r-124-additional-pension',
  trackProgress: 'ag2r-147-track-progress',
  speedWeighBoost: 'ag2r-041-speed-weigh-boost',
  multiscreens: 'ag2r-037-multiscreens',
};

import { async, TestBed } from '@angular/core/testing';

import { TRACE_FRONT_CONFIG, TraceFrontService } from './trace-front.service';
import { testingModule } from '../../../test/testing-module';
import { ApiCallerService } from '@ag2rlamondiale/redux-api-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { EMPTY } from 'rxjs';

class ApiCallerServiceMock {
  count = 0;

  basicRequest(action: any) {
    this.count += action.payload.requestData.length;
    console.log('basicRequest', action, this.count);
    return EMPTY;
  }

  reset() {
    this.count = 0;
  }
}

describe('TraceFrontService', () => {
  const apiCallerService = new ApiCallerServiceMock();

  beforeEach(() => {
    apiCallerService.reset();
    return testingModule({}, {
      providers: [
        TraceFrontService,
        {provide: ApiCallerService, useValue: apiCallerService},
        {provide: ConfigService, useValue: {config: {performance: {active: true, traceFront: true, log: true}}}},
        {provide: TRACE_FRONT_CONFIG, useValue: {XXmeasureXX: {number: 5}}}
      ]
    }).compileComponents();
  });

  it('should be created', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    expect(service).toBeTruthy();
  });

  it('should verifyPerformanceNotActive be false', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    expect(service.verifyPerformanceNotActive()).toBeFalsy();
  });

  it('should checkNombreTracesAllPassed be false', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    service.configure({'SyntheseVisible': {number: 1}});
    expect(service.checkNombreTracesAllPassed()).toBeFalsy();
  });

  it('should checkNombreTracesAllPassed be true', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    service.configure({'SyntheseVisible': {number: 1}});
    service.nombreTraces['SyntheseVisible'] = 1;
    service.nombreTraces['XXmeasureXX'] = 5;
    expect(service.checkNombreTracesAllPassed()).toBeTruthy();
  });

  it('should checkNombreTracesAllPassed be false with many names', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    service.configure({'SyntheseVisible': {number: 1}, 'Other': {number: 5}});
    service.nombreTraces['SyntheseVisible'] = 1;
    service.nombreTraces['Other'] = 2;
    expect(service.checkNombreTracesAllPassed()).toBeFalsy();
  });


  it('should map correctly', () => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    performance.mark('m1');
    performance.measure('measure1', 'm1');
    const measure1 = performance.getEntriesByName('measure1', 'measure')[0];
    expect(measure1).toBeTruthy();

    const trace1 = service.map(measure1);
    expect(trace1.name).toEqual(measure1.name);
    expect(trace1.startTime).toEqual(measure1.startTime);
    expect(trace1.duration).toEqual(measure1.duration);
    expect(trace1.timeOrigin).toEqual(performance.timeOrigin);
    expect(trace1.startTimeFromOrigin).toBeTruthy();
    expect(trace1.endTimeFromOrigin).toBeTruthy();
  });

  it('should send one time', async(() => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    service.prepareSending({measure1: {number: 1}});
    expect(service.checkNombreTracesAllPassed()).toBeFalsy();
    performance.mark('m1');
    performance.measure('measure1', 'm1');
    // On mesure une 2eme fois => ça ne doit rien changer puisqu'on a demandé {measure1: 1}
    performance.measure('measure1', 'm1');
    console.log(service.nombreTraces);
    setTimeout(() => {
      console.log(service.nombreTraces);
      expect(apiCallerService.count).toBeGreaterThanOrEqual(1);
    }, 50);
  }));

  it('should send two times', async(() => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    service.prepareSending({measure1: {number: 1}});
    expect(service.checkNombreTracesAllPassed()).toBeFalsy();
    performance.mark('m1');
    performance.measure('measure1', 'm1');
    performance.measure('measure1', 'm1');
    performance.measure('measure1', 'm1'); // 3e fois pas comptabilise
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    console.log(service.nombreTraces);
    setTimeout(() => {
      console.log(service.nombreTraces);
      expect(service.checkNombreTracesAllPassed()).toBeTruthy();
      expect(apiCallerService.count).toBeGreaterThanOrEqual(2);
    }, 50);
  }));

  it('should send 5 times XXmeasureXX', async(() => {
    const service: TraceFrontService = TestBed.get(TraceFrontService);
    expect(service.checkNombreTracesAllPassed()).toBeFalsy();
    performance.mark('m1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    performance.measure('XXmeasureXX', 'm1');
    console.log(service.nombreTraces);
    setTimeout(() => {
      console.log(service.nombreTraces);
      expect(service.checkNombreTracesAllPassed()).toBeTruthy();
      expect(apiCallerService.count).toBeGreaterThanOrEqual(5);
    }, 50);
  }));


});

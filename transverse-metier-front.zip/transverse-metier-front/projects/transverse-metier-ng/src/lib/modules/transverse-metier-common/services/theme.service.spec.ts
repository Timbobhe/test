import { testingModule } from './../../../test/testing-module';
import { waitForAsync, TestBed } from '@angular/core/testing';
import { ThemeService } from './theme.service';



describe('ThemeService', () => {
  beforeEach(() => testingModule({}, {
    providers: [
      ThemeService
    ]
  }).compileComponents());

  it('should be created', () => {
    const service: ThemeService = TestBed.inject(ThemeService);
    expect(service).toBeTruthy();
  });


  it('should change theme', waitForAsync(() => {
    const service: ThemeService = TestBed.inject(ThemeService);
    service.changeTheme('nie');

    expect(service.currentThemeType).toEqual('nie');
    service.currentTheme.subscribe(e => expect(e.name).toEqual('nie'));
  }));


});

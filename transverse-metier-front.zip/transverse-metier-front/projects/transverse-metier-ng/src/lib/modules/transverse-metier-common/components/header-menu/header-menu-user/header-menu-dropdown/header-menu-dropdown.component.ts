import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { CasService } from '../../../../../../shared/services/cas.service';
import { DeviceSize, ResponsiveService } from '../../../../../../shared/services/responsive.service';
import { DropDownItem } from '../../../../../../models/header.model';


@Component({
  selector: 'trm-header-menu-dropdown',
  templateUrl: './header-menu-dropdown.component.html',
  styleUrls: ['./header-menu-dropdown.component.scss']
})
export class HeaderMenuDropdownComponent implements OnInit {

  @Input() dropDownItems: DropDownItem[];
  @Input() responsiveFirstDropDown: DropDownItem;

  // tslint:disable-next-line:no-output-on-prefix
  @Output() onCloseDropDown = new EventEmitter();

  onResize$: Observable<DeviceSize>;


  constructor(
    private readonly casService: CasService,
    private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }


  ngOnInit() {
  }

  logout() {
    this.casService.logout();
  }

  doAction(dropDownItem: DropDownItem) {
    if (!dropDownItem) {
      return;
    }

    if (dropDownItem.onExecute) {
      dropDownItem.onExecute();
    }

    if (dropDownItem.functionName === 'logout') {
      this.logout();
    }
  }

  closeDropDown() {
    this.onCloseDropDown.emit();
  }

}

import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { DropDownItem, UserHeaderData } from '../../../../../models/header.model';
import { DeviceSize, ResponsiveService } from '../../../../../shared/services/responsive.service';

type dropdownState = 'open-state' | 'close-state';

function toCapitalString(string: string[]): string {
  let result = '';
  for (let i = 0; i < string.length; i++) {
   result = `${result + string[i].charAt(0).toUpperCase() + (string[i].slice(1).toLowerCase()) + ' '}`;
  }
  return result;
}

@Component({
  selector: 'trm-header-menu-user',
  templateUrl: './header-menu-user.component.html',
  styleUrls: ['./header-menu-user.component.scss']
})
export class HeaderMenuUserComponent implements OnInit {

  @Input() userData: UserHeaderData;
  @Input() nom: string;
  @Input() prenom: string;
  @Input() displayUser: boolean;
  @Input() lienContact: string;
  @Input() lienTitre: string;


  infoButton: DropDownItem;

  onResize$: Observable<DeviceSize>;
  menuUserState: dropdownState = 'close-state';

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
    if (this.displayUser) {
      const prenomList = this.prenom.split(' ');
      const nomList = this.nom.split(' ');
      this.infoButton = {
        title: `${toCapitalString(prenomList)} ${toCapitalString(nomList)}`,
        shortTitle: `${this.prenom[0].toUpperCase() + this.nom[0].toUpperCase()}`,
        cssClassName: 'ag2r-011-person',
        onExecute: () => this.toggleMenuUser()
      };
    } else if (this.userData.dropDown?.length > 0) {
      this.infoButton = this.userData.dropDown[0];

      if (this.userData.dropDown.length === 1) {
        this.userData = {...this.userData};
      }
    }
  }

  toggleMenuUser() {
    // 1-line if statement that toggles the value:
    this.menuUserState = this.menuUserState === 'close-state' ? 'open-state' : 'close-state';
  }

  closeDropeDown() {
    this.menuUserState = 'close-state';
  }

  navigateToContact() {
    window.location.href = this.lienContact;
  }

}

import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'trm-large-title-parag',
  templateUrl: './large-title-parag.component.html',
  styleUrls: ['./large-title-parag.component.scss']
})
export class LargeTitleParagComponent implements OnInit {

  @Input() jahiaDicoId: string;
  @Input() jahiaKey: string;
  @Input() jahiaContribId: string;

  constructor() { }

  ngOnInit() {
  }


}

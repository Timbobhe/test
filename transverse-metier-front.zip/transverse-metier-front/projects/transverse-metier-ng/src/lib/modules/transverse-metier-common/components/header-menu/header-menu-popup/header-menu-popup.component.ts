import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MenuItem } from '../../../../../models/menuItem.model';
import { Templates } from '../header-menu.component';


@Component({
  selector: 'trm-header-menu-popup',
  templateUrl: './header-menu-popup.component.html',
  styleUrls: ['./header-menu-popup.component.scss']
})
export class HeaderMenuPopupComponent implements OnInit {
  @Input() displayPop: boolean;
  @Input() menuList: MenuItem[];
  @Input() templates: Templates = {};

  @Output() hideMenu = new EventEmitter<boolean>();
  @Output() onClose = new EventEmitter<boolean>();
  clicked = false;

  constructor() {
  }

  ngOnInit() {

  }

  closePopUp(event: boolean) {
    this.hideMenu.emit(false);
    this.onClose.emit(true);
  }
}

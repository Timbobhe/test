import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HeaderData, HeaderTitle, ImageData, UserHeaderData } from '../../../../../models/header.model';
import { MenuItem } from '../../../../../models/menuItem.model';
import { DeviceSize, ResponsiveService } from '../../../../../shared/services/responsive.service';
import { Templates } from '../header-menu.component';


@Component({
  selector: 'trm-header-menu-container',
  templateUrl: './header-menu-container.component.html',
  styleUrls: ['./header-menu-container.component.scss']
})
export class HeaderMenuContainerComponent implements OnInit {
  @Input() nom: string;
  @Input() prenom: string;
  @Input() displayPop: boolean;
  @Input() menuList: MenuItem[];
  @Input() templates: Templates = {};
  @Input() lienContact: string;
  @Input() displayUser: boolean;
  @Input() displayMenu: boolean;
  @Input() isPartenaire: boolean;
  @Input() listMenuPopUp: MenuItem[];
  @Input() isFilialeAca: boolean;
  imageData: ImageData;
  userData: UserHeaderData;
  lienTitre: HeaderTitle;

  linkContrat: string;
  onResize$: Observable<DeviceSize>;

  CLOSE_STATE = 'close-state';
  menuMobileState = this.CLOSE_STATE;



  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  private _data: HeaderData;

  get data(): HeaderData {
    return this._data;
  }

  @Input()
  set data(value: HeaderData) {
    this._data = value;
    this.lienTitre = this._data.title || {display: false};
    this.userData = this._data.user || {dropDown: null};
    this.imageData = this._data.image;
  }

  ngOnInit() {
  }

  openPopUpMenu() {
    this.displayPop = true;
  }

  hideMenu() {
    this.displayPop = false;
  }

}

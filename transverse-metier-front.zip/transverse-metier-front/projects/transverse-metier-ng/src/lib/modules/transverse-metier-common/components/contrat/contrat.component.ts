import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BasicMessage, Encours, MiniContrat } from '../../../../models';

@Component({
  selector: 'trm-contrat',
  templateUrl: './contrat.component.html',
  styleUrls: ['./contrat.component.scss']
})
export class ContratComponent implements OnInit {
  constructor() {}

  @Input() contrat: MiniContrat;
  @Input() afficherEncours = false; // Afficher encours
  @Input() isActif = false;
  @Input() isClickable = true;
  @Input() raisonBlocage: BasicMessage;
  @Input() jahiaDicoId: string;
  @Output() clickAction: EventEmitter<MiniContrat> = new EventEmitter();

  @Input() encoursGlobal: Encours;

  ngOnInit() {
    console.log(this.raisonBlocage);
  }

  click() {
    if (
      (this.contrat.avecEncours && this.contrat.encours && !this.contrat.encours.encoursEnErreur) ||
      !this.afficherEncours
    ) {
      this.clickAction.emit(this.contrat);
    }
  }

  isContratClickable() {
    return (
      this.isClickable &&
      (!this.afficherEncours ||
        (this.afficherEncours && this.contrat.encours && this.contrat.encours.encoursEnErreur === false))
    );
  }
}

import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MenuItem } from '../../../../../models/menuItem.model';
import { DeviceSize, ResponsiveService } from './../../../../../shared/services/responsive.service';
import { Templates } from '../header-menu.component';

@Component({
  selector: 'trm-header-nav-menu',
  templateUrl: './header-nav-menu.component.html',
  styleUrls: ['./header-nav-menu.component.scss']
})
export class HeaderNavMenuComponent implements OnInit {

  @Input() menuList: MenuItem[];
  @Input() templates: Templates = {};

  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
  }

}

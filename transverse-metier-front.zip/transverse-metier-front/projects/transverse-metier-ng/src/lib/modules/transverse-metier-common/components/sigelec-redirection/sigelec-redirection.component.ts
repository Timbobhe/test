import { Component, Inject, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PartenaireIframeService } from '../../services/partenaire-iframe.service';
import { STEP_COMPLETED } from '../../../../models/client/partenaire.model';
import { APP_CONFIG, AppConfig } from '../../../../models/app.model';

export const statusMap = new Map([
  ['terminee', 'SIGELEC_SUCCESS_MSG'],
  ['annulee', 'SIGELEC_CANCEL_MSG'],
  ['echouee', 'SIGELEC_ERROR_MSG']
]);

export const SIGELEC_MSG_SUFFIX = '&typeUrlResource=absolute&removeJS&removeCSS&removeComments';

@Component({
  selector: 'trm-sigelec-redirection',
  templateUrl: './sigelec-redirection.component.html',
  styleUrls: ['./sigelec-redirection.component.scss']
})
export class SigElecRedirectionComponent implements OnInit {

  @Input() signatureStatus: string;
  @Input() urlPathPrefix: string;
  signatureStatusPath: string;
  contribIdStatus: string;

  constructor(
    private readonly router: Router,
    private readonly partenaireIframe: PartenaireIframeService,
    @Inject(APP_CONFIG) private readonly appConfig: AppConfig) {
  }

  ngOnInit() {
    this.contribIdStatus = statusMap.get(this.signatureStatus);
    this.signatureStatusPath = this.urlPathPrefix + this.contribIdStatus + SIGELEC_MSG_SUFFIX;
    this.partenaireIframe.postStep(STEP_COMPLETED);
  }

  returnToSynthese() {
    this.router.navigate([this.appConfig.homeRoute]);
  }
}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Templates } from '../header-menu/header-menu.component';

@Component({
  selector: 'trm-ecrs-layout-pop-in-menu',
  templateUrl: './layout-pop-in-menu.component.html',
  styleUrls: ['./layout-pop-in-menu.component.scss']
})
export class LayoutPopInMenuComponent implements OnInit {
  @Input() displayPop = true;
  @Input() fullScreen = false;
  @Input() closable = true;
  @Input() templates: Templates = {};
  @Output() onClose = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }
  closePopinMenu() {
    this.displayPop = false;
    this.onClose.emit(true);
  }
}

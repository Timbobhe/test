/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ContratComponent } from './contrat.component';
import { Encours } from '../../../../models/client/contrat.model';
import { testingModule } from '../../../../test/testing-module';


describe('EcrsContratComponent', () => {
  let component: ContratComponent;
  let fixture: ComponentFixture<ContratComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [ContratComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContratComponent);
    component = fixture.componentInstance;
    component.contrat = {
      codeSilo: 'ERE',
      nomContrat: 'numContrat',
      raisonSociale: 'raisonSociale',
      description: 'description',
      encours: Object.assign(new Encours(), {
        montantEncours: 28000,
        dateEncours: '06/09/2019'
      }),
      affichageType: 'NORMAL'
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

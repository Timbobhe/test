import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { InjectionToken } from '@angular/core';
import { Theming } from '../../../models';

export type ThemeType = 'ag2r' | 'adding' | 'nie';
export type LogoType = 'ag2r' | 'aca' |'nie' |'adding';

export interface Logo {
  name: string;
}

export interface ThemeConfig {
  defaultTheme?: { themeType: ThemeType, logoName?: string | LogoType };
  logos?: { [name: string]: Logo };
  themes?: { [name: string]: Theming.Theme };
  onInitLogo?: (logo: Logo, configService: ConfigService) => any;
  onInitTheme?: (theme: Theming.Theme, configService: ConfigService) => void;
}

export const THEME_CONFIG = new InjectionToken<ThemeConfig>('Configuration des Themes');

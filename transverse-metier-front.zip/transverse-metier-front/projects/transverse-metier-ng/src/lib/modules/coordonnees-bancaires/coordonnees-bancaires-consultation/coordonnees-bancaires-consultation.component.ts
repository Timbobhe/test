import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DemandeSigElec, GetSigElecDemEnCours, PushSelectedCoordonneesBancaires } from '../../../actions';
import { COORDONNEES_BANCAIRES, MODIF_RIB } from '../../../consts';
import { CoordonneesBancaires, MiniContrat } from '../../../models';
import { selectInfoClientAndCoordonneesBancaires } from '../../../reducers';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { coordonneesBancairesNonBloquees } from '../coordonnees-bancaires.blocage';
import { CoodonneesBancairesUiConfig, SupplierModifRibService } from '../supplier-modif-rib.service';
import { GlobalState } from '../../../reducers/global.state';

@Component({
  selector: 'mrb-coordonnees-bancaires-consultation',
  templateUrl: './coordonnees-bancaires-consultation.component.html',
  styleUrls: ['./coordonnees-bancaires-consultation.component.scss']
})
export class CoordonneesBancairesConsultationComponent implements OnInit {
  subscriptions: Subscription[] = [];
  coordonneesBancairesNonBloquees: CoordonneesBancaires[];
  contrats: MiniContrat[] = [];

  uiConfig: CoodonneesBancairesUiConfig;

  demandeEncours: { demande: DemandeSigElec, isFetched: boolean, loading: boolean } = {
    demande: null,
    isFetched: false,
    loading: false
  };

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly location: Location,
    private readonly activeRoute: ActivatedRoute,
    private readonly supplierModifRib: SupplierModifRibService) {
  }

  ngOnInit() {
    this.uiConfig = this.supplierModifRib.uiConfig();

    this.store.dispatch(new GetSigElecDemEnCours('RIBA'));

    this.subscriptions.push(selectInfoClientAndCoordonneesBancaires(this.store).subscribe(x => {
      if (x.coordonneesBancaires && x.coordonneesBancaires.isFetched) {
        const coordonneesBancaires = coordonneesBancairesNonBloquees(x.infoClient.infosBlocagesClient,
          x.coordonneesBancaires.data.coordonneesBancairesMetierPrincipal,
          COORDONNEES_BANCAIRES);

        this.coordonneesBancairesNonBloquees = coordonneesBancaires.map(c => {
          const modificationRibBloquee = x.infoClient.infosBlocagesClient.isFonctionnaliteBloqueePourContrat(c.contrat.nomContrat, MODIF_RIB);
          return Object.assign(new CoordonneesBancaires(), c, {modificationRibBloquee});
        });
        this.contrats = x.coordonneesBancaires.data.coordonneesBancairesMetierPrincipal.map(c => c.contrat);

      }

      this.demandeEncours = x.sigElec;
    }));
  }

  isFetched() {
    return this.coordonneesBancairesNonBloquees && this.demandeEncours.isFetched;
  }

  isRibNonBloqueAndModifiable(coordonneesBancaires: CoordonneesBancaires, codeSilo: string): boolean {
    const cbModifiable = coordonneesBancaires.modificationRibPossible && !coordonneesBancaires.modificationRibBloquee;
    return codeSilo != null ? 'ERE' === codeSilo && cbModifiable : cbModifiable;
  }

  descriptionFrontAndNomContrat(contrat: MiniContrat) {
    return `${contrat.description} - ${contrat.nomContrat}`;
  }

  goToVersementProgramme() {
    this.router.navigate([this.supplierModifRib.versementProgrammeRoute()]);
  }

  goToVersementSynthese() {
    this.router.navigate([this.supplierModifRib.versementSyntheseRoute()]);
  }

  modifierCoordonneeBancaire(currentCB: CoordonneesBancaires) {
    this.store.dispatch(new PushSelectedCoordonneesBancaires({currentCoordonneesBancaires: currentCB}));
    if (this.demandeEncours.demande != null) {
      this.router.navigate(['../demande-signature-electronique'], {relativeTo: this.activeRoute});
    } else {
      this.router.navigate(['../modification'], {relativeTo: this.activeRoute});
    }
  }
}

import { Injectable } from '@angular/core';

export interface CoodonneesBancairesUiConfig {
  activeVersementProgrammeRoute: boolean;
  activeVersementSyntheseRoute: boolean;
}

@Injectable({
  providedIn: 'root'
})
export abstract class SupplierModifRibService {

  abstract versementProgrammeRoute(): string;

  abstract versementSyntheseRoute(): string;

  abstract uiConfig(): CoodonneesBancairesUiConfig;

}

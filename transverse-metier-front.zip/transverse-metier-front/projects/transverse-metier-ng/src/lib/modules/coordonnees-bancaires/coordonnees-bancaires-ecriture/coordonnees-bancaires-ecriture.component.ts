import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { CoordonneesBancaires, FileUploadModel, FileUploadResponseModel } from '../../../models';
import { ReglesMetiersRib } from '../coordonnees-bancaires-modification/regles-metiers/regles-metiers-rib';

@Component({
  selector: 'mrb-coordonnees-bancaires-ecriture',
  templateUrl: './coordonnees-bancaires-ecriture.component.html',
  styleUrls: ['./coordonnees-bancaires-ecriture.component.scss']
})
export class CoordonneesBancairesEcritureComponent implements OnInit, OnDestroy {

  @Input() currentCoordonneesBancaires: CoordonneesBancaires;
  @Input() savedCoordonneesBancaires: CoordonneesBancaires;
  @Input() activeRibUpload = true;

  @Output() modifieOption = new EventEmitter<boolean>();
  @Output() cancelModif = new EventEmitter<boolean>();
  @Output() fileUploadedModel = new EventEmitter<FileUploadModel>();
  @Output() futureCoordonneBancaire = new EventEmitter<CoordonneesBancaires>();

  newCoordonneesBancaires: CoordonneesBancaires;
  fileUploaded: FileUploadModel;
  isValidRM7 = true;
  isIbanFr = true;
  frIbanMask = 'aa99 **** **** **?** **** **** ***';

  defaultMask = 'aa99 **** **** **?** **** **** **** **** **';
  ibanMask: string;
  nomCompletFormControl = new FormControl('', [
    this.reglesMetiersRib.RM1,
    Validators.required
  ]);

  ibanFormControl = new FormControl('', [
    ...this.reglesMetiersRib.RM2,
    Validators.required
  ]);


  bicFormControl = new FormControl('', [
    ...this.reglesMetiersRib.RM3,
    Validators.required
  ]);

  coordonneesBancairesForm = new FormGroup({
    nomCompletFormControl: this.nomCompletFormControl,
    ibanFormControl: this.ibanFormControl,
    bicFormControl: this.bicFormControl
  });

  subscriptions: Subscription[] = [];


  constructor(
    protected readonly reglesMetiersRib: ReglesMetiersRib) {
  }

  ngOnInit() {
    this.newCoordonneesBancaires = Object.assign(new CoordonneesBancaires(), this.currentCoordonneesBancaires);
    this.ibanMask = this.defaultMask;
    this.checkRibDifferent();
    this.setFormFieldsValues();
    this.applyFormChange();
  }

  setFormFieldsValues() {
    if (this.currentCoordonneesBancaires != null) {
      this.nomCompletFormControl.setValue(this.currentCoordonneesBancaires.titulaire);
      this.ibanFormControl.setValue(this.currentCoordonneesBancaires.iban);
      this.bicFormControl.setValue(this.currentCoordonneesBancaires.bic);
    }
  }

  applyFormChange() {
    this.subscriptions.push(this.coordonneesBancairesForm.valueChanges
      .subscribe(() => {
        if (this.ibanFormControl.value != null) {
          this.newCoordonneesBancaires.titulaire = this.nomCompletFormControl.value;
          this.newCoordonneesBancaires.iban = this.ibanFormControl.value;
          this.newCoordonneesBancaires.bic = this.bicFormControl.value;
        }
        this.checkIbanFr();
        this.checkRibDifferent();
      }));
  }

  disableButton() {
    return !(this.isValidRM7 && (!this.activeRibUpload || this.fileUploaded && this.fileUploaded.fileName) && this.coordonneesBancairesForm.valid);
  }

  upperCaseValue(formControl: any) {
    formControl.setValue(formControl.value.toUpperCase());
  }

  // Iban
  updateMask(mask: string) {
    if (mask === 'fr') {
      this.ibanMask = this.frIbanMask;
    } else if (mask === 'default' && this.ibanFormControl.value.length > this.frIbanMask.length) {
      this.ibanMask = this.defaultMask;
    }
  }

  // upload file
  deleteRibFile() {
    this.fileUploaded = null;
  }

  onRibFileUpload(uploadedFile: FileUploadResponseModel) {
    this.fileUploaded = uploadedFile;
  }

  getSaisie(iban: String) {
    console.log('iban: ' + iban);
  }

  checkIbanFr() {
    if (this.newCoordonneesBancaires && this.newCoordonneesBancaires.iban) {
      this.isIbanFr = this.newCoordonneesBancaires.iban.toUpperCase().startsWith('FR');
    }
  }

  checkRibDifferent() {
    this.isValidRM7 = this.savedCoordonneesBancaires
      ? this.reglesMetiersRib.RM7(this.savedCoordonneesBancaires.iban, this.newCoordonneesBancaires.iban)
      : true;
  }

  enregistrerModif() {
    this.newCoordonneesBancaires.rib = this.fileUploaded;
    this.futureCoordonneBancaire.emit(this.newCoordonneesBancaires);
  }

  cancel() {
    this.cancelModif.emit(true);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

}

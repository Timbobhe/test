import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { CoordonneesBancairesSigelecRedirectComponent } from './coordonnees-bancaires-sigelec-redirect.component';


describe('CoordonneesBancairesSigelecRedirectComponent', () => {
  let component: CoordonneesBancairesSigelecRedirectComponent;
  let fixture: ComponentFixture<CoordonneesBancairesSigelecRedirectComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterModule.forRoot([])],
      declarations: [CoordonneesBancairesSigelecRedirectComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesSigelecRedirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

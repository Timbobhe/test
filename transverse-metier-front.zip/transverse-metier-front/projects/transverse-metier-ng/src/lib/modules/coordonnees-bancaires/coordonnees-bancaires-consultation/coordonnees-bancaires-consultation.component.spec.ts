/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BicPipe } from '../pipes/bic.pipe';
import { IbanPipe } from '../pipes/iban.pipe';
import { testingModule } from '../../../test/testing-module';
import { initialStateWithCoordonneesBancaires } from '../../../test/store-states.mock';
import { CoordonneesBancairesConsultationComponent } from './coordonnees-bancaires-consultation.component';
import { RouterTestingModule } from '@angular/router/testing';
import { SupplierModifRibService } from '../supplier-modif-rib.service';
import { TestSupplierModifRibService } from '../test/test-supplier-modif-rib.service';


describe('CoordonneesBancairesConsultationComponent', () => {
  let component: CoordonneesBancairesConsultationComponent;
  let fixture: ComponentFixture<CoordonneesBancairesConsultationComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithCoordonneesBancaires},
      {
        imports: [RouterTestingModule.withRoutes([{path: '', redirectTo: 'coordonnees-bancaires', pathMatch: 'full'}])],
        declarations: [CoordonneesBancairesConsultationComponent, IbanPipe, BicPipe],
        providers: [
          {provide: SupplierModifRibService, useClass: TestSupplierModifRibService}
        ]
      })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesConsultationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be defined and in initial state', () => {
    expect(component.coordonneesBancairesNonBloquees.length).toEqual(2);
  });

  it('should contains 2 contracts', () => {
    const element = fixture.debugElement;
    const contrats = element.queryAll(By.css('.descriptionFront-contrat'));
    expect(contrats.length).toEqual(2);
  });

  it('should contains 2 modifiable contracts', () => {
    const element = fixture.debugElement;
    const contrats = element.queryAll(By.css('.container-cb-contrat'));
    expect(contrats.length).toEqual(2);
    const contratsModifiable = element.queryAll(By.css('.lien-modifier'));
    expect(contratsModifiable.length).toEqual(1);
  });
});

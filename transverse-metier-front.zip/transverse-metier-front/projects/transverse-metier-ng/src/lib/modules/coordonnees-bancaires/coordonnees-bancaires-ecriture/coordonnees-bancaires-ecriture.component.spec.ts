import { Globals } from './../../../shared/utils/globals';
import { ReglesMetiersRib } from './../coordonnees-bancaires-modification/regles-metiers/regles-metiers-rib';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CoordonneesBancairesEcritureComponent } from './coordonnees-bancaires-ecriture.component';

describe('CoordonneesBancairesEcritureComponent', () => {
  let component: CoordonneesBancairesEcritureComponent;
  let fixture: ComponentFixture<CoordonneesBancairesEcritureComponent>;
  let reglesMetiersRib;

  beforeEach(waitForAsync(() => {
    reglesMetiersRib = new ReglesMetiersRib(new Globals());
    TestBed.configureTestingModule({
      declarations: [ CoordonneesBancairesEcritureComponent ],
      providers: [{provide: ReglesMetiersRib, useValue: reglesMetiersRib}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesEcritureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

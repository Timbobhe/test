import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CoordBancairesAutorizedModification, CoordonneesBancaires } from '../../../models';

@Component({
  selector: 'mrb-coordonnees-bancaires-lecture',
  templateUrl: './coordonnees-bancaires-lecture.component.html',
  styleUrls: ['./coordonnees-bancaires-lecture.component.scss']
})
export class CoordonneesBancairesLectureComponent implements OnInit {

  constructor() {
  }

  @Input() cbContrat: CoordonneesBancaires;
  @Input() addLinkModifier: boolean;

  @Input() isNonBloqueOrModifiable: boolean;
  @Input() maskRib = true;
  @Input() inline = false;

  @Output() modifierRib = new EventEmitter<CoordBancairesAutorizedModification>();


  ngOnInit() {
    if (this.addLinkModifier == null) {
      this.addLinkModifier = true;
    }
  }

  onClickModifier() {
    if (this.addLinkModifier) {
      this.modifierRib.emit({cb: this.cbContrat, modifieOption: true});
    }
  }

}

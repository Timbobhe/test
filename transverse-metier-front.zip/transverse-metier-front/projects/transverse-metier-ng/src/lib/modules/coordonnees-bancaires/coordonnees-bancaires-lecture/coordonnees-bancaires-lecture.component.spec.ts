import { BicPipe } from './../pipes/bic.pipe';
import { IbanPipe } from './../pipes/iban.pipe';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CoordonneesBancairesLectureComponent } from './coordonnees-bancaires-lecture.component';

describe('CoordonneesBancairesLectureComponent', () => {
  let component: CoordonneesBancairesLectureComponent;
  let fixture: ComponentFixture<CoordonneesBancairesLectureComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CoordonneesBancairesLectureComponent, MockIbanPipe, MockBicPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesLectureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class MockIbanPipe extends IbanPipe {}
class MockBicPipe extends BicPipe {}

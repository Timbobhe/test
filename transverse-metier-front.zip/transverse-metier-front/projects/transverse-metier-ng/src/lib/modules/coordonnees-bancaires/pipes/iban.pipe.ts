import { Pipe, PipeTransform } from '@angular/core';
import { replaceAt } from '../../../shared/utils/utils.functions';

const IBAN_END_UNMASK_LENGHT = 2;
const IBAN_BEGIN_UNMASK_LENGHT = 14;
const MASK_CHAR = '*';

@Pipe({ name: 'iban' })
export class IbanPipe implements PipeTransform {
  transform(value: string, mask = false): string {
    if (!value) { return null; }

    let i = IBAN_BEGIN_UNMASK_LENGHT;
    value = value.split(' ').join('');
    if (mask) {
      for (i; i < (value.length - IBAN_END_UNMASK_LENGHT); i++) {
        value = replaceAt(value, i, MASK_CHAR);
      }
    }
    return value.replace(/(.{4})/g, '$1 ');
  }
}

import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EMPTY, Observable, Subscription } from 'rxjs';
import { CoordonneesBancairesConsultationComponent } from './coordonnees-bancaires-consultation/coordonnees-bancaires-consultation.component';
import { CoordonneesBancairesModificationComponent } from './coordonnees-bancaires-modification/coordonnees-bancaires-modification.component';
import { GlobalState } from '../../reducers/global.state';
import { Store } from '@ngrx/store';

@Component({
  selector: 'mrb-coordonnees-bancaires',
  templateUrl: './coordonnees-bancaires.component.html',
  styleUrls: ['./coordonnees-bancaires.component.scss']
})
export class CoordonneesBancairesComponent implements OnInit, OnDestroy {

  title: string;
  subtitleDescriptionFront$: Observable<string>;
  subtitleRaisonSocialeFront$: Observable<string>;
  isMdpro = false;
  isMultiEquipe = false;
  private subscriptions: Subscription[] = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly jahia: JahiaService) {
  }

  ngOnInit() {
    this.jahia.prefetchPathsDomaines('common', 'coordonneesBancaires', 'prevalidation', 'identiteNum');

    this.subscriptions.push(
      this.store.select('clientInfos').subscribe(value => {
        this.isMdpro = value && value.silos.length === 1 && value.silos.indexOf('MDP') !== -1;
        this.isMultiEquipe = this.isMdpro && value.silos.indexOf('ERE') !== -1;
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  onChildLoaded(component: CoordonneesBancairesConsultationComponent
    | CoordonneesBancairesModificationComponent) {
    if (component instanceof CoordonneesBancairesConsultationComponent) {
      this.title = 'consultation';
      this.subtitleDescriptionFront$ = EMPTY;
      this.subtitleRaisonSocialeFront$ = EMPTY;
    } else {
      this.title = 'modification';
      this.subtitleDescriptionFront$ = component.subtitleDescriptionFront;
      this.subtitleRaisonSocialeFront$ = component.subtitleRaisonSocialeFront;
    }
  }
}

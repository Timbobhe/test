import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Component, DebugElement, ElementRef, Input } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { IbanPipe } from '../pipes/iban.pipe';
import { GlobalState } from '../../../reducers/global.state';
import { ButtonCtaComponent } from '../../../shared/components/button-cta/button-cta.component';
import { Globals } from '../../../shared/utils/globals';
import { Store } from '@ngrx/store';
import { MessageService } from 'primeng/api';
import { InputMaskModule } from 'primeng/inputmask';
import {
  concatInitialStates,
  initialStateWithClientInfos,
  initialStateWithContractsAssures,
  initialStateWithCoordonneesBancaires
} from '../../../test/store-states.mock';
import { testingModule } from '../../../test/testing-module';
import { CoordonneesBancairesModificationComponent } from './coordonnees-bancaires-modification.component';
import { ReglesMetiersRib } from './regles-metiers/regles-metiers-rib';

@Component({selector: 'jahia-dico', template: ''})
class JahiaDicoStubComponent {
  @Input() dicoId: string;
  @Input() title: string;
  valeur = function () {
  };
}

@Component({selector: 'synthese-des-comptes', template: ''})
class StubComponent {
}

describe('ModificationCoordonneesBancairesComponent', () => {
  let component: CoordonneesBancairesModificationComponent;
  let fixture: ComponentFixture<CoordonneesBancairesModificationComponent>;
  let store: Store<GlobalState>;
  let de: DebugElement;
  let element: ElementRef;

  const configServiceStub = {
    config: {
      'lien_revocation_universign': 'https://sign.test.universign.eu/fr/revocation/',
      'aqea_endpoint': 'http://aqea/',
      'parcours_client_endpoint': 'http://parcours_client/accueil/'
    }
  };

  beforeEach(waitForAsync(() => {
    const initialState = concatInitialStates(initialStateWithContractsAssures,
      initialStateWithClientInfos,
      initialStateWithCoordonneesBancaires);
    testingModule({...initialState}, {
      imports: [
        RouterTestingModule.withRoutes([
          {
            path: '**',
            component: StubComponent,
            pathMatch: 'full'
          }
        ]),
        ReactiveFormsModule,
        FormsModule,
        InputMaskModule
      ],
      declarations: [CoordonneesBancairesModificationComponent,
        JahiaDicoStubComponent,
        StubComponent,
        ButtonCtaComponent,
        IbanPipe],
      providers: [
        {provide: ConfigService, useValue: configServiceStub},
        MessageService,
        ReglesMetiersRib,
        Globals,
        IbanPipe,
        CoordonneesBancairesModificationComponent
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    store = TestBed.inject(Store);
    spyOn(store, 'select').and.callThrough();
    fixture = TestBed.createComponent(CoordonneesBancairesModificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be defined and in initial state', () => {
    expect(component.coordonneesBancairesRetraiteSupp.length).toEqual(2);
    expect(component.coordonneesBancairesEpargnePrevoyance.length).toEqual(1);
    expect(component.currentCoordonneesBancaires).toBeDefined();
    expect(component.newCoordonneesBancaires).toBeDefined();
    expect(component.isValidRM4).toBeTruthy();
    expect(component.isValidRM5).toBeFalsy();
    expect(component.isValidRM7).toBeFalsy();
  });

  it('should show slider', () => {
    component.selectContratsRetraiteSuppForNewRib([component.coordonneesBancairesRetraiteSupp.map(c => c.contrat).filter(c => c.codeSilo === 'MDPRO').pop()]);
    fixture.detectChanges();
    de = fixture.debugElement;
    element = de.query(By.css('.p-inputswitch-slider'));
    expect(component.isValidRM5).toBeFalsy();
    expect(component.isValidRM6).toBeFalsy();
    expect(element).toBeDefined();
  });

  it('should enable next button', () => {
    fixture.detectChanges();

    de = fixture.debugElement;
    element = de.query(By.css('#nextButton'));
    const button: HTMLElement = element.nativeElement;
    expect(button.getAttribute('ng-reflect-disabled')).toEqual('true');
    component.modifierRIB();
    fixture.detectChanges();
  });
});

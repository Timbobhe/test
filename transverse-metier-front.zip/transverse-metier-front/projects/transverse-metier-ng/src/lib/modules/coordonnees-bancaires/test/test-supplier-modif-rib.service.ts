import { Injectable } from '@angular/core';
import { SupplierModifRibService, CoodonneesBancairesUiConfig } from '../supplier-modif-rib.service';


@Injectable({
  providedIn: 'root'
})
export class TestSupplierModifRibService extends SupplierModifRibService {

  versementProgrammeRoute(): string {
    return '/modification-gestion-financiere';
  }

  versementSyntheseRoute(): string {
    return '/synthese-des-comptes';
  }

  uiConfig(): CoodonneesBancairesUiConfig {
    return {activeVersementSyntheseRoute: true, activeVersementProgrammeRoute: true};
  }

}

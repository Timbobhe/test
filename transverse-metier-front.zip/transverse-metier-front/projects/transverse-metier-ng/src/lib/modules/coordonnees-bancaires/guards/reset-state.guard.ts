import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { TrackingState } from '../../../reducers';
import { ResetStateAction } from '../../../actions';
import { GlobalState } from '../../../reducers/global.state';

@Injectable({
  providedIn: 'root'
})
export class ResetStateGuard implements CanActivate {

  constructor(private readonly store: Store<GlobalState>) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.store.dispatch(new ResetStateAction<GlobalState>({
      coordonneesBancaires: {},
      identNumMatchAccount: {},
      sigElec: {},
      tracking: (state: TrackingState) => Object.assign({info: state.info})
    }));
    return true;
  }

}

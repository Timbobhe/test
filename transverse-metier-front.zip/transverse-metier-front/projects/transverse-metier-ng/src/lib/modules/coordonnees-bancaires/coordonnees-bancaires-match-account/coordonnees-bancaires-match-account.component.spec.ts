import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { CoordonneesBancairesMatchAccountComponent } from './coordonnees-bancaires-match-account.component';
import {StoreModule} from '@ngrx/store';
import * as fromRoot from '@app/reducers/_index';

describe('CoordonneesBancairesMatchAccountComponent', () => {
  let component: CoordonneesBancairesMatchAccountComponent;
  let fixture: ComponentFixture<CoordonneesBancairesMatchAccountComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(fromRoot.reducers),
        RouterModule.forRoot([])],
      declarations: [CoordonneesBancairesMatchAccountComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesMatchAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

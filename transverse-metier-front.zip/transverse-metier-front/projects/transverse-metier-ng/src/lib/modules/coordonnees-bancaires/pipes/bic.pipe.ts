import { Pipe, PipeTransform } from '@angular/core';
import { replaceAt } from '../../../shared/utils/utils.functions';

const BIC_END_UNMASK_LENGHT = 2;
const BIC_BEGIN_UNMASK_LENGHT = 6;
const MASK_CHAR = '*';

@Pipe({ name: 'bic' })
export class BicPipe implements PipeTransform {
  transform(value: string, mask = false): string {
    if (!value) { return null; }

    let i = BIC_BEGIN_UNMASK_LENGHT;

    if (mask) {
      for (i; i < (value.length - BIC_END_UNMASK_LENGHT); i++) {
        value = replaceAt(value, i, MASK_CHAR);
      }
    }

    return value;
  }
}

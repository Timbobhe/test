import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { CoordonneesBancaires, MiniContrat } from '../../../../models';
import { Globals } from '../../../../shared/utils/globals';

@Injectable()
export class ReglesMetiersRib {

  constructor(private readonly globals: Globals) {
  }

  RM1 = Validators.maxLength(100);
  RM2 = [
    Validators.minLength(14),
    Validators.maxLength(34),
    Validators.pattern(this.globals.FRENCH_IBAN_PATTERN + this.globals.FIVE_TIMES_FOUR_ALPHANUMERIC_WITH_SPACE + this.globals.TREE_ALPHANUMERIC_WITH_SPACE)
  ];
  RM3 = [
    Validators.minLength(8),
    Validators.maxLength(11),
    Validators.pattern(this.globals.ONLY_ALPHANUMERIC)
  ];

  /**
   * Le bloc associé un RIB à d’autres contrats n’est affiché que dans le cas ou il y a plus d’un contrat pour lesquels la modification du RIB est possible.
   */

  RM4 = (coordonneesBancairesRetraiteSupp: CoordonneesBancaires[], coordonneesBancairesEpargnePrevoyance: CoordonneesBancaires[]) => {
    return coordonneesBancairesEpargnePrevoyance && coordonneesBancairesEpargnePrevoyance.length > 0 || coordonneesBancairesRetraiteSupp && coordonneesBancairesRetraiteSupp.filter(c => {
      return c.modificationRibPossible;
    }).length > 1;
  };

  /**
   * Le slider n’est affiché que si le choix initial du client se porte sur un contrat MDPRO ou si le client clique sur oui pour associer d’autres contrats
   * et choisi un contrat MDPRO
   */
  RM5 = (currentContrat: MiniContrat, selectedContratsRetraiteSupp: MiniContrat[], selectedContratsEpargnePrevoyance: MiniContrat[]) => {
    return (currentContrat && currentContrat.codeSilo === 'MDP') || (selectedContratsRetraiteSupp && selectedContratsRetraiteSupp.some(c => c.codeSilo === 'MDP' || c.codeSilo === 'MDPRO')
      || (selectedContratsEpargnePrevoyance.some(c => c.codeSilo === 'MDP' || c.codeSilo === 'MDPRO')));
  };

  /**
   * Le bouton continuer devient en bleu que si tous les contrôles sont bons, que le slider a été checké, que le client a choisi d'étendre ou pas son RIB sur
   * d’autres contrats et qu’il a choisi un seul contrat s’il veut étendre son RIB
   */
  RM6 = (controlsOk: boolean, silderActivated: boolean, silderChecked: boolean, etendreOk: boolean,
         selectedContratsRetraiteSupp: MiniContrat[], selectedContratsEpargnePrevoyance: MiniContrat[]) => {
    return !silderActivated ? controlsOk : controlsOk && (silderActivated === silderChecked) && (etendreOk === (selectedContratsRetraiteSupp.length > 0 || selectedContratsEpargnePrevoyance.length > 0));
  };

  /**
   * Le RIB saisi ne doit pas être identique à l’ancien RIB sinon un message d’erreur est affiché au client
   */
  RM7 = (oldIban: string, newIban: string) => {
    if (!oldIban) {
      return true;
    }
    return oldIban !== newIban;
  };

  /**
   * Si le RIB saisi n’est pas identique pour le contrat choisi mais est identique pour l’un des contrats du client,
   * ce contrat n’est pas proposé dans la liste.
   * Si aussi la modification des coordonnées bancaires est possible
   */
  RM8 = (currentContrat: MiniContrat, newIban: string, coordonneesBancairesRetraiteSupp: CoordonneesBancaires[]) => {
    return coordonneesBancairesRetraiteSupp && coordonneesBancairesRetraiteSupp.filter(c => {
      return (c.modificationRibPossible && currentContrat.nomContrat !== c.contrat.nomContrat && c.contrat.affichageType === 'NORMAL') && c.iban !== newIban;
    });
  };
}

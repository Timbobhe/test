import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { GetModifierCoordonneesBancairesStart } from '../../../actions';
import { selectInfoClientAndCoordonneesBancaires } from '../../../reducers/transverse-metier.selectors';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { GlobalState } from '../../../reducers/global.state';

@Injectable({
  providedIn: 'root'
})
export class StartGuard implements CanActivate {

  constructor(
    private readonly store: Store<GlobalState>) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    return selectInfoClientAndCoordonneesBancaires(this.store).pipe(
      take(1),
      map(x => {
        if (!x.coordonneesBancaires.isFetched && !x.coordonneesBancaires.loading) {
          this.store.dispatch(new GetModifierCoordonneesBancairesStart());
        }
        return true;
      })
    );
  }

}

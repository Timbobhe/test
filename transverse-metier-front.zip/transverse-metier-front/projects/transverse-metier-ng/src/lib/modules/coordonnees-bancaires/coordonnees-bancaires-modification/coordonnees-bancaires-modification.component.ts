import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Subscription } from 'rxjs';
import { PushModifierCoordonneesBancaires, PushModifierCoordonneesBancairesPayload, tracking } from '../../../actions';
import { MODIF_RIB } from '../../../consts';
import { Categorie, TypeOriginAction } from '../../../consts/tracking.const';
import { CoordonneesBancaires, FileUploadModel, FileUploadResponseModel, MiniContrat, ModificationCoordonneesBancairesDto } from '../../../models';
import { selectCurrentContratAndCoordonneesBancairesAndInfoClient } from '../../../reducers';
import { GlobalState } from '../../../reducers/global.state';
import { coordonneesBancairesNonBloquees } from '../coordonnees-bancaires.blocage';
import { ReglesMetiersRib } from './regles-metiers/regles-metiers-rib';


@Component({
  selector: 'mrb-coordonnees-bancaires-modification',
  templateUrl: './coordonnees-bancaires-modification.component.html',
  styleUrls: ['./coordonnees-bancaires-modification.component.scss']
})
export class CoordonneesBancairesModificationComponent implements OnInit, OnDestroy {

  subtitleDescriptionFront: BehaviorSubject<string> = new BehaviorSubject('');
  subtitleRaisonSocialeFront: BehaviorSubject<string> = new BehaviorSubject('');

  subscriptions: Subscription[] = [];
  coordonneesBancairesRetraiteSupp: CoordonneesBancaires[] = [];
  coordonneesBancairesEpargnePrevoyance: CoordonneesBancaires[] = [];
  listContratsEpargnePrevoyanceChoix: MiniContrat[] = [];
  listContratsRetraiteSuppChoix: MiniContrat[] = [];
  selectedContratsRetraiteSupp: MiniContrat[] = [];
  selectedContratsEpargnePrevoyance: MiniContrat[] = [];
  currentContrat: MiniContrat;

  currentCoordonneesBancaires: CoordonneesBancaires;
  newCoordonneesBancaires: CoordonneesBancaires;

  fileUploadModel: FileUploadModel;

  isValidRM4: boolean;
  isValidRM5: boolean;
  isValidRM6: boolean;
  isValidRM7 = true;
  isIbanFr = true;
  isCeritficationChecked = false;
  isCertificationCheckedForEpargnePrevoyance = false;
  isAssocierAutresContrats = false;

  frIbanMask = 'aa99 **** **** **?** **** **** ***';
  defaultMask = 'aa99 **** **** **?** **** **** **** **** **';
  ibanMask: string;

  nomCompletFormControl = new FormControl('', [
    this.reglesMetiersRib.RM1,
    Validators.required
  ]);

  ibanFormControl = new FormControl('', [
    ...this.reglesMetiersRib.RM2,
    Validators.required
  ]);


  bicFormControl = new FormControl('', [
    ...this.reglesMetiersRib.RM3,
    Validators.required
  ]);

  coordonneesBancairesForm = new FormGroup({
    nomCompletFormControl: this.nomCompletFormControl,
    ibanFormControl: this.ibanFormControl,
    bicFormControl: this.bicFormControl
  });


  constructor(private readonly store: Store<GlobalState>,
    protected readonly reglesMetiersRib: ReglesMetiersRib,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }


  ngOnInit() {
    this.ibanMask = this.defaultMask;

    this.subscriptions.push(selectCurrentContratAndCoordonneesBancairesAndInfoClient(this.store).subscribe(x => {
      this.coordonneesBancairesRetraiteSupp = coordonneesBancairesNonBloquees(x.infoClient.infosBlocagesClient,
        x.coordonneesBancaires.data.coordonneesBancairesMetierPrincipal, MODIF_RIB);
      this.coordonneesBancairesEpargnePrevoyance = coordonneesBancairesNonBloquees(x.infoClient.infosBlocagesClient,
        x.coordonneesBancaires.data.coordonneesBancairesAutresMetiers,
        MODIF_RIB);
      this.currentCoordonneesBancaires = x.coordonneesBancaires.currentCoordonneesBancaires;
      this.newCoordonneesBancaires = Object.assign(new CoordonneesBancaires(), this.currentCoordonneesBancaires);
      this.currentContrat = x.currentContrat;
      this.subtitleDescriptionFront.next(`${x.currentContrat.description} - ${x.currentContrat.nomContrat}`);
      this.subtitleRaisonSocialeFront.next(`${x.currentContrat.raisonSociale != null ? x.currentContrat.raisonSociale : ''}`);
      if (this.currentCoordonneesBancaires) {
        this.checkIbanFr();
        this.checkRM4();
        this.checkRM5();
        this.checkRM7();
      }
    }));
    this.handleFormChanges();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  upperCaseValue(formControl: any) {
    formControl.setValue(formControl.value.toUpperCase());
  }

  handleFormChanges() {
    this.subscriptions.push(this.coordonneesBancairesForm.valueChanges
      .subscribe(() => {
        if (this.ibanFormControl.value != null) {
          this.newCoordonneesBancaires.titulaire = this.nomCompletFormControl.value;
          this.newCoordonneesBancaires.iban = this.ibanFormControl.value;
          this.newCoordonneesBancaires.bic = this.bicFormControl.value;
        }
        this.checkIbanFr();
        this.checkRM7();
        this.checkRM8();
      }));
  }

  deleteRibFile() {
    this.fileUploadModel = null;
  }

  onRibFileUpload(uploadedFile: FileUploadResponseModel) {
    this.fileUploadModel = uploadedFile;
  }

  updateCertificationCheckedStatus(event: any) {
    this.isCeritficationChecked = event;
  }

  updateCertificationCheckedForEpargneAndPrevoyance(event: any) {
    this.isCertificationCheckedForEpargnePrevoyance = event;
  }

  handleYesOrNo(isAssocierAutresContrats: boolean) {
    this.isAssocierAutresContrats = isAssocierAutresContrats;
    if (isAssocierAutresContrats) {
      this.checkRM8();
    } else {
      this.selectedContratsRetraiteSupp = [];
      this.selectedContratsEpargnePrevoyance = [];
    }
  }

  modifierRIB() {
    const dto = new ModificationCoordonneesBancairesDto();
    dto.contratSelected = this.currentCoordonneesBancaires.contrat;

    dto.coordonneesBancairesActuelles = {
      titulaireCompte: this.currentCoordonneesBancaires.titulaire,
      codeBIC: this.currentCoordonneesBancaires.bic,
      codeIBAN: this.currentCoordonneesBancaires.iban
    };
    dto.coordonneesBancairesModifiees = {
      titulaireCompte: this.newCoordonneesBancaires.titulaire,
      codeBIC: this.newCoordonneesBancaires.bic,
      codeIBAN: this.newCoordonneesBancaires.iban
    };
    dto.fichiersJoint = [];
    dto.fichiersJoint.push(this.fileUploadModel);

    const payload = new PushModifierCoordonneesBancairesPayload();
    payload.demandeModificationCoordonneesBancaires = [];
    payload.demandeModificationCoordonneesBancaires.push(dto);

    if (this.selectedContratsRetraiteSupp && this.selectedContratsRetraiteSupp.length) {
      this.modifierRibAutresContrats(this.selectedContratsRetraiteSupp, payload, dto);
    }
    if (this.selectedContratsEpargnePrevoyance && this.selectedContratsEpargnePrevoyance.length) {
      this.modifierRibAutresContrats(this.selectedContratsEpargnePrevoyance, payload, dto);
    }
    payload.demandeModificationCoordonneesBancaires.forEach(demande => {
      // if blank, put '' instead of nothing to ease API requesting
      const actualRib = demande.coordonneesBancairesActuelles != null ? demande.coordonneesBancairesActuelles.codeIBAN : '';
      this.store.dispatch(tracking(Categorie.coordonneesBancaires, TypeOriginAction.coordonneesBancaires_modification, actualRib));
    });
    this.store.dispatch(new PushModifierCoordonneesBancaires(payload));
    this.router.navigate(['../verification-donnees-personnelles'], { relativeTo: this.activeRoute });
  }

  modifierRibAutresContrats(contrats: MiniContrat[], payload: PushModifierCoordonneesBancairesPayload, dto: ModificationCoordonneesBancairesDto) {
    contrats.forEach(contrat => {
      const cb = this.coordonneesBancairesRetraiteSupp.find(coordBanc => coordBanc.contrat.nomContrat === contrat.nomContrat);
      const modifDto = new ModificationCoordonneesBancairesDto();
      modifDto.contratSelected = contrat;

      if (cb) {
        modifDto.coordonneesBancairesActuelles = {
          titulaireCompte: cb.titulaire,
          codeBIC: cb.bic,
          codeIBAN: cb.iban
        };
      }
      modifDto.coordonneesBancairesModifiees = dto.coordonneesBancairesModifiees;
      modifDto.fichiersJoint = dto.fichiersJoint;

      payload.demandeModificationCoordonneesBancaires.push(modifDto);
    });
  }

  selectContratsRetraiteSuppForNewRib(contrats: MiniContrat[]) {
    this.selectedContratsRetraiteSupp = contrats;
  }

  selectContratsEpargnePrevoyanceForNewRib(contrats: MiniContrat[]) {
    this.selectedContratsEpargnePrevoyance = contrats;
  }

  checkIbanFr() {
    if (this.newCoordonneesBancaires && this.newCoordonneesBancaires.iban) {
      this.isIbanFr = this.newCoordonneesBancaires.iban.toUpperCase().startsWith('FR');
    }
  }

  checkRM4() {
    this.isValidRM4 = this.reglesMetiersRib.RM4(this.coordonneesBancairesRetraiteSupp, this.coordonneesBancairesEpargnePrevoyance);
  }

  checkRM5() {
    this.isValidRM5 = this.reglesMetiersRib.RM5(this.currentContrat, this.selectedContratsRetraiteSupp, this.selectedContratsEpargnePrevoyance);
  }

  disableNextButton() {
    return !(this.isValidRM7 && this.fileUploadModel && this.fileUploadModel.fileName &&
      this.reglesMetiersRib.RM6(this.coordonneesBancairesForm.valid, this.isValidRM5,
        this.isCeritficationChecked, this.isAssocierAutresContrats, this.selectedContratsRetraiteSupp, this.selectedContratsEpargnePrevoyance));
  }

  checkRM7() {
    this.isValidRM7 = this.reglesMetiersRib.RM7(this.currentCoordonneesBancaires.iban,
      this.newCoordonneesBancaires.iban);
  }

  checkRM8() {
    this.listContratsRetraiteSuppChoix = this.ibanFormControl.valid && this.reglesMetiersRib.RM8(this.currentContrat,
      this.newCoordonneesBancaires.iban, this.coordonneesBancairesRetraiteSupp).map(c => c.contrat);
    this.listContratsEpargnePrevoyanceChoix = this.coordonneesBancairesEpargnePrevoyance.map(c => c.contrat);
  }

  updateMask(mask: string) {
    if (mask === 'fr') {
      this.ibanMask = this.frIbanMask;
    } else if (mask === 'default' && this.ibanFormControl.value.length > this.frIbanMask.length) {
      this.ibanMask = this.defaultMask;
    }
  }

  isAucunContratSelectionne() {
    return this.isAssocierAutresContrats && this.isCeritficationChecked && (this.selectedContratsRetraiteSupp.length === 0) && (this.selectedContratsEpargnePrevoyance.length === 0);
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../reducers/global.state';
import { selectDemSigElec } from '../../../reducers/transverse-metier.selectors';
import { map, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ModificationGuard implements CanActivate {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    return this.store.select(selectDemSigElec).pipe(
      take(1),
      map(e => {
        if (!e.isFetched) {
          return false;
        }

        if (e.demande != null) {
          this.router.navigate(['/coordonnees-bancaires/demande-signature-electronique'], {replaceUrl: true});
          return false;
        }

        return true;
      })
    );
  }

}

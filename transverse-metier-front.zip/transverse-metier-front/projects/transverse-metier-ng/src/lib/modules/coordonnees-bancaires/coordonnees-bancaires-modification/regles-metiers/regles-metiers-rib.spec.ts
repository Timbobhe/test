import { waitForAsync, TestBed } from '@angular/core/testing';
import { Contrat } from '@app/models/client/contrat.model';
import { ReglesMetiersRib } from './regles-metiers-rib';
import { CoordonneesBancaires } from '../../../../models';
import { Globals } from '../../../../shared/utils/globals';


describe('ReglesMetiersRibService', () => {
  let service: ReglesMetiersRib;
  const contratERE: Contrat = {codeSilo: 'ERE', nomContrat: 'RG135153689'} as Contrat;
  const contratMDP: Contrat = {codeSilo: 'MDP', nomContrat: 'RG150108276'} as Contrat;
  const contratsRetraiteSupp: Contrat[] = [
    {codeSilo: 'ERE', nomContrat: 'RP151131238'} as Contrat,
    contratERE,
    contratMDP];

  const coordonneesBancaires: CoordonneesBancaires[] = [
    {
      contrat: {nomContrat: 'RG135153689', codeSilo: 'ERE', college: null, idAdherente: null, idContractante: null},
      titulaire: 'MME DURAND /HAURY ISABELLE',
      bic: 'CRLYFRPPXXX',
      iban: 'FR6630002006530000020595G59',
      idMessage: null,
      modificationRibPossible: true,
      modificationRibBloquee: false
    } as CoordonneesBancaires,
    {
      contrat: {nomContrat: 'RG150108276', codeSilo: 'ERE'},
      titulaire: 'MME DURAND /HAURY ISABELLE',
      bic: 'CRLYFRPPXXX',
      iban: 'FR6630002006530000020595G59',
      idMessage: null,
      modificationRibPossible: true,
      modificationRibBloquee: false
    } as CoordonneesBancaires,
    {
      contrat: {nomContrat: 'RP151131238', codeSilo: 'ERE'},
      titulaire: 'MME DURAND /HAURY ISABELLE',
      bic: 'CRLYFRPPXXX',
      iban: 'FR6630002006530000020595G59',
      idMessage: null,
      modificationRibPossible: true,
      modificationRibBloquee: false
    } as CoordonneesBancaires,
  ];

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      providers: [ReglesMetiersRib, Globals],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    service = TestBed.inject(ReglesMetiersRib);
  });

  it('RM4 should return true', () => {
    expect(service.RM4(coordonneesBancaires, null)).toBeTruthy();
  });

  it('RM5 should return true', () => {
    expect(service.RM5(contratERE, contratsRetraiteSupp, null)).toBeTruthy();
  });

  it('RM6 should return true', () => {
    expect(service.RM6(true, false, false, true, null, null)).toBeTruthy();
  });

  it('RM7 should return true', () => {
    expect(service.RM7('FR0238505226134087679878798', 'FR0238505226134087679878700')).toBeTruthy();
  });

  it('RM8 should return 0 contract', () => {
    expect(service.RM8(contratMDP, 'FR6630002006530000020595G59', coordonneesBancaires).length).toEqual(0);
  });
});

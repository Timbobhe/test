import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { UploadIdentiteComponent } from './upload-identite.component';
import { Globals } from '../../../shared/utils/globals';
import { testingModule } from '../../../test/testing-module';
import { initialStateWithIdentiteNum } from '../../../test/store-states.mock';


describe('UploadIdentiteComponent', () => {
  let component: UploadIdentiteComponent;
  let fixture: ComponentFixture<UploadIdentiteComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithIdentiteNum}, {
      declarations: [UploadIdentiteComponent],
      providers: [Globals],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadIdentiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnInit } from '@angular/core';
import { GlobalState } from '../../reducers/global.state';
import { Globals } from '../../shared/utils/globals';
import { Store } from '@ngrx/store';


@Component({
  selector: 'app-identite-num',
  templateUrl: './identite-num.component.html',
  styleUrls: ['./identite-num.component.scss']
})
export class IdentiteNumComponent implements OnInit {

  etape = '';
  urlCancel: string;

  constructor(private readonly store: Store<GlobalState>,
              public globals: Globals,
              private readonly jahia: JahiaService) {
  }

  ngOnInit() {
    this.jahia.preFetchDico(['dictionnairePrevalidation']);
  }

  updateCurrentPage(event: any) {
    this.etape = event.etape;
  }
}



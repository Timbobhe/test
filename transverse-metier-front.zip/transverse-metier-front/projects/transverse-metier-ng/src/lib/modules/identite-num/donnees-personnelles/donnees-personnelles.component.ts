import { Component, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GetCoordonneesClient, UpdateCoordonneesClient } from '../../../actions/coordonnees-client.actions';
import { PushToastMessage } from '../../../actions/ui.actions';
import { CoordonneesClient } from '../../../models/client/coordonnees-client.model';
import { ImpersonationService } from '../../transverse-metier-common/services/impersonation.service';
import { IdentiteNumIntegrationComponent } from '../identite-num-integration-component';
import { GlobalState } from '../../../reducers/global.state';
import { Globals } from '../../../shared/utils/globals';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { filter, switchMap, take } from 'rxjs/operators';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';


@Component({
  selector: 'trm-donnees-personnelles',
  templateUrl: './donnees-personnelles.component.html',
  styleUrls: ['./donnees-personnelles.component.scss']
})
export class DonneesPersonnellesComponent implements OnInit, OnDestroy, IdentiteNumIntegrationComponent {
  enCours = false;
  disableBtn = false;
  enableSaveBtn = false;
  message1 = 'Le format de l\'adresse e-mail est incorrect.';
  message2 = 'Le format du numéro de téléphone portable est incorrect. ';
  messageRequired = 'Ce champ est obligatoire';
  preValidateForm: FormGroup;
  onParcoursManuscrit: () => any;

  infosClient: CoordonneesClient;

  subscriptions: Subscription[] = [];

  emailFormControl = new FormControl('', [
    Validators.pattern(this.globals.PATTERNS.email),
    Validators.required
  ]);

  telFormControl = new FormControl('', [
    Validators.pattern(this.globals.PATTERNS.phone),
    Validators.required
  ]);

  constructor(
    private readonly store: Store<GlobalState>,
    public globals: Globals,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly elRef: ElementRef,
    private readonly impersonationService: ImpersonationService,
    private readonly reduxApiService: ReduxApiService) {
  }

  ngOnInit() {
    this.preValidateForm = new FormGroup({
      emailFormControl: this.emailFormControl,
      telFormControl: this.telFormControl
    });

    this.subscriptions.push(
      this.store.select('coordonneesClient').pipe(
        filter(info => !info.isFetched),
        take(1),
        switchMap(_ => this.reduxApiService.execute(new GetCoordonneesClient()))
      ).subscribe(),

      this.store.select('coordonneesClient').pipe(
        filter(info => info.isFetched),
      ).subscribe(info => {
        this.infosClient = info.coordonnees;
        this.enCours = info.updateEncours;

        if (!this.enCours) {
          this.setFormFieldsValues();
        }

        if (info.updated === true && this.enCours === true) {
          this.store.dispatch(new PushToastMessage({
            severity: 'success',
            jahiaSummary: {dicoId: 'dictionnairePrevalidation', key: 'MSG_MODIFICATION_DONE'},
          }));
          this.disableBtn = true;
          this.enCours = false;
        }
      }));

    this.handleFormChanges();
  }

  bindClickEvent(event) {
    setTimeout(() => {
      const signManuTag = this.elRef.nativeElement.querySelector('span.signManu');
      if (signManuTag) {
        signManuTag.addEventListener('click', this.nextToSignManu.bind(this));
      }
    }, 2000);
  }

  nextToSignManu() {
    this.onParcoursManuscrit();
  }

  handleFormChanges() {
    if (!this.preValidateForm.valid && !this.preValidateForm.dirty) {
      this.disableBtn = this.preValidateForm.valid;
    }
    this.preValidateForm.valueChanges
      .subscribe((changedObj: any) => {
        this.disableBtn = this.preValidateForm.valid;
        if (this.infosClient.email !== this.emailFormControl.value || this.infosClient.telPortable !== this.telFormControl.value) {
          this.enableSaveBtn = this.preValidateForm.valid;
          this.disableBtn = false;
        }
      });
  }

  setFormFieldsValues() {
    if (this.infosClient.telPortable != null && this.infosClient.email != null) {
      this.disableBtn = true;
    }
    this.preValidateForm.get('telFormControl').setValue(this.infosClient.telPortable);
    this.preValidateForm.get('emailFormControl').setValue(this.infosClient.email);
  }

  isFieldValid(controlName: string): boolean {
    return !this.preValidateForm.get(controlName).valid && this.preValidateForm.get(controlName).touched ||
      this.preValidateForm.get(controlName).untouched;
  }

  next() {
    this.router.navigate(['../piece-identite'], {relativeTo: this.activeRoute});
  }

  modifierCoordonnees() {
    this.impersonationService.protect('Modification coordonnées', () => {
      this.enableSaveBtn = false;
      const coordonnees = {email: this.emailFormControl.value, telPortable: this.telFormControl.value};
      this.enCours = true;
      this.store.dispatch(new UpdateCoordonneesClient(coordonnees));
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  setOnParcoursManuscrit(fct: () => any) {
    this.onParcoursManuscrit = fct;
  }
}

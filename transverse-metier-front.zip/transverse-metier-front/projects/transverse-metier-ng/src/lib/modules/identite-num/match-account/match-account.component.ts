import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UpdateCoordonneesClient } from '../../../actions/coordonnees-client.actions';
import { GetIdentNumMatchAccount } from '../../../actions/ident-num-match-account.actions';
import { PushToastMessage } from '../../../actions/ui.actions';
import { CoordonneesClient } from '../../../models/client/coordonnees-client.model';
import { IdentiteNumerique } from '../../../models/client/identiteNumerique.model';
import { GlobalState } from '../../../reducers/global.state';
import { Globals } from '../../../shared/utils/globals';
import { Store } from '@ngrx/store';
import { BehaviorSubject, Subscription } from 'rxjs';
import { IdentiteNumStateService } from '../services/identite-num-state.service';
import { RedirectService } from '../../../shared/services/redirect.service';
import { ImpersonationService } from '../../transverse-metier-common/services/impersonation.service';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { filter, switchMap } from 'rxjs/operators';

@Component({
  selector: 'trm-match-account',
  templateUrl: './match-account.component.html',
  styleUrls: ['./match-account.component.scss']
})
export class MatchAccountComponent implements OnInit, OnDestroy {

  @Input() displaySignManu: boolean;
  @Output() matchAccount = new BehaviorSubject(false);
  @Output() onSignatureManuscrit = new EventEmitter();

  coordoneesContactClient: CoordonneesClient = new CoordonneesClient();
  msgDone;
  enCours = false;
  enableSaveBtn = false;
  emailErrorMessage = this.globals.ERROR_MESSAGES.email;
  phoneErrorMessage = this.globals.ERROR_MESSAGES.phone;
  messageRequired = this.globals.ERROR_MESSAGES.required;
  matchAccountForm: FormGroup;
  isMatchAccount: boolean;
  identNumMatchAccount: IdentiteNumerique;
  urlCancel: string;
  nonCorrespond = '';
  nomCorrespondAutreCompte: { NOM: string, PRENOM: string };
  subscriptions: Subscription[] = [];
  emailAg2rFormControl = new FormControl('', [
    Validators.pattern(this.globals.PATTERNS.email),
    Validators.required
  ]);
  telAg2rFormControl = new FormControl('', [
    Validators.pattern(this.globals.PATTERNS.phone),
    Validators.required
  ]);
  emailUniversignFormControl = new FormControl();
  telUniversignFormControl = new FormControl();
  private readonly lien_revocation_universign: string;

  constructor(
    private readonly redirectService: RedirectService,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly store: Store<GlobalState>,
    public globals: Globals,
    private readonly elRef: ElementRef,
    private readonly configService: ConfigService,
    public readonly identiteNumStateService: IdentiteNumStateService,
    private readonly impersonationService: ImpersonationService,
    private readonly reduxApiService: ReduxApiService) {
  }

  bindClickEvent(event) {
    setTimeout(() => {
      const signManuTag = this.elRef.nativeElement.querySelector('span.signManu');
      if (signManuTag) {
        signManuTag.addEventListener('click', this.handleSignatureManuscrit.bind(this));
      }
    }, 2000);
  }

  ngOnInit() {
    this.emailUniversignFormControl.disable();
    this.telUniversignFormControl.disable();
    this.matchAccountForm = new FormGroup({
      emailAg2rFormControl: this.emailAg2rFormControl,
      telAg2rFormControl: this.telAg2rFormControl,
      emailUniversignFormControl: this.emailUniversignFormControl,
      telUniversignFormControl: this.telUniversignFormControl,
    });

    this.subscriptions.push(this.store.select('identNumMatchAccount').pipe(
      filter(identNum => !identNum || (identNum.isFetched === false && identNum.loading === false && !identNum.error)),
      switchMap(_ => this.reduxApiService.execute(new GetIdentNumMatchAccount()))
    ).subscribe());

    this.subscriptions.push(this.store.select('identNumMatchAccount').pipe(
      filter(identNum => !!identNum.identiteNumerique)
    ).subscribe(identNum => {
      this.identNumMatchAccount = identNum.identiteNumerique;
      this.isMatchAccount = identNum.identiteNumerique.matchAccount;
      this.matchAccount.next(this.isMatchAccount && !this.enableSaveBtn);
      this.setFormFieldsValues();
      this.handleFormChanges();
      this.preventToGoToNextStepWhenValuesNull();
    }));
  }

  preventToGoToNextStepWhenValuesNull() {
    if (this.identNumMatchAccount.ag2r !== null && (this.identNumMatchAccount.ag2r.email === null
      || this.identNumMatchAccount.ag2r.telPortable === null)) {
      this.enableSaveBtn = false;
      this.matchAccount.next(false);
    }
  }

  handleFormChanges() {
    this.matchAccountForm.valueChanges
      .subscribe((changedObj: any) => {
        if (this.identNumMatchAccount.ag2r !== null && (this.identNumMatchAccount.ag2r.email !== this.emailAg2rFormControl.value
          || this.identNumMatchAccount.ag2r.telPortable !== this.telAg2rFormControl.value)) {
          this.enableSaveBtn = this.matchAccountForm.valid;
        } else {
          this.enableSaveBtn = false;
        }
        this.matchAccount.next(this.isMatchAccount && !this.enableSaveBtn && this.matchAccountForm.valid);
      });
  }

  setFormFieldsValues() {
    if (this.identNumMatchAccount.ag2r !== null) {
      this.telAg2rFormControl.setValue(this.identNumMatchAccount.ag2r.telPortable);
      this.emailAg2rFormControl.setValue(this.identNumMatchAccount.ag2r.email);
    }
    if (this.identNumMatchAccount.universign !== null) {
      this.telUniversignFormControl.setValue(this.identNumMatchAccount.universign.telPortable);
      this.emailUniversignFormControl.setValue(this.identNumMatchAccount.universign.email);
    }
    this.nonCorrespond = '';
    if (this.emailUniversignFormControl.value && this.emailUniversignFormControl.value.includes('*')) {
      this.nonCorrespond = 'Email';
    }
    if (this.telUniversignFormControl.value && this.telUniversignFormControl.value.includes('*')) {
      this.nonCorrespond += 'Tel';
    }

    this.nomCorrespondAutreCompte = null;
    if (this.identNumMatchAccount.universign &&
      (this.identNumMatchAccount.universign.nom && this.identNumMatchAccount.universign.nom.includes('*')
        || this.identNumMatchAccount.universign.prenom && this.identNumMatchAccount.universign.prenom.includes('*'))) {
      this.nomCorrespondAutreCompte = {
        NOM: this.identNumMatchAccount.universign.nom,
        PRENOM: this.identNumMatchAccount.universign.prenom
      };
      this.nonCorrespond = 'AutreCompte';
    }
  }

  isFieldValid(controlName: string): boolean {
    return (!this.matchAccountForm.get(controlName).valid && this.matchAccountForm.get(controlName).touched) ||
      (this.matchAccountForm.get(controlName).untouched);
  }

  modifierCoordonneesRelancerMatchAccount() {
    this.impersonationService.protect('', () => {
      this.enableSaveBtn = false;
      this.coordoneesContactClient = {
        email: this.emailAg2rFormControl.value,
        telPortable: this.telAg2rFormControl.value
      };
      this.enCours = true;
      const updateClientInfos = new UpdateCoordonneesClient(this.coordoneesContactClient);
      updateClientInfos.payload.onSuccess = (info => {
        if (info.result === true && this.enCours === true) {
          this.enCours = false;
          this.store.dispatch(new PushToastMessage({
            severity: 'success',
            jahiaSummary: {dicoId: 'dictionnairePrevalidation', key: 'MSG_MODIFICATION_DONE'}
          }));
        }
      });
      this.store.dispatch(updateClientInfos);
    });
  }

  reinitialiserIdentNum() {
    this.redirectService.openUrl(this.configService.config.lien_revocation_universign);
  }

  handleSignatureManuscrit() {
    this.onSignatureManuscrit.emit();
  }

  isFieldValidButHasError(field: string, errorType: string) {
    if (field === 'emailAg2rFormControl') {
      if (errorType === 'pattern') {
        return this.isFieldValid('emailAg2rFormControl') && this.emailAg2rFormControl.hasError('pattern');
      }
      if (errorType === 'required') {
        return this.isFieldValid('emailAg2rFormControl') && this.emailAg2rFormControl.hasError('required') && this.emailAg2rFormControl.dirty;
      }
    }
    if (field === 'telAg2rFormControl') {
      if (errorType === 'pattern') {
        return this.isFieldValid('telAg2rFormControl') && this.telAg2rFormControl.hasError('pattern');
      }
      if (errorType === 'required') {
        return this.isFieldValid('telAg2rFormControl') && this.telAg2rFormControl.hasError('required') && this.emailAg2rFormControl.dirty;
      }
    }
    return false;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  isNonCorrespondEmailTel() {
    return this.nonCorrespond === 'Email' || this.nonCorrespond === 'Tel' || this.nonCorrespond === 'EmailTel';
  }
}

import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PieceIdentite, SelectedPieceIdentiteAction } from '../../../actions/identite-num.actions';
import { Reponse } from '../../../models/question-responses.model';
import { IdentiteNumStateService } from '../services/identite-num-state.service';
import { GlobalState } from '../../../reducers/global.state';
import { Store } from '@ngrx/store';
import { IdentiteNumIntegrationComponent } from '../identite-num-integration-component';

@Component({
  selector: 'trm-piece-identite',
  templateUrl: './piece-identite.component.html',
  styleUrls: ['./piece-identite.component.scss']
})
export class PieceIdentiteComponent implements OnInit, IdentiteNumIntegrationComponent {
  etape = 'choixPiece';
  pieces: Reponse<PieceIdentite>[];
  onParcoursManuscrit: () => any;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly elRef: ElementRef,
    public readonly identNumStateService: IdentiteNumStateService
  ) {
    this.pieces = [
      {label: 'Carte nationale d\'identité', value: 'CIN'},
      {label: 'Passeport', value: 'PASSEPORT'}
    ];
  }

  ngOnInit() {
  }

  bindClickEvent(event) {
    setTimeout(() => {
      const signManuTag = this.elRef.nativeElement.querySelector('span.signManu');
      if (signManuTag) {
        signManuTag.addEventListener('click', this.goParcoursManuscrit.bind(this));
      }
    }, 2000);
  }

  goParcoursManuscrit() {
    this.onParcoursManuscrit();
  }

  handleSelectPiece(choix: Reponse<PieceIdentite>) {
    this.store.dispatch(new SelectedPieceIdentiteAction(choix.value));
    this.router.navigate(['../upload-piece-identite'], {relativeTo: this.activeRoute});
  }

  setOnParcoursManuscrit(fct: () => any) {
    this.onParcoursManuscrit = fct;
  }
}

import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  CreateIdentiteNumAction,
  CreateIdentitePayload,
  PrevalidatePieceIdentite
} from '../../../actions/identite-num.actions';
import { PushToastMessage } from '../../../actions/ui.actions';
import { FileUploadModel, FileUploadResponseModel } from '../../../models/client/file-upload.model';
import { IdentiteNum, PrevalidationIdentNumResult } from '../../../models/client/identite-num.model';
import { GlobalState } from '../../../reducers/global.state';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { IdentiteNumIntegrationComponent } from '../identite-num-integration-component';

@Component({
  selector: 'trm-upload-identite',
  templateUrl: './upload-identite.component.html',
  styleUrls: ['./upload-identite.component.scss']
})
export class UploadIdentiteComponent implements OnInit, OnDestroy, IdentiteNumIntegrationComponent {

  uploadTitle = 'Recto :';
  defaultMessageError = '';

  labelPieceAenvoyer = 'Carte nationale d\'identité';
  images: any = [];
  waitingOCR = false;
  disableBtn = true;
  identitePayload: CreateIdentitePayload = new CreateIdentitePayload();
  urlRetourOk: string;
  identiteNum: IdentiteNum = new IdentiteNum();
  headerText = 'Voir les exemples';

  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
              private readonly router: Router,
              private readonly jahia: JahiaService,
              private readonly activeRoute: ActivatedRoute) {
  }


  setImages(type: string) {
    let folderName = 'cni';
    if (this.identiteNum.typeDoc === 'PASSEPORT') {
      this.uploadTitle = '';
      folderName = 'pass';
      this.labelPieceAenvoyer = this.identiteNum.typeDoc;
    }
    this.images.push({imageName: 'valable.png', imageTitle: ' Correct', folderName: folderName});
    const NON_CORRECT = 'Non correct';
    this.images.push({imageName: 'masquee.png', imageTitle: NON_CORRECT, folderName: folderName});
    this.images.push({imageName: 'noir-blanc.png', imageTitle: NON_CORRECT, folderName: folderName});
    this.images.push({imageName: 'verso-masquee.png', imageTitle: NON_CORRECT, folderName: folderName});
  }

  ngOnInit() {
    this.subscriptions.push(
      this.jahia.getDicoEntry('dictionnairePrevalidation', 'OCR_REP_CODE_DEFAULT').subscribe(
        msg => this.defaultMessageError = msg.label),

      this.store.select('identiteNum').subscribe(identiteNum => {
        this.identiteNum.typeDoc = identiteNum.pieceIdentite;
        this.urlRetourOk = identiteNum.contexteAppel.urlRetourOk;
        this.identitePayload.typePieceIdentite = identiteNum.pieceIdentite;
      })
    );

    this.setImages(this.identiteNum.typeDoc);
    if (this.identiteNum.typeDoc === undefined) { // FIXME change to guard
      this.router.navigate(['../piece-identite'], {relativeTo: this.activeRoute});
    }
  }

  onFileUpload1(uploadedFile1: FileUploadResponseModel) {
    if (uploadedFile1) {
      this.changePiecesJointes(pieceJointes => pieceJointes.unshift(uploadedFile1));
      if (this.identiteNum.typeDoc === 'PASSEPORT') {
        this.dispatchFileUpload();
      } else if (this.identiteNum.pieceJointes.length === 2) {
        if (!this.sameFile()) {
          this.dispatchFileUpload();
        } else {
          this.store.dispatch(new PushToastMessage({
            severity: 'error',
            jahiaSummary: {
              dicoId: 'dictionnairePrevalidation',
              key: 'OCR_REP_CODE_6',
              defaultValue: this.defaultMessageError
            },
            detail: '',
            life: 6000
          }));
        }
      }
    }
  }

  onFileUpload2(uploadedFile2: FileUploadResponseModel) {
    if (uploadedFile2) {
      this.changePiecesJointes(pieceJointes => pieceJointes.push(uploadedFile2));
      if (this.identiteNum.pieceJointes.length === 2) {
        if (!this.sameFile()) {
          this.dispatchFileUpload();
        } else {
          this.store.dispatch(new PushToastMessage({
            severity: 'error',
            jahiaSummary: {
              dicoId: 'dictionnairePrevalidation',
              key: 'OCR_REP_CODE_6',
              defaultValue: this.defaultMessageError
            },
            detail: '',
            life: 6000
          }));
        }
      }
    }
  }

  sameFile() {
    return this.identiteNum.pieceJointes[0].fileContent.length === this.identiteNum.pieceJointes[1].fileContent.length;
  }

  dispatchFileUpload() {
    this.waitingOCR = true;
    const acn = new PrevalidatePieceIdentite(this.identiteNum);
    acn.payload.onSuccess = data => {
      this.displayMessage(data);
      if (data.codeRetour === '0') {
        this.identitePayload.cleValidation = data.idUniverSign;
        this.disableBtn = false;
      }
    };
    this.store.dispatch(acn);
  }

  displayMessage(data: PrevalidationIdentNumResult) {
    const champsMap = new Map();
    champsMap.set('dateNaissance', 'Date de naissance attendue');
    champsMap.set('Prénom', 'Prénom attendu');
    champsMap.set('Nom', 'Nom attendu');
    champsMap.set('secondlastname', 'Nom d\'usage attendu');

    const code = Number(data.codeRetour);
    const keyMessage = `OCR_REP_CODE_${data.codeRetour}`;
    let detailsOCR = '';
    if (data.details) {
      let details = [...data.details];
      details.sort((a, b) => b.informationControlee.localeCompare(a.informationControlee));
      for (const detail of details) {
        if (!detail.indicateurInformationValidee && detail.informationControlee !== 'secondlastname') {
          detailsOCR += `\n○ ${champsMap.get(detail.informationControlee) || detail.informationControlee} "${detail.valeurDocument}" au lieu de "${detail.valeurDeclaree}"`;
        }
      }
    }
    const severity = code === 0 ? 'success' : 'error';
    this.store.dispatch(new PushToastMessage({
      severity,
      jahiaSummary: {dicoId: 'dictionnairePrevalidation', key: keyMessage, defaultValue: this.defaultMessageError},
      detail: detailsOCR,
      life: 60000
    }));
    this.waitingOCR = false;
  }

  createIdentiteNum() {
    this.identitePayload.doc1 = this.identiteNum.pieceJointes[0];
    this.identitePayload.doc2 = this.identiteNum.pieceJointes[1];
    this.store.dispatch(new CreateIdentiteNumAction(this.identitePayload));
  }

  deleteFile1() {
    this.changePiecesJointes(pieceJointes => pieceJointes.shift());
  }

  deleteFile2() {
    this.changePiecesJointes(pieceJointes => pieceJointes.pop());
  }

  changePiecesJointes(operation: (pieceJointes: FileUploadModel[]) => any) {
    const pj = [...this.identiteNum.pieceJointes];
    operation(pj);
    this.identiteNum = Object.assign(new IdentiteNum(), this.identiteNum, {pieceJointes: pj});
  }

  terminate() {
    this.createIdentiteNum();
    this.router.navigate([this.urlRetourOk], {queryParamsHandling: 'preserve'});
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  updateAccordionStatus(open: boolean) {
    this.headerText = open ? 'Cacher les exemples' : 'Voir les exemples';
  }

  setOnParcoursManuscrit(fct: () => any) {
  }
}


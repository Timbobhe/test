/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { Globals } from '../../shared/utils/globals';
import { testingModule } from '../../test/testing-module';
import { initialStateWithIdentiteNum } from '../../test/store-states.mock';
import { IdentiteNumComponent } from './identite-num.component';


describe('IdentiteNumComponent', () => {
  let component: IdentiteNumComponent;
  let fixture: ComponentFixture<IdentiteNumComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithIdentiteNum}, {
      declarations: [IdentiteNumComponent],
      providers: [Globals],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IdentiteNumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

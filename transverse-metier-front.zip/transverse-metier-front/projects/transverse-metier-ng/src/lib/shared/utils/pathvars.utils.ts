export interface FlatVarsPath {
  rxPath: RegExp;
  vars?: any;
}

export interface VarsPathData {
  path: string;
  vars?: any;
  children?: VarsPathData[];
}

class VarsPath implements VarsPathData {
  path: string;
  vars?: any;
  children?: VarsPath[];

  static fromObject(object: VarsPathData) {
    const res = new VarsPath();
    Object.assign(res, object);
    res.children = [];
    if (object.children) {
      object.children.forEach((c: VarsPathData) => res.children.push(VarsPath.fromObject(c)));
    }
    return res;
  }

  flatten(res: FlatVarsPath[] = [], parent: VarsPath = null): FlatVarsPath[] {
    if (parent) {
      res.push({ rxPath: new RegExp(`${parent.path}/.*${this.path}`), vars: this.vars });
    } else {
      res.push({ rxPath: new RegExp(this.path), vars: this.vars });
    }
    this.children.forEach(child => child.flatten(res, this));

    return res;
  }

}

export const compile = (config: VarsPathData[]): FlatVarsPath[] => {
  const res: FlatVarsPath[] = [];
  config.forEach(e => VarsPath.fromObject(e).flatten(res));
  return res;
};


export const findVars = (path: string, config: FlatVarsPath[]): any => {
  const target = {};
  config.forEach(e => {
    if (path.match(e.rxPath) && e.vars) {
      Object.assign(target, e.vars);
    }
  });

  return target;
};






export function isNotNullOrEmptyString(o: any): boolean {
  if (typeof o === 'string') {
    o = o.trim();
  }
  return o !== null && o !== '';
}


export function isBlank(o: any): boolean {
  return !isNotNullOrEmptyString(o);
}

export function isNotBlank(o: any): boolean {
  return isNotNullOrEmptyString(o);
}

export function forEachEntry(object, cb: (key: any, value: any) => any) {
  for (const key in object) {
    if (object.hasOwnProperty(key)) {
      const value = object[key];
      cb(key, value);
    }
  }
}

export function replaceAt(str: string, index: number, replacement: string): string {
  return str.substr(0, index) + replacement + str.substr(index + replacement.length);
}


export function compareNumber(a: number, b: number) {
  if (a === b) {
    return 0;
  }
  if (a < b) {
    return -1;
  }
  return 1;
}


export function arrayEquals(a: Array<any>, b: Array<any>): boolean {
  if (a.length !== b.length) {
    return false;
  }

  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) {
      return false;
    }
  }

  return true;
}

export function containsAll<T = any>(source: Set<T>, search: Array<T>): boolean {
  for (const e of search) {
    if (!source.has(e)) {
      return false;
    }
  }
  return true;
}

export function arrayContainsAll<T = any>(source: Array<T>, search: Array<T>): boolean {
  for (const e of search) {
    if (!source.includes(e)) {
      return false;
    }
  }
  return true;
}

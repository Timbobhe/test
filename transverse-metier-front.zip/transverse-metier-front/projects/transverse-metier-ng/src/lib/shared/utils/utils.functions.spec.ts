import { arrayContainsAll, arrayEquals, compareNumber } from './utils.functions';

describe('utils.functions', () => {

  it('should compareNumber', () => {
    expect(compareNumber(1, 1)).toEqual(0);
    expect(compareNumber(0, 1)).toEqual(-1);
    expect(compareNumber(1, 0)).toEqual(1);
  });

  it('should arrayEquals', () => {
    expect(arrayEquals([1], [1])).toBeTruthy();
    expect(arrayEquals([1], [2])).toBeFalsy();
    expect(arrayEquals([1, 2, 3], [2])).toBeFalsy();
  });

  it('should arrayContainsAll', () => {
    expect(arrayContainsAll([1, 2, 3], [1])).toBeTruthy();
    expect(arrayContainsAll([1, 2, 3], [1, 2, 3])).toBeTruthy();
    expect(arrayContainsAll([1, 2, 3], [1, 2, 3, 4, 5])).toBeFalsy();
    expect(arrayContainsAll([1, 2, 3], [4, 5, 6])).toBeFalsy();
  });

});

const MAX_FRAME = 5;
const SRC_ATTR = 'src';
const DOWNLOAD_FRAME = 'download-frames';

let frameIndex: number;

export function downloadDocument(link: string) {
  let iframe: HTMLIFrameElement = document.createElement('iframe');
  const framesContainer: HTMLElement = document.getElementById(DOWNLOAD_FRAME);

  if (framesContainer.childElementCount < MAX_FRAME) {
    framesContainer.appendChild(iframe);
  } else {
    iframe = <HTMLIFrameElement>framesContainer.childNodes.item(frameIndex);
  }

  iframe.setAttribute(SRC_ATTR, link);
  frameIndex = ++frameIndex % MAX_FRAME;
}

/**
 * Permet d'ouvrir/télécharger un fichier à partir de son contenu encodé en Base64
 *
 * @param fileContent contenu du fichier en base64
 * @param fileName Nom du fichier
 * @param download true pour télécharger le fichier; false pour l'ouvrir uniquement
 *
 * https://stackoverflow.com/questions/16245767/creating-a-blob-from-a-base64-string-in-javascript
 */
export function fileContentDownload(fileContent, fileName = 'fichier.pdf', download = false) {
  const type = 'application/pdf';
  let blob;
  if (typeof fileContent === 'string') {
    const byteCharacters = atob(fileContent);

    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);

     blob = new Blob([byteArray], { type });
  } else {
    blob = new Blob([fileContent], { type });
  }

   // IE doesn't allow using a blob object directly as link href
   // instead it is necessary to use msSaveOrOpenBlob
   if (window.navigator && window.navigator.msSaveOrOpenBlob) {
     window.navigator.msSaveOrOpenBlob(blob, fileName);
     return;
   }

  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.target = '_blank';
  link.href = url;
  if (download) {
    fileName = fileName || 'fichier.pdf';
    if (!fileName.endsWith('.pdf')) {
      fileName += '.pdf';
    }
    link.setAttribute('download', fileName);
  }
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

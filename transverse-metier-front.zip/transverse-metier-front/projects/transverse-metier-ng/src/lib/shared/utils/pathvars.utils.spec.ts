import { compile, findVars } from './pathvars.utils';


describe('pathvars', () => {

  const TC_VARS = compile([
    {
      path: '/synthese-des-comptes',
      vars: {
        env_template: 'synthese-des-comptes',
        client_profil: 'particuliers'
      }
    },
    {
      path: '/accueil',
      vars: {
        form_profil: 'particuliers',
        env_template: 'onboarding',
      },
      children: [
        {
          path: 'beneficiaires',
          vars: {
            form_step: 'beneficiaires'
          }
        },
        {
          path: 'gestion-financiere',
          vars: {
            form_step: 'beneficiaires'
          }
        },
        {
          path: 'objectifs',
          vars: {
            form_step: 'objectifs'
          }
        },
      ]
    },
  ]);

  it('compile Data', () => {
    expect(TC_VARS).toBeTruthy();
    expect(TC_VARS.length).toEqual(5);
  });

  it('find Data /synthese-des-comptes', () => {
    const vars = findVars('/synthese-des-comptes', TC_VARS);
    expect(vars.env_template).toEqual('synthese-des-comptes');
    expect(vars.client_profil).toEqual('particuliers');
  });


  it('find Data /accueil/configurer-votre-espace/gestion-financiere', () => {
    const vars = findVars('/accueil/configurer-votre-espace/gestion-financiere', TC_VARS);
    expect(vars.form_step).toEqual('beneficiaires');
  });

});

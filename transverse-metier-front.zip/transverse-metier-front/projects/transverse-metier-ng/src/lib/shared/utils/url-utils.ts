import { Injectable } from '@angular/core';
import { Params } from '@angular/router';
import { forEachEntry } from './utils.functions';

export function getSearchParam(parameter: string) {
  const params = getSearchParams();
  return params[parameter];
}

export function getHashParam(parameter: string) {
  const params = getHashParams();
  return params[parameter];
}

/**
 * http://localhost:4200/?frame&fdi=5151#/modification-gestion-financiere/ma-demande
 */
export function getSearchParams() {
  return queryStringToObject(window.location.search);
}

/**
 * http://localhost:4200/?frame#/modification-gestion-financiere/ma-demande?type=stock&onglet=RG152223361
 */
export function getHashParams() {
  return queryStringToObject(window.location.hash);
}


export function queryStringToObject(qs: string): Params {
  const res = {};
  let line = qs;
  const starting = qs.indexOf('?');
  if (starting >= 0) {
    line = qs.substring(starting + 1);
  }
  if (line.length > 0) {
    line.split('&').map(couple => couple.split('='))
      .map(ary => {
        const k = ary[0];
        const v = ary[1];
        return res[k] = v || true;
      });
  }

  return res;
}

export function setSearchParam(parameter: string, value: string) {
  if (getSearchParam('frame') == null) {
    window.location.search = `?${parameter}=${value}`;
  } else {
    window.location.search = `?frame&${parameter}=${value}`;
  }
}

export function deleteSearchParam(parameter: string) {
  const param = window.location.search;
  const isParamFound = param.match(parameter);
  if (isParamFound) {
    window.location.search = '';
  }
}

export function paramsToQueryString(params: Params, startWithInterrogation = true) {
  if (!params) {
    return null;
  }
  const qs = [];
  forEachEntry(params, ((key, value) => qs.push(`${key}=${value}`)));
  if (qs.length > 0) {
    const s = qs.join('&');
    return startWithInterrogation ? `?${s}` : s;
  }
  return '';
}

export const UrlUtils = {
  getSearchParam: getSearchParam,
  getHashParam: getHashParam,
  getSearchParams: getSearchParams,
  getHashParams: getHashParams,
  queryStringToObject: queryStringToObject,
  setSearchParam: setSearchParam,
  deleteSearchParam: deleteSearchParam,
  paramsToQueryString: paramsToQueryString
};


@Injectable({
  providedIn: 'root'
})
export class UrlService {
  get isFrame(): boolean {
    return !!getSearchParam('frame');
  }
}


export function setCssVariable(variableName: string, value: string) {
  document.querySelector('body').style.setProperty(variableName, value);
}
export function getCssVariable(variableName: string) {
  return document.querySelector('body').style.getPropertyValue(variableName);
}

/**
 * Format une URL pour CSS
 *
 * @param url
 * @return `url(${url})`;
 */
export function formatUrl(url: string): string {
  return `url(${url})`;
}

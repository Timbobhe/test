import { Component, forwardRef, Input, OnInit } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { noop } from 'rxjs';

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    // tslint:disable-next-line: no-use-before-declare
    useExisting: forwardRef(() => ButtonRadioComponent),
    multi: true
};

@Component({
    selector: 'trm-button-radio',
    templateUrl: './button-radio.component.html',
    styleUrls: ['./button-radio.component.scss'],
    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})

export class ButtonRadioComponent implements ControlValueAccessor, OnInit {
    @Input('value') val = false;

    private propagateChange: () => void = noop;
    private propagateTouch: (_: any) => void = noop;
    onChange: any = () => {
    };
    ontouched: any = () => {
    };

    constructor() {
    }

    ngOnInit() {
    }

    get value(): any {
        return this.val;
    }

    set value(v: any) {
        this.val = v;
        this.onChange(v);
        this.ontouched();
    }

    writeValue(obj: any): void {
        this.val = obj;
    }

    registerOnChange(fn: any): void {
        this.onChange = fn;
        this.propagateChange = fn;
    }

    registerOnTouched(fn: any): void {
        this.ontouched = fn;
        this.propagateTouch = fn;
    }

    setDisabledState?(isDisabled: boolean): void {
    }
}

import { SimpleChange } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ResponsiveService } from '../../services/responsive.service';
import { StepperComponent } from './stepper.component';

function configureTestBed(): void {
  TestBed.configureTestingModule({
    declarations: [StepperComponent],
    providers: [ResponsiveService]
  })
    .compileComponents();
}

describe('StepperComponent', () => {
  let component: StepperComponent;
  let fixture: ComponentFixture<StepperComponent>;

  beforeEach(waitForAsync(() => {
    configureTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepperComponent);
    component = fixture.componentInstance;
    component.variant = 'mini';
    component.steps = [{label: 'Step 0'}, {label: 'Step 1'}, {label: 'Step 2'}];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contains 3 steps', () => {
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(pieces.length).toEqual(3);
    expect(component.currentStepIndex).toEqual(0);
  });

  it('should select step 1', () => {
    component.currentStepIndex = 1;
    fixture.detectChanges();

    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });

  it('should next step', () => {
    component.currentStepIndex = 0;
    component.stepChanged.subscribe(step => {
      expect(step.index).toEqual(1);
    });
    fixture.detectChanges();
    component.next();
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(1);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });

  it('should previous step', () => {
    component.currentStepIndex = 2;
    component.stepChanged.subscribe(step => {
      expect(step.index).toEqual(1);
    });
    fixture.detectChanges();
    component.previous();
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(1);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });


  it('should goTo step', waitForAsync(() => {
    component.currentStepIndex = 2;
    component.stepChanged.subscribe(step => {
      expect(step.index).toEqual(1);
    });
    fixture.detectChanges();
    component.goToStep(1);
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(1);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  }));

  it('should no-goTo step', () => {
    component.currentStepIndex = 0;
    fixture.detectChanges();
    component.goToStep(1);
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(0);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-disabled');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });


  it('should no-next step', () => {
    component.currentStepIndex = 2;
    fixture.detectChanges();
    component.next();
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(2);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-is-current');
  });

  it('should no-prev step', () => {
    component.currentStepIndex = 0;
    fixture.detectChanges();
    component.previous();
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(0);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-disabled');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });

  it('should setCurrentStepIndex', () => {
    component.setCurrentStepIndex(1);
    fixture.detectChanges();
    expect(component.currentStepIndex).toEqual(1);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-is-current');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-disabled');
  });

  it('should not setCurrentStepIndex', () => {
    expect(function () {
      component.setCurrentStepIndex(-1);
    }).toThrowError('-1 is an invalid step index.');
  });

  it('should detect changes on currentStepIndex', () => {
    component.currentStepIndex = 2;
    component.ngOnChanges({
      currentStepIndex: new SimpleChange(1, component.currentStepIndex, false)
    });
    fixture.detectChanges();
    expect(component.currentStepIndex).toEqual(2);
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(Object.keys(pieces[0].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[1].classes)).toContain('trm-stepper-level-item-enabled');
    expect(Object.keys(pieces[2].classes)).toContain('trm-stepper-level-item-is-current');
  });

  it('should not detect changes on currentStepIndex', () => {
    component.currentStepIndex = 20;
    expect(function () {
      component.ngOnChanges({
        currentStepIndex: new SimpleChange(1, component.currentStepIndex, false)
      });
      fixture.detectChanges();
    }).toThrowError('20 is an invalid step index.');
  });

  it('should detect changes on totalSteps', () => {
    component.totalSteps = 8;
    component.ngOnChanges({
      totalSteps: new SimpleChange(null, component.totalSteps, true)
    });
    fixture.detectChanges();
    expect(component.totalSteps).toEqual(8);
  });

  it('should create stepper with totalSteps', () => {
    TestBed.resetTestingModule();
    configureTestBed();
    fixture = TestBed.createComponent(StepperComponent);
    component = fixture.componentInstance;
    component.variant = 'mini';
    component.totalSteps = 5;
    fixture.detectChanges();
    const element = fixture.debugElement;
    const pieces = element.queryAll(By.css('.trm-stepper-level-item-mini'));
    expect(pieces.length).toEqual(5);
    expect(component.currentStepIndex).toEqual(0);
  });
});

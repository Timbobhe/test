import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { DeviceSize, ResponsiveService } from '../../services/responsive.service';

@Component({
  selector: 'trm-soustitre-bar',
  templateUrl: './soustitre-bar.component.html',
  styleUrls: ['./soustitre-bar.component.scss']
})
export class SoustitreBarComponent implements OnInit {
  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = responsiveService.onResize$;
  }

  ngOnInit() {
  }

}

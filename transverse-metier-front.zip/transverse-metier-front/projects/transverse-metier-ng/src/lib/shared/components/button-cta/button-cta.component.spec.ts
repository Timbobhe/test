/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Button, ButtonModule } from 'primeng/button';
import { testingModule } from '../../../test/testing-module';
import { ButtonCtaComponent } from './button-cta.component';


describe('ButtonCtaComponent', () => {
  let componentPrincipal: ButtonCtaComponent;
  let fixturePrincipal: ComponentFixture<ButtonCtaComponent>;
  let componentSecondaire: ButtonCtaComponent;
  let fixtureSecondaire: ComponentFixture<ButtonCtaComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      imports: [ButtonModule],
      declarations: [ButtonCtaComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixturePrincipal = TestBed.createComponent(ButtonCtaComponent);
    componentPrincipal = fixturePrincipal.componentInstance;
    componentPrincipal.text = 'texte';
    componentPrincipal.isCtaPrincipal = true;
    fixturePrincipal.detectChanges();

    fixtureSecondaire = TestBed.createComponent(ButtonCtaComponent);
    componentSecondaire = fixtureSecondaire.componentInstance;
    componentSecondaire.text = 'texte';
    componentSecondaire.isCtaPrincipal = false;
    fixtureSecondaire.detectChanges();
  });

  it('should create ButtonCtaComponent principal', () => {
    expect(componentPrincipal).toBeTruthy();
    const element: DebugElement = fixturePrincipal.debugElement;
    const button = element.query(By.directive(Button));
    expect(button.nativeElement.firstElementChild.classList.contains('btn-primary')).toBe(true);
  });

  it('should create ButtonCtaComponent secondaire', () => {
    expect(componentSecondaire).toBeTruthy();
    const element: DebugElement = fixtureSecondaire.debugElement;
    const button = element.query(By.directive(Button));
    expect(button.nativeElement.firstElementChild.classList.contains('btn-secondary')).toBe(true);
  });
});

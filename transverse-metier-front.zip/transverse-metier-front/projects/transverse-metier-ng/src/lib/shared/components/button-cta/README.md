# Description

Composant d'un bouton CTA (principal, secondaire ou inactif) respectant la charte internet 2018.

Le bouton affiche soit du texte en dur avec la propriete text, ou alors une entree d'un dictionnaire Jahia avec les proprietes jahiaTitle et jahiaKey

**Attention !** L'action du click sur le bouton n'est pas gérée par ce composant mais plutôt par le composant qui parent via *clickAction*.

**Attention !** Ne pas utiliser en meme temps le parametre text avec les parametres jahiaTitle et jahiaKey

## Inputs

| **Paramètre**  | **Type**  | **Description** | **Valeur par défaut** |
| --------- |-----| -----------| --------------|
| **text** | string | Le texte du bouton donné en dur | |
| **jahiaTitle** | string | Le nom du dictionnaire Jahia | |
| **jahiaKey** | string | La clé d'une entrée du dictionnaire Jahia | |
| **isCtaPrincipal** | boolean | Pour afficher un bouton principal ou un secondaire| |
| **disabled** | boolean | Pour désactiver le bouton| false |

## Exemples d'utilisation

* ### CTA principal simple

```html
<app-button-cta text="CTA principal" [isCtaPrincipal]=true></app-button-cta>
```

* ### CTA principal avec Jahia

```html
<app-button-cta jahiaTitle="xxx" jahiaKey="yyy" [isCtaPrincipal]=true></app-button-cta>
```

* ### CTA secondaire

```html
<app-button-cta text="CTA secondaire" [isCtaPrincipal]=false></app-button-cta>
```

* ### Bouton inactif

```html
<app-button-cta text="Inactif" [disabled]=true></app-button-cta>
```

* ### Bouton avec action clic

```html
<app-button-cta text="bouton avec action de clic" (clickAction)="goToUrl()" [isCtaPrincipal]=true></app-button-cta>
```

* ### Bouton avec icône et position d'icône

```html
<app-button-cta text="Bouton avec icône et position d'icône" icon="pi pi-chevron-right" iconPosition="right" 
(clickAction)="goToUrl()" [isCtaPrincipal]=true></app-button-cta>
```

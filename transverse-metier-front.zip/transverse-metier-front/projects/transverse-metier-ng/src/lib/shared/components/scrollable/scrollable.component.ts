import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'trm-scrollable',
  templateUrl: './scrollable.component.html',
  styleUrls: ['./scrollable.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ScrollableComponent implements OnInit {

  @Input() isScrollVisible = true;
  @Input() styleHeight = '250';

  constructor() {}

  ngOnInit() {}
}

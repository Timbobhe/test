import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'trm-button-yes-no',
  templateUrl: './button-yes-no.component.html',
  styleUrls: ['./button-yes-no.component.scss']
})
export class ButtonYesNoComponent implements OnInit {

  @Output() onChanged = new EventEmitter<boolean>();
  @Input()
  isYes = false;

  constructor() { }

  ngOnInit() {
  }

  selected(isYes: boolean) {
    this.isYes = isYes;
    this.onChanged.emit(this.isYes);
  }

}

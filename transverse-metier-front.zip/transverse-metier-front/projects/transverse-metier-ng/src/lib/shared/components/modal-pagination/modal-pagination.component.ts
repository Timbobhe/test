import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

export interface StepPagination {
  index?: number; // calculer selon index dans le tableau
  label: string;
}

@Component({
  selector: 'trm-modal-pagination',
  templateUrl: './modal-pagination.component.html',
  styleUrls: ['./modal-pagination.component.scss']
})
export class ModalPaginationComponent implements OnInit, OnChanges {

  @Input() steps: Array<StepPagination> = [];

  @Input() totalSteps: number;

  @Output() stepChanged = new EventEmitter<StepPagination>();

  @Input() currentStepIndex = 0;
  lastStepIndex = 0;

  constructor() {
  }

  ngOnInit() {
    if (this.steps.length !== 0) {
      this.lastStepIndex = this.steps.length - 1;
    } else if (this.totalSteps) {
      this.steps = [];
      this.lastStepIndex = this.totalSteps - 1;
      for (let i = 0; i < this.totalSteps; i++) {
        this.steps.push({ label: 'Etape ' + (i) });
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.steps) {
      this.lastStepIndex = this.steps.length - 1;
    } else if (changes.totalSteps) {
      this.totalSteps = changes.totalSteps.currentValue;
      this.lastStepIndex = this.totalSteps - 1;
      this.steps = [];
      for (let i = 0; i < this.totalSteps; i++) {
        this.steps.push({ label: 'Etape ' + (i + 1) });
      }
    }

    if (changes.currentStepIndex) {
      const originalValue = changes.currentStepIndex.previousValue;
      const valueAfterChange = changes.currentStepIndex.currentValue;
      if (valueAfterChange < 0 || (this.lastStepIndex && valueAfterChange > this.lastStepIndex)) {
        this.currentStepIndex = originalValue;
        throw new Error(`${valueAfterChange} is an invalid step index.`);
      }
      this.notifyStepChange(this.currentStepIndex);
    }
  }

  setCurrentStepIndex(newIndex: number) {
    if (newIndex < 0 || (this.lastStepIndex && newIndex > this.lastStepIndex)) {
      throw new Error(`${newIndex} is an invalid step index.`);
    }
    this.currentStepIndex = newIndex;
    this.notifyStepChange(newIndex);
  }

  next() {
    if (this.currentStepIndex + 1 <= this.lastStepIndex) {
      this.currentStepIndex++;
      this.notifyStepChange(this.currentStepIndex);
    }
  }
  previous() {
    if (this.currentStepIndex - 1 >= 0) {
      this.currentStepIndex--;
      this.notifyStepChange(this.currentStepIndex);
    }
  }

  notifyStepChange(currentStepIndex: number) {
    const step = this.steps[currentStepIndex]; // the object that represents the step
    this.stepChanged.emit({ ...step, index: currentStepIndex });
  }

  goToStep(stepIndex: number) {
    if (stepIndex !== this.currentStepIndex) {
      this.currentStepIndex = +stepIndex;
      const step = this.steps[this.currentStepIndex]; // the object that represents the step
      this.stepChanged.emit({ ...step, index: this.currentStepIndex });
    }
  }
}

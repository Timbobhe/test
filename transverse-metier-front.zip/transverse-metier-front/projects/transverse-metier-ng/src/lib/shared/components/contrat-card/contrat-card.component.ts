import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { MiniContrat } from '../../../models';
import { DeviceSize, ResponsiveService } from '../../services/responsive.service';

@Component({
  selector: 'trm-contrat-card',
  templateUrl: './contrat-card.component.html',
  styleUrls: ['./contrat-card.component.scss']
})
export class ContratCardComponent implements OnInit {

  @Input() nbContractsToShow: number;
  @Input() contrat: MiniContrat;
  @Input() bloque: boolean;
  @Input() raisonBlocageDicoEntry: string;
  @Input() dicoId: string;
  @Output() contratSelected = new EventEmitter<MiniContrat>();
  onResize$: Observable<DeviceSize>;
  constructor(private readonly responsive: ResponsiveService) {
    this.onResize$ = this.responsive.onResize$; }

  ngOnInit(): void {
  }

  selectContrat(info: MiniContrat) {
    this.contratSelected.emit(info);
  }

}

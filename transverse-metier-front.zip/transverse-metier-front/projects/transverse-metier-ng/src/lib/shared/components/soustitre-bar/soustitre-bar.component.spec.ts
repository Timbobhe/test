import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoustitreBarComponent } from './soustitre-bar.component';
import { ResponsiveService } from '../../services/responsive.service';

describe('SoustitreBarComponent', () => {
  let component: SoustitreBarComponent;
  let fixture: ComponentFixture<SoustitreBarComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SoustitreBarComponent ],
      providers: [ResponsiveService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoustitreBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

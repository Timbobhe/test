import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'trm-input-slider',
  templateUrl: './input-slider.component.html',
  styleUrls: ['./input-slider.component.scss']
})
export class InputSliderComponent implements OnInit {

  @Output() onChecked = new EventEmitter<boolean>();
  @Input() checked = false;

  constructor() { }

  ngOnInit() {
  }

  updateCheckStatus(event: any) {
    this.onChecked.emit(event.checked);
  }

  reset() {
    this.checked = false;
    this.onChecked.emit(this.checked);
  }
}

/* tslint:disable:no-unused-variable */
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BackendService } from '../../services/backend/backend.service';
import { StoreModule } from '@ngrx/store';
import * as fromRoot from '../../../reducers/global.state';
import { FileUploadResponseModel } from '../../../models/client/file-upload.model';
import { CustomUploadComponent } from './custom-upload.component';

describe('CustomUploadComponent', () => {
  let component: CustomUploadComponent;
  let fixture: ComponentFixture<CustomUploadComponent>;
  const mockBackEndService = {};

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, StoreModule.forRoot(fromRoot.reducers)],
      providers: [{provide: BackendService, useValue: mockBackEndService}],
      declarations: [CustomUploadComponent,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create event', () => {
    const input = fixture.debugElement.query(By.css('input[type=file]')).nativeElement;
    spyOn(component, 'onFileSelect');
    input.dispatchEvent(new Event('change'));
    expect(component.onFileSelect).toHaveBeenCalled();
  });

  it('should delete file', () => {
    component.uploadedFiles = [
      {fileName: 'image.png', fileContent: 'content', state: 'ok', errorTag: null}
    ];

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      const comp = fixture.componentInstance;
      spyOn(comp, 'onFileDelete');
      const el = fixture.debugElement.query(By.css('span')).nativeElement.click();
      expect(comp.onFileDelete).toHaveBeenCalled();
    });
  });

  it('should display an error due to the extension', () => {
    component = fixture.componentInstance;
    // @ts-ignore
    component.selectedFile = {
      name: 'image.png',
      lastModified: null,
      size: 155,
      type: 'image/png',
      slice: null
    };
    expect(component.frontChecksFileUploaded()).toBe(true);
  });

  it('should display an error due to the filename', () => {
    component = fixture.componentInstance;
    // @ts-ignore
    component.selectedFile = {
      name: '',
      lastModified: null,
      size: 155,
      type: 'image/png',
      slice: null
    };
    expect(component.frontChecksFileUploaded()).toBe(false);
    // @ts-ignore
    component.selectedFile = {
      name: null,
      lastModified: null,
      size: 0,
      type: 'image/png',
      slice: null
    };
    expect(component.frontChecksFileUploaded()).toBe(false);
  });

  it('should display an error due to the size', () => {
    component = fixture.componentInstance;
    // @ts-ignore
    component.selectedFile = {
      name: '',
      lastModified: null,
      size: 2097900,
      type: 'image/png',
      slice: null
    };
    expect(component.frontChecksFileUploaded()).toBe(false);
  });

  it('should upload the file', () => {
    component = fixture.componentInstance;
    // @ts-ignore
    component.selectedFile = {
      name: 'image.png',
      lastModified: null,
      size: 200,
      type: 'image/png',
      slice: null
    };
    expect(component.frontChecksFileUploaded()).toBe(true);
  });

  it('should test onFileUploadRetourBack', () => {
    component = fixture.componentInstance;
    const response: FileUploadResponseModel = {
      fileName: 'image.png',
      fileContent: 'content',
      state: 'OK',
      errorTag: '',
    };
    const prevLength = component.uploadedFiles.length;
    component.onFileUploadRetourBack(response);
    fixture.detectChanges();
    expect(component.uploadedFiles.length).toBeGreaterThanOrEqual(prevLength);
  });

  it('should display delete file', () => {
    component = fixture.componentInstance;
    component.uploadedFiles = [{
      fileName: 'image.png',
      fileContent: 'content',
      state: 'OK',
      errorTag: '',
    }];
    const prevLength = component.uploadedFiles.length;
    component.onFileDelete(0);
    fixture.detectChanges();
    expect(component.uploadedFiles.length).toBeLessThan(prevLength);
  });
});

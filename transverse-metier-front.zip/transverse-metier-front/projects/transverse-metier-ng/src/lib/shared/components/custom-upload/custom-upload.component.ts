import { HttpEvent, HttpEventType } from '@angular/common/http';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { ERROR_CODE, ERROR_LEVEL, ErrorCode } from '../../../consts';
import { CustomUploadState, PJ_TAILLE_MAX, TYPES_AUTORISES } from '../../../consts';
import { BackErrorModel } from '../../../models';
import { FileUploadModel, FileUploadResponseModel } from '../../../models';
import { BackendService } from '../../services/backend/backend.service';
import { fileContentDownload } from '../../utils/download-utils';
import { isNotNullOrEmptyString } from '../../utils/utils.functions';

@Component({
  selector: 'trm-custom-upload',
  templateUrl: './custom-upload.component.html',
  styleUrls: ['./custom-upload.component.scss']
})
export class CustomUploadComponent implements OnChanges {

  @Input() requiredFormat = 'pdf, jpg, png';
  @Input() title: string;

  @Input() maxSize = 'none';
  @Input() maxFiles = 1;

  @Input() idButtonUpload = Math.random();

  @Input() textInBackground = 'Joindre un fichier';
  @Output() uploadedFileOutput = new EventEmitter<FileUploadResponseModel>();

  @Output() uploadedFilesOutput = new EventEmitter<FileUploadResponseModel[]>();
  @Output() deletedFileOutput = new EventEmitter<FileUploadResponseModel>();
  @Output() changeState = new EventEmitter<CustomUploadState>();
  @Input() oneFileBehaviour = false;

  files: any = [];
  nombreCaracteresMaxAffiches = 13;
  progress = 0;
  selectedFile: File = null;

  _compState: CustomUploadState = CustomUploadState.EMPTY;
  UploadListState = CustomUploadState;

  uploadedFiles: FileUploadResponseModel[] = [];

  // fileUploaded: FileUploadResponseModel;

  msgErrorUpload = '';

  constructor(private readonly bs: BackendService) {
  }

  get compState() {
    return this._compState;
  }

  set compState(state) {
    this._compState = state;
    this.changeState.emit(this._compState);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.onSuccessAction) {
      this.compState = CustomUploadState.EMPTY;
    }
  }

  onFileSelect(e: any): void {
    const files = e.dataTransfer ? e.dataTransfer.files : e.target.files;
    this.selectedFile = files[0];
    const formData = new FormData();

    if (this.frontChecksFileUploaded()) {
      formData.append('file', this.selectedFile);
      this.bs.uploadJustif(formData).subscribe(
        (event: HttpEvent<FileUploadResponseModel>) => {
          switch (event.type) {
            case HttpEventType.Response:
              this.onFileUploadRetourBack(event.body);
              break;
            case HttpEventType.UploadProgress:
              this.compState = CustomUploadState.UPLOADING;
              this.progress = Math.round((event['loaded'] * 100) / event['total']);
              break;
          }
        },
        backError => {
          console.log(backError);
          const error: BackErrorModel = backError.error;
          this.onFileUploadFailure(error);
        }
      );
    }
  }

  frontChecksFileUploaded(): boolean {
    let error: BackErrorModel;
    if (!isNotNullOrEmptyString(this.selectedFile.name) || this.selectedFile.size === 0) {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE.PJ_NULL_OR_EMPTY, ['']);
      this.onFileUploadFailure(error);
      return false;
    }
    if (!this.oneFileBehaviour && this.uploadedFiles.find(e => e.fileName === this.selectedFile.name)) {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE.PJ_DOUBLON_FILE, ['']);
      this.onFileUploadFailure(error);
      return false;
    }
    if (this.selectedFile.size >= PJ_TAILLE_MAX) {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE.PJ_TAILLE_KO, ['']);
      this.onFileUploadFailure(error);
      return false;
    }
    if (!this.isTypeAutorise(this.selectedFile.type)) {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE.PJ_EXTENSION_KO, ['']);
      this.onFileUploadFailure(error);
      return false;
    }
    return true;
  }

  onFileUploadRetourBack(body: FileUploadResponseModel) {
    let error: BackErrorModel;
    if (body.state !== 'OK') {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE[body.errorTag], ['']);
      this.onFileUploadFailure(error);
    } else if (!this.oneFileBehaviour && this.uploadedFiles.find(e => this.sameFile(e, body))) {
      error = new BackErrorModel(
        ERROR_LEVEL.BUSINESS_ERROR, ERROR_CODE.PJ_DOUBLON_FILE, ['']);
      this.onFileUploadFailure(error);
      return false;
    } else {
      this.compState = CustomUploadState.SUCCESS;
      this.progress = 0;
      const fileUploaded = body;
      if (!this.oneFileBehaviour) {
        this.uploadedFiles.push(fileUploaded);
        this.uploadedFilesOutput.emit(this.uploadedFiles);
      }
      this.uploadedFileOutput.emit(fileUploaded);
      console.log('Uploaded file', fileUploaded);
    }
  }

  onFileUploadFailure(error: BackErrorModel) {
    const codeError = error.errorCode;
    this.msgErrorUpload = this.getMessageByErrorCode(codeError);
    this.progress = 0;
    this.compState = CustomUploadState.ERROR;
  }

  onFileDelete(fileIndex: number): void {
    const deletedFile = this.uploadedFiles.find((e, index) => index === fileIndex);
    this.uploadedFiles = this.uploadedFiles.filter((e, index) => index !== fileIndex);
    this.uploadedFileOutput.emit(this.uploadedFiles.length >= 0 ? this.uploadedFiles[0] : null);
    this.uploadedFilesOutput.emit(this.uploadedFiles);
    this.deletedFileOutput.emit(deletedFile);
    this.compState = CustomUploadState.EMPTY;
  }

  getMessageByErrorCode(errCode: string): string {
    if (errCode) {
      return ErrorCode.has(errCode) ? ErrorCode.get(errCode) : 'Une erreur est survenue, merci de réessayer';
    } else {
      return 'Une erreur est survenue, merci de réessayer';
    }
  }

  isTypeAutorise(typeEntier: string): boolean {
    const type: string = typeEntier.split('/')[1];
    return TYPES_AUTORISES.indexOf(type) !== -1;
  }

  fileDownload(file: FileUploadModel) {
    fileContentDownload(file.fileContent, file.fileName);
  }

  appendFile(): boolean {
    return this.uploadedFiles.length < this.maxFiles || this.oneFileBehaviour;
  }

  cancel() {
    this.msgErrorUpload = '';
    this.progress = 0;
    this.compState = CustomUploadState.EMPTY;
  }

  private sameFile(e: FileUploadResponseModel, body: FileUploadResponseModel) {
    if (e.fileContent.length === body.fileContent.length) {
      return e.fileContent.startsWith(body.fileContent.slice(0, Math.min(1000, body.fileContent.length)));
    }
    return false;
  }

  get_extension(fileName: string) {
    return fileName.substr(fileName.lastIndexOf('.'));
  }

  getNomFichier(fileName: string) {
    if (fileName.length > this.nombreCaracteresMaxAffiches) {
      return fileName.substring(0, this.nombreCaracteresMaxAffiches).concat('...' + this.get_extension(fileName));
    }
    return fileName;
  }

}

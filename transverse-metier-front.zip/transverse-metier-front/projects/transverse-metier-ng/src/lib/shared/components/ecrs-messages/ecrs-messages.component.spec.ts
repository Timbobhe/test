import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { EcrsMessagesComponent } from './ecrs-messages.component';
import { testingModule } from '../../../test/testing-module';

describe('EcrsMessagesComponent', () => {
  let component: EcrsMessagesComponent;
  let fixture: ComponentFixture<EcrsMessagesComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [EcrsMessagesComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EcrsMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

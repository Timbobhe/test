import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'trm-block-divider',
  template: `<hr class='ag2rlm-divider {{ overlayClass }}' >`,
  styleUrls: ['./block-divider.component.scss']
})
export class BlockDividerComponent implements OnInit {

  @Input()
  overlayClass: string;

  constructor() { }

  ngOnInit() {
  }

}

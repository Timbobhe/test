import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'trm-global-spinner',
  templateUrl: './global-spinner.component.html',
  styleUrls: ['./global-spinner.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GlobalSpinnerComponent {

  constructor() {
  }

}

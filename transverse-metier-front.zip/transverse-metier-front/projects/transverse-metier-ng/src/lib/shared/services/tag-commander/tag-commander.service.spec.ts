import { ConfigService, EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import * as fromRoot from '../../../reducers/global.state';
import { TagCommanderService } from './tag-commander.service';

describe('TagCommanderService', () => {
  let tagco: TagCommanderService;

  let configServiceStub: Partial<ConfigService>;
  let envSpecificServiceStub: Partial<EnvSpecificService>;

  configServiceStub = {
    config: {
      'jahia_endpoint': 'http://jahia/'
    }
  };
  envSpecificServiceStub = {
    config: {
      'jahia_endpoint': 'http://jahia/'
    },
    getConfig() {
      return envSpecificServiceStub.config;
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(fromRoot.reducers)
      ],
      providers: [
        {provide: ConfigService, useValue: configServiceStub},
        {provide: EnvSpecificService, useValue: envSpecificServiceStub},
        TagCommanderService],
    })
      .compileComponents();
    tagco = TestBed.inject(TagCommanderService);
  });

  it('should create an instance', () => {
    expect(tagco).toBeTruthy();
  });
});

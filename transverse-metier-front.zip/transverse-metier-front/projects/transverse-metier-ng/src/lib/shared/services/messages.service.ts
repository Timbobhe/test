import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Observable, of } from 'rxjs';
import { filter, map, switchMap } from 'rxjs/operators';
import { JahiaDicoEntry, MessageModel } from '../../models/message.model';

@Injectable({
  providedIn: 'root'
})
export class MessagesService {

  constructor(
    private readonly jahia: JahiaService) {
  }

  add(message: MessageModel, prime: MessageService): void {
    this.messageFromJahia(message).subscribe(msg => {
      // msg.life = 60000;
      prime.add(msg);
    });
  }

  addAll(messages: MessageModel[], prime: MessageService): void {
    if (messages && messages.length) {
      messages.forEach(message => {
        this.add(message, prime);
      });
    }
  }

  messageFromJahia(msg: MessageModel): Observable<MessageModel> {
    return of(msg).pipe(
      switchMap(e => {
        if (e.jahiaDetail) {
          return this.fromJahiaDicoEntry(e.jahiaDetail, 'detail', msg);
        } else {
          return of(e);
        }
      }),
      switchMap(e => {
        if (e.jahiaSummary) {
          return this.fromJahiaDicoEntry(e.jahiaSummary, 'summary', msg);
        } else {
          return of(e);
        }
      }),
    );
  }

  private fromJahiaDicoEntry(e: JahiaDicoEntry, key: string, msg: MessageModel): Observable<MessageModel> {
    return this.jahia.getDico(e.dicoId).pipe(
      filter(e => !!e),
      map(dico => {
        const label = dico.get(e.key) || e.defaultValue;
        return {...msg, [key]: label};
      })
    );
  }
}

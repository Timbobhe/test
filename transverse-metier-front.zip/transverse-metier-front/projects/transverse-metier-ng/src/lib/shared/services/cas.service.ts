import { BackendService, EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface LogoutModel {
  logout: boolean;
}

@Injectable()
export class CasService {
  private readonly cas_server_logout_url: string;
  private readonly should_logout_cas_client: boolean;

  constructor(
    private readonly http: HttpClient,
    private readonly envSpecificService: EnvSpecificService,
    private readonly backendService: BackendService
  ) {
    // @ts-ignore
    this.cas_server_logout_url = this.envSpecificService.config.cas_server_logout_url;
    // @ts-ignore
    this.should_logout_cas_client = this.envSpecificService.config.should_logout_cas_client;
  }

  private logoutFromCasClient(): Observable<LogoutModel> {
    return this.http.get<LogoutModel>(this.backendService.getEndpointUrl('casClientLogout'));
  }

  public logout() {
    if (this.should_logout_cas_client) {
      this.logoutFromCasClient().subscribe(logoutResponse => {
        window.location.replace(this.cas_server_logout_url);
      });
    } else {
      window.location.replace(this.cas_server_logout_url);
    }
  }
}

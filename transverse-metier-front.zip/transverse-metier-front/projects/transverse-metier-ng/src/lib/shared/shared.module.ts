import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AccordionModule } from 'primeng/accordion';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { CarouselModule } from 'primeng/carousel';
import { ChartModule } from 'primeng/chart';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { MessagesModule } from 'primeng/messages';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PanelModule } from 'primeng/panel';
import { ProgressBarModule } from 'primeng/progressbar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { SelectButtonModule } from 'primeng/selectbutton';
import { SidebarModule } from 'primeng/sidebar';
import { TableModule } from 'primeng/table';
import { ActionsBarComponent } from './components/actions-bar/actions-bar.component';
import { BadgeHexagonComponent } from './components/badge-hexagon/badge-hexagon.component';
import { BlockDividerComponent } from './components/block-divider/block-divider.component';
import { ButtonCtaComponent, ClickHandlerDirective } from './components/button-cta/button-cta.component';
import { ButtonRadioComponent } from './components/button-radio/button-radio.component';
import { ButtonYesNoComponent } from './components/button-yes-no/button-yes-no.component';
import { CarouselOneComponent } from './components/carousel-one/carousel-one.component';
import { CustomInputComponent } from './components/custom-input/custom-input.component';
import { CustomUploadComponent } from './components/custom-upload/custom-upload.component';
import { DragDropDirective } from './components/custom-upload/drag-drop.directive';
import { EcrsBasicMessageComponent } from './components/ecrs-basic-message/ecrs-basic-message.component';
import { EcrsMessagesComponent } from './components/ecrs-messages/ecrs-messages.component';
import { InputSliderComponent } from './components/input-slider/input-slider.component';
import { ModalPaginationComponent } from './components/modal-pagination/modal-pagination.component';
import { ScrollableComponent } from './components/scrollable/scrollable.component';
import { SelectButtonComponent } from './components/select-button/select-button.component';
import { SoustitreBarComponent } from './components/soustitre-bar/soustitre-bar.component';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { StepperComponent } from './components/stepper/stepper.component';
import { ValidationErrorsComponent } from './components/validation-errors/validation-errors.component';
import { Globals } from './utils/globals';
import { GlobalSpinnerComponent } from './components/global-spinner/global-spinner.component';
import { ContratCardComponent } from './components/contrat-card/contrat-card.component';
import { SliderModule } from 'primeng/slider';
import { EcrsRulerComponent } from './components/ecrs-ruler/ecrs-ruler.component';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule,
    RadioButtonModule,
    FormsModule,
    PanelModule,
    DialogModule,
    ScrollingModule,
    OverlayPanelModule,
    ButtonModule,
    MessagesModule,
    MessageModule,
    RouterModule,
    JahiaNgModule,
    InputSwitchModule,
    CarouselModule,
    AccordionModule,
    ReactiveFormsModule,
    ProgressBarModule,
    ProgressSpinnerModule,
    TableModule,
    SelectButtonModule,
    ScrollPanelModule,
    SliderModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    ButtonModule,
    DropdownModule,
    MetisNgModule,
    CalendarModule,
    SidebarModule,
    RadioButtonModule,
    InputTextModule,
    ProgressSpinnerModule,
    ProgressBarModule,
    DialogModule,
    PanelModule,
    ChartModule,
    OverlayPanelModule,
    TableModule,
    SelectButtonModule,
    BlockDividerComponent,
    ScrollPanelModule,
    ScrollableComponent,
    InputSwitchModule,
    ButtonCtaComponent,
    ButtonRadioComponent,
    StepperComponent,
    InputSliderComponent,
    CustomUploadComponent,
    ModalPaginationComponent,
    CarouselModule,
    AccordionModule,
    ValidationErrorsComponent,
    CustomInputComponent,
    ButtonYesNoComponent,
    ActionsBarComponent,
    SoustitreBarComponent,
    SpinnerComponent,
    CarouselOneComponent,
    BadgeHexagonComponent,
    EcrsBasicMessageComponent,
    EcrsMessagesComponent,
    SelectButtonComponent,
    GlobalSpinnerComponent,
    ContratCardComponent,
    EcrsRulerComponent
  ],
  declarations: [
    BlockDividerComponent,
    ScrollableComponent,
    ButtonCtaComponent,
    ButtonRadioComponent,
    StepperComponent,
    InputSliderComponent,
    CustomUploadComponent,
    ModalPaginationComponent,
    ValidationErrorsComponent,
    CustomInputComponent,
    ButtonYesNoComponent,
    ActionsBarComponent,
    SoustitreBarComponent,
    SpinnerComponent,
    ClickHandlerDirective,
    DragDropDirective,
    CarouselOneComponent,
    BadgeHexagonComponent,
    EcrsBasicMessageComponent,
    EcrsMessagesComponent,
    SelectButtonComponent,
    GlobalSpinnerComponent,
    ContratCardComponent,
    EcrsRulerComponent
  ],
  providers: [Globals]
})
export class SharedModule {
  // static forRoot(): ModuleWithProviders {
  //   return {
  //     ngModule: SharedModule,
  //     providers: [HttpInterceptorProviders2, BackendService, CasService]
  //   };
  // }
}

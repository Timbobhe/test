import { storeApiLogger } from '@ag2rlamondiale/redux-api-ng';
import { HttpErrorResponse } from '@angular/common/http';
import { ActionReducer, MetaReducer } from '@ngrx/store';
import { CoordonneesBancairesState } from '../reducers';


export function logger(reducer: ActionReducer<any>): ActionReducer<any> {
  return storeApiLogger(reducer);
}

export const metaReducers: MetaReducer<any>[] = [logger];

const ENCOURS_TOTAL = 100000;
const DATE_ENCOURS = '05/04/2019';
const REGIME_RETRAITE_PREVOYANCE = 'Régime de Retraite et de Prévoyance';
const MONDIALE_SOLUTIONS_RETRAITE = 'Mondiale Solutions Retraite';
const PLAN_EPARGNE_RETRAITE = 'Plan d\'Epargne retraite';
const PLAN_EPARGNE_RETRAITE_ENTREPRISE = 'Plan d\'Epargne Retraite Entreprises';
const AUTRE_CONTRAT = 'Autre contrat';

export function concatInitialStates(...initialStates: any) {
  const res = {};
  initialStates.forEach(e => Object.assign(res, ...e.initialState));
  const s = {initialState: res};
  console.log('CONCAT_STATE', s);
  return s;
}


export const initialStateWithEncours = {
  initialState: {
    compartiments: {
      data: {
        encoursTotal: ENCOURS_TOTAL,
        compartiments: {},
        autresContrats: [],
        contientPacte: true,
        uniquementPacte: true,
        contratSansEncours: [],
        sansEncoursSurTousLesContrats: false,
        uniquementAutresContrats: false
      },
      isFetched: true
    }
  }
};


export const initialStateWithCompartiment = {
  initialState: {
    compartiments: {
      data: {
        'encoursTotal': ENCOURS_TOTAL,
        'compartiments': {
          'c3': {
            'encoursCompartiment': 12500.0,
            'pourcentage': 37.0,
            'contrats': {
              'retraite': [
                {
                  'nomContrat': 'F98472902847237',
                  'description': REGIME_RETRAITE_PREVOYANCE,
                  'sousCompartiment': 'c1.2',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 22500.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                },
                {
                  'nomContrat': 'RG1362691',
                  'description': MONDIALE_SOLUTIONS_RETRAITE,
                  'sousCompartiment': 'c1.2',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 12300.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                }
              ],
              'conditions': [
                {
                  'nomContrat': 'RG1362691',
                  'description': PLAN_EPARGNE_RETRAITE,
                  'sousCompartiment': 'c3.1',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 17770.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                }
              ],
              'disponible': [
                {
                  'nomContrat': 'RG2756213564',
                  'description': PLAN_EPARGNE_RETRAITE_ENTREPRISE,
                  'sousCompartiment': 'c3.2',
                  'deductible': true,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 5000.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': true,
                  'disabled': false
                }
              ]
            }
          },
          'c1': {
            'encoursCompartiment': 60500.0,
            'pourcentage': 55.0,
            'contrats': {
              'retraite': [
                {
                  'nomContrat': 'F98472902847237',
                  'description': REGIME_RETRAITE_PREVOYANCE,
                  'sousCompartiment': 'c1.2',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 22500.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                },
                {
                  'nomContrat': 'RG1362691',
                  'description': MONDIALE_SOLUTIONS_RETRAITE,
                  'sousCompartiment': 'c1.2',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 12300.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                }
              ],
              'conditions': [
                {
                  'nomContrat': 'RG1362691',
                  'description': PLAN_EPARGNE_RETRAITE,
                  'sousCompartiment': 'c3.1',
                  'deductible': false,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 17770.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                }
              ],
              'disponible': [
                {
                  'nomContrat': 'RG1362691',
                  'description': PLAN_EPARGNE_RETRAITE_ENTREPRISE,
                  'sousCompartiment': 'c1.1',
                  'deductible': true,
                  'encours': {
                    'dateEncours': DATE_ENCOURS,
                    'montantEncours': 8000.0
                  },
                  'identifiantAssure': '',
                  'raisonSociale': '',
                  'dateAffiliation': null,
                  'pacte': false,
                  'vifPossible': true,
                  'encoursEnErreur': false,
                  'disabled': false
                }
              ]
            }
          },
          'c2': {
            type: null,
            encoursCompartiment: 0,
            pourcentage: 0,
            contrats: {
              disponible: [],
              retraite: [],
              conditions: []
            },
          }
        },
        'autresContrats': [
          {
            'nomContrat': AUTRE_CONTRAT,
            'description': null,
            'sousCompartiment': null,
            'deductible': false,
            'encours': {
              'dateEncours': null,
              'montantEncours': 22500.0
            },
            'identifiantAssure': '',
            'raisonSociale': '',
            'dateAffiliation': null,
            'pacte': false,
            'vifPossible': true,
            'encoursEnErreur': false,
            'disabled': false
          },
          {
            'nomContrat': AUTRE_CONTRAT,
            'description': null,
            'sousCompartiment': null,
            'deductible': false,
            'encours': {
              'dateEncours': null,
              'montantEncours': 22500.0
            },
            'identifiantAssure': '',
            'raisonSociale': '',
            'dateAffiliation': null,
            'pacte': false,
            'vifPossible': true,
            'encoursEnErreur': false,
            'disabled': false
          }
        ],
        'contientPacte': true,
        'uniquementPacte': true,
        'contratSansEncours': [],
        'sansEncoursSurTousLesContrats': false,
        'uniquementAutresContrats': false
      }
      ,
      isFetched: true
    }
  }
};


export const initialStateWithClientInfos = {
  initialState: {
    clientInfos:
      {
        'isFetched': true,
        'idGdi': 'cobnj6',
        'numeroPersonneEre': 'P3880287',
        'numeroPersonneMdpro': null,
        'partenaire': null,
        'sousPartenaire': null,
        'nom': 'CADOUOT',
        'prenom': 'PATRICK',
        'impersonation': false,
        'externalUid': null,
        'infosBlocagesClient': {
          'fonctionnalitesBloqueesALaPersonne': ['ClauseBeneficiaireSigElec', 'EnSavoirPlus', 'completerBIA'],
          'fonctionnalitesBloqueesPartenaire': [],
          'fonctionnalitesBloqueesContrats': {},
          'personneTotalementBloquee': false
        }
      }
  }
};

export const initialStateWithClientInfosImpersonation = {
  initialState: {
    clientInfos:
      {
        'isFetched': true,
        'idGdi': 'cobnj6',
        'numeroPersonneEre': 'P3880287',
        'numeroPersonneMdpro': null,
        'partenaire': null,
        'sousPartenaire': null,
        'nom': 'CADOUOT',
        'prenom': 'PATRICK',
        'impersonation': true,
        'externalUid': null,
        'infosBlocagesClient': {
          'fonctionnalitesBloqueesALaPersonne': ['ClauseBeneficiaireSigElec', 'EnSavoirPlus', 'completerBIA'],
          'fonctionnalitesBloqueesPartenaire': [],
          'fonctionnalitesBloqueesContrats': {},
          'personneTotalementBloquee': false
        }
      }
  }
};

export const initialStateWithClientInfosAndBlocageContrat = {
  initialState: {
    clientInfos:
      {
        'isFetched': true,
        'idGdi': 'cobnj6',
        'sousPartenaire': null,
        'numeroPersonneEre': 'P3880287',
        'numeroPersonneMdpro': null,
        'partenaire': null,
        'nom': 'CADOUOT',
        'prenom': 'PATRICK',
        'impersonation': false,
        'externalUid': null,
        'infosBlocagesClient': {
          'fonctionnalitesBloqueesALaPersonne': ['ClauseBeneficiaireSigElec', 'EnSavoirPlus', 'completerBIA'],
          'fonctionnalitesBloqueesPartenaire': [],
          'fonctionnalitesBloqueesContrats': {'RG152125682': ['SYNTHESE']},
          'personneTotalementBloquee': false
        }
      }
  }
};

export const initialStateEvenement = {
  'initialState': {
    'evenement': {
      'even': {
        'id': 22461,
        'typeEvenement': {
          'codeEvenement': 'ERE_PND_3',
          'categorie': {
            'codeCategorie': 'CAT_DONNEES_PERSO',
            'codeApplication': 'A1324',
            'ordre': 1,
            'description': 'Categorie données perso'
          },
          'ordre': 3,
          'dateDebut': null,
          'dateFin': null,
          'nbDeclenchementsMaxPeriode': 3,
          'periodeDeclenchement': null,
          'delaiAvantReactivation': null,
          'modeAction': 'FACU',
          'titre': 'ERE_PND_Titre',
          'contenu': 'ere.evenements.contenu.erePnd3',
          'actionTraiter': 'ERE_PND_TRAITER',
          'actionAnnuler': null,
          'lienRedirection': 'ModifDonneesPerso',
          'perimetreEvenements': [],
          'libEvenement': 'Pli non distribué 3 fois',
          'dirty': false
        },
        'idGdi': '5qkpcx',
        'numContrat': null,
        'etatTraitement': null,
        'dateDebut': null,
        'dateFin': null
      },
      'isFetched': true,
      'enTraitement': false,
      'loading': false
    }
  }
};
export const initialStateWithCompartimentNotFetched = {
  initialState: {
    compartiments: {
      isFetched: false,
      data: null
    }
  }
};

const errorTypeValue = 'API';

export const initialStateWithHttpError = {
  initialState: {
    ui: {
      initializing: false,
      tagCommanderDispo: false,
      compartimentSelected: '',
      stackCalls: [],
      tourSteps: [],
      tourFinished: false,
      tourStarted: false,
      cardSujetsSelectionnes: [],
      error: {
        error: new HttpErrorResponse({}),
        errorType: errorTypeValue,
        severity: 2
      },
      onboarding: {etape: null, sujetsSelectionnes: [], etapeConfigurerVotreEspace: null},
      contratSelected: null,
      typeActionContactSelected: '',
      toastMessages: []
    }
  }
};

export const initialStateJahiaDicoEven = {
  initialState: {
    jahia: {
      jahiaContribs: {
        contributions: {
          'ERE_PND_3': {
            contentHtml: 'Votre adresse n\'a pas été renseignée',
            contribId: 'ERE_PND_3'
          }
        }
      },
      jahiaDictionnaires: {
        dictionnaires: {
          eventDictionnaireDeLibelles: {
            entries: {
              'ERE_CONF_Titre': 'Confirmation de vos données personnelles',
              'ERE_CONF_TRAITER': 'Confirmer mes données personnelles',
              'ERE_PND_Titre': 'Mettre à jour mes données personnelles',
              'ERE_PND_TRAITER': 'Mettre à jour mes données personnelles',
              'ERE_BIA_Titre': 'Compléter mon BIA',
              'ERE_BIA_TRAITER': 'Compléter mon BIA',
              'ERE_BIA_ANNULER': 'Continuer ma navigation (ERE_BIA_ANNULER)',
              'ERE_INFO_Titre': 'Information',
              'ERE_INFO_TRAITER': 'J&#039;ai pris connaissance des informations',
              'ERE_PND_ANNULER': 'Continuer ma navigation (ERE_PND_ANNULER)',
              'ERE_VDPP_Titre': 'Vérification de vos données personnelles',
              'ERE_VDPP_TRAITER': 'Vérifier que mes données personnelles sont à jour',
              'ERE_VDPP_ANNULER': 'Continuer ma navigation (ERE_VDPP_ANNULER)',
              'ADDING_ARB_Titre': 'Modifier la gestion financière',
              'ADDING_ARB_TRAITER': 'Modifier ma gestion financière',
              'ERE_MDMD_Titre': 'Modification de vos demandes',
              'ERE_MDMD_TRAITER': 'Compléter mes demandes.',
              'ERE_MDMD_ANNULER': 'Continuer ma navigation (ERE_MDMD_ANNULER)',
              'PRT_CGU_Titre': 'Conditions générales d&#039;utilisation',
              'PRT_CGU_TRAITER': 'J’accepte',
              'PRT_CGU_TELECHARGER': 'Télécharger'
            },
            title: 'eventDictionnaireDeLibelles'
          }
        }
      }
    }
  }
};

export const initialStateWithClientInfosAndPartenaire = {
  initialState: {
    clientInfos:
      {
        'isFetched': true,
        'idGdi': 'cobnj6',
        'numeroPersonneEre': 'P3880287',
        'numeroPersonneMdpro': null,
        'partenaire': {
          codePartenaire: 'test',
          codePartenairePrincipal: 'test',
          label: 'test',
          urlHeader: 'test',
          urlFooter: 'test',
          urlError: 'test',
          urlMenu: 'test',
          nomCss: 'test',
          idContrats: 'test',
          urlBase: 'http://localhost:4200'
          // fonctionnnalitesBloquees: Array<string>,
        },
        'sousPartenaire': null,
        'nom': 'CADOUOT',
        'prenom': 'PATRICK',
        'impersonation': false,
        'externalUid': null,
        'infosBlocagesClient': {
          'fonctionnalitesBloqueesALaPersonne': ['ClauseBeneficiaireSigElec', 'EnSavoirPlus', 'completerBIA'],
          'fonctionnalitesBloqueesPartenaire': [],
          'fonctionnalitesBloqueesContrats': {},
          'personneTotalementBloquee': false
        }
      }
  }
};

export const initialStateWithClientInfosAndPartenaireNie = {
  initialState: {
    clientInfos:
      {
        'isFetched': true,
        'idGdi': 'cobnj6',
        'numeroPersonneEre': 'P3880287',
        'numeroPersonneMdpro': null,
        'partenaire': {
          codePartenaire: '49505',
          codePartenairePrincipal: 'test',
          label: 'test',
          urlHeader: 'test',
          urlFooter: 'test',
          urlError: 'test',
          urlMenu: 'test',
          nomCss: 'test',
          idContrats: 'test',
          urlBase: 'http://localhost:4200'
          // fonctionnnalitesBloquees: Array<string>,
        },
        'sousPartenaire': null,
        'nom': 'CADOUOT',
        'prenom': 'PATRICK',
        'impersonation': false,
        'externalUid': null,
        'infosBlocagesClient': {
          'fonctionnalitesBloqueesALaPersonne': ['ClauseBeneficiaireSigElec', 'EnSavoirPlus', 'completerBIA'],
          'fonctionnalitesBloqueesPartenaire': [],
          'fonctionnalitesBloqueesContrats': {},
          'personneTotalementBloquee': false
        }
      }
  }
};

export const initialStateWithContractsAssures = {
  initialState: {
    contratsAssure: {
      contratsAssure: [{
        id: 'RG152125682',
        codeFiliale: '',
        codeSilo: 'ERE',
        identifiantAssure: '1315286'
      },
        {
          id: 'RG151312337',
          codeFiliale: '',
          codeSilo: 'ERE',
          identifiantAssure: '583241'
        },
        {
          id: 'RG150108276',
          codeFiliale: '',
          codeSilo: 'ERE',
          identifiantAssure: '583241'
        },
        {
          id: 'RA143551464000',
          codeFiliale: '',
          codeSilo: 'MDPRO',
          identifiantAssure: ''
        }]
      , isFetched: true, idDernierContratERE: 'RG151312337'
    }
  }
};

export const initialStateWithContractsAssuresComplets = {
  initialState: {
    contratsAssure: {
      contratsAssure: [
        {
          affichageType: 'NORMAL',
          codeFiliale: 'ARI',
          codeProduit: 'RG02-003-ARI',
          codeSilo: 'ERE',
          compartiments: [
            {
              affichageType: 'NORMAL',
              college: 'Cadres dirigeants',
              compartimentId: {idAssure: '1443995', nomContrat: null, compartimentType: 'C3'},
              deductible: false,
              disponibilite: 'DISPO_RETRAITE',
              identifiantAssure: '1443995',
              libelleEtat: 'Validé',
              type: 'C3'
            },
            {
              affichageType: 'NORMAL',
              college: 'Non catégorielle',
              compartimentId: {idAssure: '1443996', nomContrat: null, compartimentType: 'C1'},
              deductible: true,
              disponibilite: 'DISPO_SOUS_CONDITIONS',
              identifiantAssure: '1443996',
              libelleEtat: 'Validé',
              type: 'C1'
            },
            {
              affichageType: 'NORMAL',
              college: 'Non catégorielle',
              compartimentId: {idAssure: '1443997', nomContrat: null, compartimentType: 'C4'},
              deductible: false,
              disponibilite: 'DISPO_SOUS_CONDITIONS',
              identifiantAssure: '1443997',
              libelleEtat: 'Validé',
              type: 'C4'
            },
            {
              affichageType: 'NORMAL',
              college: 'Non catégorielle',
              compartimentId: {idAssure: '1443998', nomContrat: null, compartimentType: 'C2'},
              deductible: false,
              disponibilite: 'DISPO_SOUS_CONDITIONS',
              identifiantAssure: '1443998',
              libelleEtat: 'Validé',
              type: 'C2'
            }
          ],
          contractanteRepresent: false,
          dateAffiliation: '2020-09-06T22:00:00.000+0000',
          dateEffet: '2019-12-31T23:00:00.000+0000',
          description: 'UNIVERS RETRAITE ENTREPRISE',
          descriptionFront: 'UNIVERS RETRAITE ENTREPRISE',
          etatAffiliationLabel: 'En cours',
          etatContrat: 'VALIDE',
          etatContratLabel: 'Validé',
          id: 'RG152222876',
          idContractante: 'S3926551',
          identifiantAssure: '1443995',
          nomContrat: 'RG152222876',
          numGenContrat: '003',
          pacte: true,
          personId: 'P3926647',
          petitCollectifPTV: false,
          raisonSociale: 'ARCHITECTURE PARENT OLIVIER',
          raisonSocialeContractante: 'ARCHITECTURE PARENT OLIVIER',
          raisonSocialeFront: 'ARCHITECTURE PARENT OLIVIER',
          typeContrat: 'RG02'
        },
        {
          affichageType: 'NORMAL',
          codeFiliale: 'ARI',
          codeProduit: 'RP01-002-ARI',
          codeSilo: 'ERE',
          college: 'Cadres',
          compartiments: [
            {
              affichageType: 'NORMAL',
              college: 'Cadres',
              compartimentId: {idAssure: '280980', nomContrat: null, compartimentType: 'C1'},
              deductible: true,
              disponibilite: 'DISPO_RETRAITE',
              identifiantAssure: '280980',
              type: 'C1'
            },
            {
              affichageType: 'NORMAL',
              college: 'Cadres',
              compartimentId: {idAssure: '280980', nomContrat: null, compartimentType: 'C3'},
              deductible: false,
              disponibilite: 'DISPO_RETRAITE',
              identifiantAssure: '280980',
              type: 'C3'
            }
          ],
          contractanteRepresent: false,
          dateAffiliation: '2007-11-30T23:00:00.000+0000',
          dateEffet: '2007-11-30T23:00:00.000+0000',
          dateEffetSituationAffiliation: '2018-12-30T23:00:00.000+0000',
          description: 'ARIAL Retraite Entreprise',
          descriptionFront: 'ARIAL Retraite Entreprise',
          etatContratLabel: 'Validé',
          id: 'RP150612773',
          idContractante: 'S3925406',
          identifiantAssure: '280980',
          nomContrat: 'RP150612773',
          numGenContrat: '002',
          pacte: false,
          personId: 'P3926647',
          petitCollectifPTV: false,
          raisonSociale: 'SCAPA FRANCE',
          raisonSocialeContractante: 'SCAPA FRANCE',
          raisonSocialeFront: 'SCAPA FRANCE',
          typeContrat: 'RP01'
        }
      ],
      isFetched: true,
      idDernierContratERE: 'RG151312337'
    }
  }
};


export const initialStateWithRouter = {
  initialState: {
    router: {
      navigationId: 0,
      state: {
        root: null,
        url: '/onboarding'
      }
    }
  }
};

export const initialStateWithIdentiteNumerique = {
  initialState: {
    identNumMatchAccount: {
      identiteNumerique: {
        matchAccount: true,
        identiteNumeriqueExist: true,
        ag2r: {
          email: 'email@ag2rlamondiale.fr',
          telPortable: '0600000000'
        },
        universign: {
          email: 'email@ag2rlamondiale.fr',
          telPortable: '0600000000'
        },
      }
    }
  }
};

export const initialStateWithIdentiteNum = {
  initialState: {
    identiteNum: {
      contexteAppel:
        {
          'fonctionnaliteAppelante': null,
          'urlRetourOk': '',
          'urlRetourCancel': '',
        },
      pieceIdentite: 'PASSEPORT'
    }
  }
};

export const initialStateWithCoordonneesBancaires = {
  initialState: {
    coordonneesBancaires: {
      data: {
        coordonneesBancairesRetraiteSupp: [
          {
            contrat: {'nomContrat': 'RG151095348', 'codeSilo': 'ERE'},
            bic: 'AGRIFRPP878',
            iban: 'FR7617806004400809674800087',
            idAssure: '343742',
            idMessage: null,
            titulaire: 'MME CLUTIER /BORRON ANNE',
            modificationRibPossible: false,
            modificationRibBloquee: false
          },
          {
            contrat: {'nomContrat': 'RG151095349', 'codeSilo': 'ERE'},
            bic: 'AGRIFRPP879',
            iban: 'FR7617806004400809674800089',
            idAssure: '343742',
            idMessage: null,
            titulaire: 'MME CLUTIER /BORRON ANNE',
            modificationRibPossible: true,
            modificationRibBloquee: false
          }
        ],
        coordonneesBancairesEpargnePrevoyance: [
          {
            contrat: {'nomContrat': 'RA143551464000', 'codeSilo': 'MDPRO'},
            bic: null,
            iban: null,
            idAssure: '343742',
            idMessage: null,
            titulaire: null,
            modificationRibPossible: false,
            modificationRibBloquee: false
          }
        ]
      },
      currentCoordonneesBancaires: {
        contrat: {'nomContrat': 'RG150108276', 'codeSilo': 'ERE'},
        titulaire: 'MME DURAND /HAURY ISABELLE',
        bic: 'CRLYFRPPXXX',
        iban: 'FR6630002006530000020595G59',
      },
      isFetched: true
    },
    sigElec: {
      demande: null,
      isFetched: true,
      loading: false,
      urlRetour: ''
    }
  }
};

export const initialStateWithRouterAndQueryParam = {
  initialState: {
    router: {
      navigationId: 0,
      state: {
        root: {
          queryParams: {
            startTour: false
          }
        },
        url: '/synthese-des-comptes'
      }
    },
    navigation: {
      navigationId: 0,
      navigate: true,
      navigationEvent: 'navigation',
      url: '/synthese-des-comptes'
    }
  }
};
export const initialStateWithQad = {
  initialState: {
    qad: {
      contrat: {nomContrat: 'RG151887159', codeSilo: 'ERE'},
      type: null,
      fonctionnaliteType: null,
      codeDocument: null,
      qadQuestionsReponses: [],
      isFetched: false,
      codeProposition: '',
      codesSupportsContrat: null
    }
  }
};

export const initialStateWithSigElec = {
  initialState: {
    sigElec: {
      demande: null,
      isFetched: false,
      loading: false,
      urlRetour: ''
    }
  }
};


export const initialStateAccessibilite = {
  initialState: {
    accessibilite: {
      accesFonctionnaliteModel: {
        fonctionnaliteType: 'completerBIA',
        accessible: false,
        raison: 'BLOCAGE_BIA_MONO_EQUIPE_MDPRO'
      },
      isFetched: true
    }
  }
};

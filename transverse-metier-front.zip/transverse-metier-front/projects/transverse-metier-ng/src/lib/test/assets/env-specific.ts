export const envSpecificConfig = {
  backend_base: {
    protocol: 'http',
    host: 'localhost',
    port: '8080',
    contextRoot: 'ecrs'
  },
  jahia_endpoint: 'http://cdr-dev-jahia7:8080',
  jahia_header_script: '/files/live/sites/alm-angular-utils/files/javascript/angular-header-footer.js',
  cas_server_logout_url: 'http://loginalm-qualif/cas/sso/dev$alm2014/logout',
  // jahia_api_contrib: 'http://localhost:8080/ecrs/api/jahia',
  api_contrib_jahia: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  api_dictionnaire_jahia: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  jahia_files: 'http://cdr-dev-jahia7:8080/',
  should_logout_cas_client: true,
  jahia_ressources_logos_root: 'http://jahia',
  jahia_ressources_onboarding_root: 'http://jahia',
  jahia_ressources_mkg_bloc_root: 'http://jahia',
  jahia_ressources_contact_root: 'http://jahia',
  jahia_ressources_coordonnees_bancaires_root: 'http://jahia',
  jahia_ressources_versement_root: 'http://jahia',

  mkg_bloc_endpoint: 'http://aqea/#Dossier:le-fonctionnement-de-la-retraite'

};



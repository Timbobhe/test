export const config = {
  backend: {
    endpoints: {
      loginUrl: '/api/secure/redirectToJahia',
      casClientLogout: '/api/logout',
      demoResource: '/api/secure/demo',
      api_hello: '/api/hello'
    }
  }
}

import {
  JahiaContrib,
  JahiaContribPayload,
  JahiaDictionnaire,
  JahiaLoadStatePayload,
  JahiaLoadStateRemote,
  JahiaNgModule,
  JahiaQuestionsReponses,
  JahiaService
} from '@ag2rlamondiale/jahia-ng';
import { JahiaConfigData } from '@ag2rlamondiale/jahia-ng/lib/actions/jahia-config';
import { DataStatus, ReduxApiNgModule, storeApiLogger } from '@ag2rlamondiale/redux-api-ng';
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed, TestModuleMetadata } from '@angular/core/testing';
import * as fromRoot from '../reducers/global.state';
import { EffectsModule } from '@ngrx/effects';
import { ActionReducer, MetaReducer, StoreModule } from '@ngrx/store';
import { backendServiceProvider, configServiceProvider, envSpecificProvider } from './conf-test.provider';
import { ContextCondition, JahiaConditionPayload } from '@ag2rlamondiale/jahia-ng/lib/models/jahiacondition.model';
import { EMPTY, Observable } from 'rxjs';
import { JahiaResource } from '@ag2rlamondiale/jahia-ng/lib/models/jahiaresource.model';
import { RouterTestingModule } from '@angular/router/testing';
import { Globals } from '../shared/utils/globals';

export function logger(reducer: ActionReducer<any>): ActionReducer<any> {
  return storeApiLogger(reducer);
}

export const metaReducers: MetaReducer<any>[] = [logger];

export class TestingConfig {
  jahiaConfig?: JahiaConfigData = {};
  initialState?: any = {};
}

const jahiaServiceServiceStub: Partial<JahiaService> = {
  preFetchDico: function (dicoIds: string[]): void {
  },
  preFetchContrib: function (contribIds: string[]): void {
  },
  preFetchQuestionsResponses: function (contribIds: string[]): void {
  },
  prefetchPathsDomaines(domaines: string): void {
  },
  applyCondition(data: string, contexteCondition: ContextCondition): Observable<string> {
    return EMPTY;
  },
  clearContrib(contribId: string): void {
  },
  dumpState(callback: ((data: JahiaLoadStatePayload) => any) | undefined): void {
  },
  evalCondition(payload: JahiaConditionPayload): Observable<boolean> {
    return EMPTY;
  },
  getContrib(params: JahiaContribPayload, option: { force: boolean } | undefined): Observable<JahiaContrib> {
    return EMPTY;
  },
  getDico(dicoId: string): Observable<JahiaDictionnaire> {
    return EMPTY;
  },
  getDicoEntry(dicoId: string, key: string): Observable<{ dico: JahiaDictionnaire; key: string; label: string }> {
    return EMPTY;
  },
  getQuestionsReponses(contribId: string): Observable<JahiaQuestionsReponses> {
    return EMPTY;
  },
  getResource(resourceId: string, resourcePath: string | undefined): Observable<JahiaResource> {
    return EMPTY;
  },
  loadState(data: JahiaLoadStatePayload): void {
  },
  loadStateRemote(endpoint: string | undefined): void {
  },
  loadStateRemoteAction(endpoint: string | undefined): JahiaLoadStateRemote {
    return undefined;
  },
  preFetchResources(resourceIds: string[]): void {
  },
  prefetchAll(): void {
  },
  getContribWithStatus(params: JahiaContribPayload, option: { force: boolean } = {force: false}): Observable<DataStatus<JahiaContrib>> {
    return EMPTY;
  }


};


// noinspection AngularMissingOrInvalidDeclarationInModule
@Component({selector: 'route-dummy-component', template: ''})
class RouteDummyComponent {
}


export const testingModule = (config: TestingConfig, testModuleMetadata: TestModuleMetadata = {}) => {
  const meta = Object.assign({imports: [], providers: [], declarations: []}, testModuleMetadata);
  const conf = Object.assign(new TestingConfig(), config);

  if (conf.initialState && conf.initialState.hasOwnProperty('initialState')) {
    throw new Error(`2 niveaux initialState : il faut faire ...initialStateXXX`);
  }

  return TestBed.configureTestingModule({
    imports: [
      StoreModule.forRoot(fromRoot.reducers, {metaReducers, initialState: conf.initialState}),
      EffectsModule.forRoot([]),
      ReduxApiNgModule,
      JahiaNgModule.forRoot({config: conf.jahiaConfig}),
      RouterTestingModule.withRoutes([{path: '**', component: RouteDummyComponent}]),
      ...meta.imports,
    ],
    declarations: [
      RouteDummyComponent,
      ...meta.declarations
    ],
    providers: [
      envSpecificProvider,
      configServiceProvider,
      backendServiceProvider,
      Globals,
      {provide: JahiaService, useValue: jahiaServiceServiceStub},
      ...meta.providers,
    ],
    schemas: [NO_ERRORS_SCHEMA]
  });
};

export enum Categorie {
  coordonneesBancaires = 'ERE_coordonnees_bancaires'
}


export enum TypeOriginAction {
  coordonneesBancaires_modification = 'demande-modification',
  coordonneesBancaires_confirmation = 'confirmation-modification',
}

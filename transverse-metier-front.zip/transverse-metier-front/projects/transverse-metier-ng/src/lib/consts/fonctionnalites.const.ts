export const COORDONNEES_BANCAIRES = 'VosCoordonneesBancaires';
export const MODIF_RIB = 'ModifierRIB';

export const SIGELEC_RIBA = 'RIBA';

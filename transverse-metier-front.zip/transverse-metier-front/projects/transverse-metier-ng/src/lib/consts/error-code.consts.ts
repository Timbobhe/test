export enum ERROR_LEVEL {
  BUSINESS_ERROR = 'business-error',
  TECHNICAL_ERROR = 'technical-error'
}

export const ErrorLevel = new Map<string, string>([
  [ERROR_LEVEL.BUSINESS_ERROR, 'Une erreur a été rencontrée: '],
  [ERROR_LEVEL.TECHNICAL_ERROR, 'Une erreur Technique a été rencontrée.']
]);

export enum ERROR_CODE {
  UNAUTHORIZED_USER = 'unauthorized-user',
  USER_NOT_FOUND = 'user-not-found',
  CONTRACT_EMPTY_LIST = 'contract-empty-list',
  NO_ELIGIBLE_CONTRACT = 'no-eligible-contract',

  PJ_TAILLE_KO = 'pj-taille-ko',
  PJ_EXTENSION_KO = 'pj-extention-ko',
  PJ_TAILLE_ALL_KO = 'pj-taille-all-ko',
  INVALID_DATA = 'invalid-data',
  PJ_NULL_OR_EMPTY = 'pj-null-or-empty',
  PJ_DOUBLON_FILE = 'pj-doublon-file',
  PJ_CORRUPTED_FILE = 'pj-corrupted-file'
}

export const ErrorCode = new Map<string, string>([
  [ERROR_CODE.UNAUTHORIZED_USER, 'L’utilisateur ne possède pas le rôle TODO sur son compte GDI '],
  [ERROR_CODE.USER_NOT_FOUND, 'Le client n\'a pas été trouvé dans la base de donnée'],
  [ERROR_CODE.CONTRACT_EMPTY_LIST, 'Le client existe mais sa liste de contrats est vide'],
  [ERROR_CODE.NO_ELIGIBLE_CONTRACT, 'Il existe bien des contrats mais pas un seul n\'est éligible'],

  [ERROR_CODE.PJ_TAILLE_KO, 'La taille de votre fichier doit être inférieure à 2 Mo.'],
  [ERROR_CODE.PJ_EXTENSION_KO, 'Seuls les fichiers de type PDF, TIF, TIFF, PNG, BMP, JPG et JPEG sont autorisés.'],
  [ERROR_CODE.PJ_TAILLE_ALL_KO, 'La taille de vos justificatifs est supérieure à 15 Mo.'],
  [ERROR_CODE.INVALID_DATA, 'Les données envoyées par le client diffèrent des données enregistrées en base.'],
  [ERROR_CODE.PJ_NULL_OR_EMPTY, 'Votre fichier est vide.'],
  [ERROR_CODE.PJ_DOUBLON_FILE, 'Ce fichier a déjà été ajouté'],
  [ERROR_CODE.PJ_CORRUPTED_FILE, 'Ce fichier est corrompu']

]);

'use strict';
var gulp = require('gulp'),
    maven = require('gulp-maven-deploy'),
    zip = require('gulp-zip');
var pckg = require('./package.json');


gulp.task('deploy-local', function() {
    gulp.src('dist/*')
    .pipe(zip('eia.zip'))
        .pipe(maven.install({
            'groupId': 'fr.ag2rlamondiale.ng',
            'buildDir': 'dist/',
            'snapshot': false,
            'version': pckg.version,
        }));
});

/** Default Task. */
gulp.task('default', ['deploy-local']);

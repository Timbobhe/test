import { TrackingConfig } from '@ag2rlamondiale/transverse-metier-ng';
import { Categorie } from '@app/actions/tracking.action';


/**
 * --- EVENT : pageview ----
 */
export const TC_VARS = [
  {
    path: '/synthese-des-comptes',
    vars: {
      client_profil: 'particuliers'
    }
  },
  {
    path: '/accueil',
    vars: {
      form_profil: 'particuliers',
    },
    children: [
      {
        path: 'configurer-votre-espace',
        vars: {
          notag: true
        },
        children: [
          {
            path: 'beneficiaires',
            vars: {
              notag: false,
              form_step: 'beneficiaires'
            }
          },
          {
            path: 'gestion-financiere',
            vars: {
              notag: false,
              form_step: 'gestion-financiere'
            }
          },
          {
            path: 'objectifs',
            vars: {
              notag: false,
              form_step: 'objectifs'
            }
          }
        ]
      }
    ]
  },
  {
    path: '/nous-contacter',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'type-demande',
        vars: {
          notag: false,
          form_step: 'type-demande'
        }
      },
      {
        path: 'contact',
        vars: {
          notag: false,
          form_step: 'contact'
        }
      },
      {
        path: 'reclamation',
        vars: {
          notag: false,
          form_step: 'reclamation'
        }
      }
    ]
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'consultation',
        vars: {
          notag: false,
          form_step: 'consultation'
        }
      },
      {
        path: 'modification',
        vars: {
          notag: false,
          form_step: 'modification'
        }
      },
      {
        path: 'verification-donnees-personnelles',
        vars: {
          notag: false,
          form_step: 'verification'
        }
      },
    ]
  }
];


/**
 * --- EVENT : eventGA ----
 */
export const TC_CATEGORY_URL = [
  {
    path: '/accueil',
    vars: {
      category: Categorie.onboarding
    }
  },
  {
    path: '/synthese-des-comptes',
    vars: {
      category: Categorie.synthese
    }
  },
  {
    path: '/modifier-objectif',
    vars: {
      category: Categorie.modificationObjectif
    }
  },
  {
    path: '/bulletin-affiliation',
    vars: {
      category: Categorie.bia
    }
  },
  {
    path: '/nous-contacter',
    vars: {
      category: Categorie.contact
    }
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      category: Categorie.coordonneesBancaires
    }
  },
  {
    path: '/clause-beneficiaire',
    vars: {
      category: Categorie.modificationClauseBeneficiaire
    }
  },
  {
    path: '/modification-gestion-financiere',
    vars: {
      category: Categorie.arbitrage
    }
  },
  {
    path: '/versement',
    vars: {
      category: Categorie.versement
    }
  },

];

export const EcrsTrackingConfig: TrackingConfig = {
  appNameContext: '/retraite-supplementaire',
  varsPath: TC_VARS,
  categoriesPath: TC_CATEGORY_URL
};

import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { FooterModel } from '@app/models/footer/footer.model';
import { HeaderUser } from '@app/models/header/header-user.model';
import { JahiaModel } from '../models/jahia.model';

const LABEL = 'Votre espace client';

const IMG_SRC = 'https://espace-client.ag2rlamondiale.fr/files/live/sites/aql/files/javascriptEtCSS/styles/css/img/picto/sprite-ag2r.png';
export const footerData: FooterModel = {
  footerSocial: {
    title: 'Suivez-nous',
    canals: [
      {
        type: 'facebook',
        link: 'https://www.facebook.com/AG2RLAMONDIALE/',
        iconClass: 'iconFb',
        imgSrc:
          IMG_SRC,
        backgroundPositionX: '-197px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'tweeter',
        link: 'https://twitter.com/ag2rlamondiale?lang=fr',
        iconClass: 'iconTw',
        imgSrc:
          IMG_SRC,
        backgroundPositionX: '-291px',
        backgroundPositionY: '-120px'
      },
      {
        type: 'linkedin',
        link: 'https://fr.linkedin.com/company/ag2r-la-mondiale',
        iconClass: 'iconLnkd',
        imgSrc:
          IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'scoope',
        link: 'http://www.scoop.it/u/ag2rlamondiale',
        iconClass: 'iconScoope',
        imgSrc:
          IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'youtube',
        link: 'https://www.youtube.com/user/AG2RLAMONDIALE',
        iconClass: 'iconYoutube',
        imgSrc:
          IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      }
    ]
  },
  footerTitle: 'Les sites AG2R LA MONDIALE',
  footerCols: [
    {
      title: 'SITES SERVICES DU GROUPE',
      links: [
        {
          label: 'Portail Groupe',
          url: 'https://www.ag2rlamondiale.fr/'
        },
        {
          label: 'Ventes en ligne',
          url: 'https://www.vente-en-ligne.ag2rlamondiale.fr/accueil'
        },
        {
          label: 'Clientèle patrimoniale',
          url: 'http://www.patrimoine.ag2rlamondiale.fr/'
        },
        {
          label: 'Partenariat patrimonial',
          url:
            'https://www.partenariat.patrimonial.ag2rlamondiale.fr/accueil.html'
        },
        {
          label: 'Aidons les nôtres',
          url: 'https://www.aidonslesnotres.fr/'
        },
        {
          label: 'Préparons ma retraite',
          url: 'http://www.preparonsmaretraite.fr/cms/retraite.html'
        },
        {
          label: 'Club Expertises et Solutions',
          url:
            'https://www.ag2rlamondiale.fr/club-expertises-et-solutions'
        },
        {
          label: 'Epargne salariale',
          url: 'http://www.epargne.ag2rlamondiale.fr/'
        }
      ]
    },
    {
      title: 'Autres sites du groupe',
      links: [
        {
          label: 'Cyclisme',
          url: 'http://www.cyclisme.ag2rlamondiale.fr/fr/'
        },
        {
          label: 'Voile',
          url: 'http://transat.ag2rlamondiale.fr/fr/s01_home/s01p01_home.php'
        },
        {
          label: 'Magazine Pleine Vie',
          url: 'http://www.pleinevie.fr/'
        }
      ]
    },
    {
      title: 'Mutuelles Partenaires du Groupe',
      links: [
        {
          label: 'La Frontalière',
          url: 'http://www.mutuelle-lafrontaliere.fr/'
        },
        {
          label: 'Leroy Somer',
          url: 'http://www.mutuelle-leroy-somer.com/'
        },
        {
          label: 'Mutuelle Interprofessionnelle des Antilles et de Guyane',
          url: 'http://www.miag.fr/'
        },
        {
          label: 'Mutuelle des Professions Judiciaires',
          url: 'http://www.mutuelle-mpj.fr/home.html'
        },
        {
          label: 'Mutuelle Just\'En Famille',
          url: 'http://www.justenfamille.fr/'
        }
      ]
    },
    {
      title: 'Caisses de retraite partenaires du groupe',
      links: [
        {
          label: 'IRCOM La Verrière',
          url: 'http://www.ircom-laverriere.com/'
        },
        {
          label: 'CGRR',
          url: 'http://www.cgrr.fr/'
        }
      ]
    }
  ],
  footerLegal: {
    cols: [
      {
        label: 'Plan du site',
        url: 'https://portail-convergence.ppalm.fr/plan-du-site'
      },
      {
        label: 'Mentions légales',
        url: 'https://www.ag2rlamondiale.fr/mentions-legales'
      },
      {
        label: 'Protection des données',
        url:
          'https://www.ag2rlamondiale.fr/protection-des-donnees-espace-client'
      },
      {
        label: 'Nous contacter',
        url: 'https://www.ag2rlamondiale.fr/nous-contacter'
      }
    ],
    copyRight: '© 2011-2018 AG2R LA MONDIALE'
  }
};


export function getJahiaResponse(configService: ConfigService): JahiaModel {
  return {
    headerAg2r: {
      title: {
        image: {
          alt: 'AG2R LA MONDIALE',
          url: configService.config['jahia_ressources_logos_root'].concat('AG2R-desktop.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('AG2R-mobile.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerArialCNP: {
      title: {
        image: {
          alt: 'ARIAL CNP ASSURANCES',
          url: configService.config['jahia_ressources_logos_root'].concat('ACA.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('ACA.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerPartenaireNie: {
      title: {
        image: {
          alt: '',
          url: configService.config['jahia_ressources_logos_root'].concat('logo_nie_aca_small.svg'),
           urlMobile: configService.config['jahia_ressources_logos_root'].concat('logo_nie_aca_small.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerPartenaireAdding: {
      title: {
        image: {
          alt: '',
          url: configService.config['jahia_ressources_logos_root'].concat('adding-logo.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('adding-logo.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    onboardingImage: {
      alt: 'Onboarding',
      url: configService.config['jahia_ressources_onboarding_root'].concat('onboarding-desktop.png'),
      urlMobile: configService.config['jahia_ressources_onboarding_root'].concat('onboarding-mobile.png'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    biaImage: {
      alt: 'BIA',
      url: configService.config['jahia_ressources_bia_root'].concat('bia-desktop.png'),
      urlMobile: configService.config['jahia_ressources_bia_root'].concat('bia-mobile.png'),
      urlToRedirect: null
    },
    coordonneesBancairesImage: {
      alt: 'CoordonneesBancaires',
      url: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-mobile.jpg'),
      urlToRedirect: null
    },
    versementImage: {
      alt: 'Versement',
      url: configService.config['jahia_ressources_versement_root'].concat('versement-desktop.png'),
      urlMobile: configService.config['jahia_ressources_versement_root'].concat('versement-mobile.png'),
      urlToRedirect: null
    },
    contactImage: {
      alt: 'ContactReclamation',
      url: configService.config['jahia_ressources_contact_root'].concat('contact-desktop.png'),
      urlMobile: configService.config['jahia_ressources_contact_root'].concat('contact-mobile.png'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    arbitrageImage: {
      alt: 'Arbitrage',
      url: configService.config['jahia_ressources_arbitrage_root'].concat('arbitrage-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_arbitrage_root'].concat('arbitrage-mobile.jpg'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    syntheseImages: {
      mkgDefaultBloc: {
        alt: 'MKG BLOC',
        url: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_bloc/pub.png'),
        urlMobile: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_bloc/pub-mobile.png'),
        urlToRedirect: configService.config['mkg_bloc_endpoint']
      },

      mkgLyfeBloc: {
        alt: 'LYFE BLOC',
        url: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_lyfe_bloc/lyfe.png'),
        urlMobile: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_lyfe_bloc/lyfe.png'),
        urlToRedirect: configService.config['mkg_lyfe_bloc_endpoint']
      }
    }
  };
}

// export function getHeaderUserEre(isFilialeAca: boolean): HeaderUser {
//   const theme = isFilialeAca ? 'aca' : 'alm2';
//   return {
//     dropDown: [
//       {
//         title: 'Consultez vos données personnelles',
//         urlToRedirect: '/activation/pages/secured/display-account.jsf?theme=' + theme,
//         selectionColor: '0088bb',
//         cssClassName: ''
//       },
//       {
//         title: 'Modifiez votre mot de passe',
//         urlToRedirect: '/activation/pages/secured/change-password.jsf?theme=' + theme,
//         selectionColor: '0088bb',
//         cssClassName: ''
//       },
//       {
//         title: 'Modifiez vos questions secrètes',
//         urlToRedirect: '/activation/pages/secured/reset-challenges.jsf?theme=' + theme,
//         selectionColor: '0088bb',
//         cssClassName: ''
//       }
//     ]
//   };
// }

// export function getHeaderUserMdpro(): HeaderUser {
//   return {
//     dropDown: [
//       {
//         title: 'Consultez vos données personnelles',
//         urlToRedirect: '/accueil/vos-donnees-personnelles',
//         selectionColor: '0088bb',
//         cssClassName: ''
//       },
//       {
//         title: 'Modifiez votre mot de passe',
//         urlToRedirect: '/activation/pages/secured/change-password.jsf?theme=alm2',
//         selectionColor: '0088bb',
//         cssClassName: ''
//       },
//       {
//         title: 'Modifiez vos questions secrètes',
//         urlToRedirect: '/activation/pages/secured/reset-challenges.jsf?theme=alm2',
//         selectionColor: '0088bb',
//         cssClassName: ''
//       }
//     ]
//   };
// }
export function getHeaderUserEre(isFilialeAca: boolean): HeaderUser {
  const theme = isFilialeAca ? 'aca' : 'alm2';
  return {
    dropDown: [

      {
          title: 'Données de connexion',
          urlToRedirect: 'https://espace-client.ag2rlamondiale.fr/activation/pages/secured/display-account.jsf?theme=aca ?' + theme,
          selectionColor: '0088bb',
          cssClassName: 'ag2r-134-record-of-situation',
          functionName: 'connexionData',
        },
      {
        title: 'Déconnexion',
        urlToRedirect: '',
        selectionColor: '0088bb',
        cssClassName: 'ag2r-004-turn-off',
        functionName: 'logout'
      }
    ]
  };
}

export function getHeaderUserMdpro(): HeaderUser {
  return {
    dropDown: [

      {
        title: 'Données de connexion',
        urlToRedirect: '/activation/pages/secured/change-password.jsf?theme=alm2',
        selectionColor: '0088bb',
        cssClassName: 'ag2r-091-key',
        functionName: 'connexionData',
      },
      {
        title: 'Déconnexion',
        urlToRedirect: '',
        selectionColor: '0088bb',
        cssClassName: 'ag2r-004-turn-off',
        functionName: 'logout'
      }
    ]
  };
}

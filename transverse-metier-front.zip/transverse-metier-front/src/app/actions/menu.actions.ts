import { ApiAction, LEVEL_SEVERITY_MAJOR } from '@ag2rlamondiale/redux-api-ng';
import { MenuItemData } from '@app/models/client/menu.model';


export const LOAD_MENU = '[MENU]_LOAD';

export interface MenuJson {
  menu: Array<MenuItemData>;
}

export class LoadMenu extends ApiAction<MenuJson> {
  type = LOAD_MENU;

  constructor() {
    super(LOAD_MENU, 'jahia_ressources_menu', null);
    this.payload.severity = LEVEL_SEVERITY_MAJOR;
  }

}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = LoadMenu;

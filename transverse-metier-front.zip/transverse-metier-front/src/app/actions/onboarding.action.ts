import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng/lib/actions/api.actions';
import { OnboardingTerminateModel } from '@app/models/client/onboarding.model';
import { Action } from '@ngrx/store';
import { LectureSujet } from './../models/client/sujets.model';
import { TrackingActionPayload, TypeOriginAction } from './tracking.action';

export const ONBOARDING_START = '[ONBOARDING]_START';
export const ONBOARDING_TERMINATE = '[ONBOARDING]_TERMINATE';

export const PUSH_ONBOARDING_ETAPE = '[ONBOARDING]_PUSH_ONBOARDING_ETAPE';
export const PUSH_CONFIGURER_VOTRE_ESPACE_ETAPE = '[ONBOARDING]_PUSH_CONFIGURER_VOTRE_ESPACE_ETAPE';
export const PUSH_ONBOARDING_SUJETS = '[ONBOARDING]_PUSH_ONBOARDING_SUJETS';
export const CLEAR_ONBOARDING_SUJETS = '[ONBOARDING]_CLEAR_ONBOARDING_SUJETS';
export const TOGGLE_GESTION_FIN_DEFAUT = '[ONBOARDING]_TOGGLE_GESTION_FIN_DEFAUT';
export const TOGGLE_BENEF_CLAUSE_STANDARD = '[ONBOARDING]_TOGGLE_BENEF_CLAUSE_STANDARD';
export const RESET_ONBOARDING_STATE = '[ONBOARDING]_RESET_STATE';
export const ONBOARDING_TERMINATE_IMPERSONNATION = '[ONBOARDING]_TERMINATE_IMPERSONNATION';

export class GetOnboardingStart extends ApiAction<any> {
  constructor() {
    super(ONBOARDING_START, 'backend/onboarding', null);
    this.payload.url = `/start`;
  }
}


export class PostOnboardingTerminate extends ApiAction<any> {
  constructor(param: OnboardingTerminateModel) {
    super(ONBOARDING_TERMINATE, 'backend/onboarding', param);
    this.payload.url = `/terminate`;
    this.payload.method = 'POST';
    this.payload.requestData = param;
  }
}



export class PushEtapeOnboardingPayload {
  etapeOnboarding: number;
}

export class PushEtapeOnboarding implements Action {
  type = PUSH_ONBOARDING_ETAPE;
  constructor(public payload: PushEtapeOnboardingPayload) { }
}

export class PushSelectedSubjectOnboarding implements Action {
  type = PUSH_ONBOARDING_SUJETS;
  constructor(public payload: number) { }
}

export class ClearSubjectOnboarding implements Action {
  type = CLEAR_ONBOARDING_SUJETS;
  constructor(public payload: number) { }
}

export class PushEtapeConfigurerVotreEspace implements Action {
  type = PUSH_CONFIGURER_VOTRE_ESPACE_ETAPE;
  constructor(public payload: number) { }
}

export class ToggleGestionFinanciereDefaut implements Action {
  type = TOGGLE_GESTION_FIN_DEFAUT;
  constructor(public payload: TrackingActionPayload = { tc_category: 'ERE INTEGRATION', tc_action: TypeOriginAction.affichage, tc_label: 'infos_gestion_par_defaut' }) { }
}
export class ToggleBeneficiaireClauseStandard implements Action {
  type = TOGGLE_BENEF_CLAUSE_STANDARD;
  constructor(public payload: TrackingActionPayload = { tc_category: 'ERE INTEGRATION', tc_action: TypeOriginAction.affichage, tc_label: 'clause_standard' }) { }
}

export class ResetState implements Action {
  type = RESET_ONBOARDING_STATE;
  constructor(public payload = null) { }
}


export class PushOnboardingTerminateWithImpersonnation implements Action {
  type = ONBOARDING_TERMINATE_IMPERSONNATION;
  constructor(public payload: LectureSujet[]) { }
}

export type Actions = GetOnboardingStart
  | PostOnboardingTerminate
  | ApiActions
  | PushEtapeOnboarding
  | PushSelectedSubjectOnboarding
  | ClearSubjectOnboarding
  | PushEtapeConfigurerVotreEspace
  | ToggleGestionFinanciereDefaut
  | ToggleBeneficiaireClauseStandard
  | ResetState
  | PushOnboardingTerminateWithImpersonnation;


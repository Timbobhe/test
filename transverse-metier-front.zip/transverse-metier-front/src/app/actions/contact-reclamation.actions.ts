import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import {
  ContactReclamationModel,
  ContactReclamationTerminateModel,
  ReclamationResponseModel
} from '@app/models/client/contact-reclamation-terminate.model';
import { Contrat } from '@app/models/client/contrat.model';
import { Action } from '@ngrx/store';
import { GetContrat } from '@app/actions/common.actions';

export const CONTACT_RECLAMATION_START = '[CONTACT_RECLAMATION]_START';
export const CONTACT_RECLAMATION_CREATE = '[CONTACT_RECLAMATION]_CREATE';
export const CONTACT_RECLAMATION_CHOIX_CONTRAT = '[CONTACT_RECLAMATION]_CHOIX_CONTRAT';
export const CONTACT_RECLAMATION_CHOIX_TYPE_CONTACT = '[CONTACT_RECLAMATION]_CHOIX_TYPE_CONTACT';

export class CreateContactReclamation extends ApiAction<ReclamationResponseModel> {
  constructor(body: ContactReclamationTerminateModel) {
    super(CONTACT_RECLAMATION_CREATE, 'backend/contact', body);
    this.payload.method = 'POST';
    this.payload.requestData = body;
  }
}

export class SelectionContrat implements Action {
  type = CONTACT_RECLAMATION_CHOIX_CONTRAT;

  constructor(public payload: Contrat) {
  }
}

export type TypeContact = 'Contact' | 'Reclamation';

export class SelectionTypeContact implements Action {
  type = CONTACT_RECLAMATION_CHOIX_TYPE_CONTACT;

  constructor(public payload: TypeContact) {
  }
}

export class GetContactReclamationStart extends GetContrat<ContactReclamationModel> {
  constructor() {
    super(CONTACT_RECLAMATION_START, 'backend/contactReclamation', '/start');
  }
}

// rajouter les classes d'actions exposÃ©es pour le reducer
export type Actions =
  | CreateContactReclamation
  | SelectionContrat
  | SelectionTypeContact
  | GetContactReclamationStart
  | ApiActions;

import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng';
import { Compartiments } from '../models/client/compartiments.model';
import { GetContrat } from './common.actions';

export const GET_COMPARTIMENTS = '[COMPARTIMENTS]_GET';

export class GetCompartiments extends GetContrat<Compartiments> {
  type = GET_COMPARTIMENTS;

  constructor() {
    super(GET_COMPARTIMENTS, 'backend/compartiments', null);
  }

}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetCompartiments | ApiActions;

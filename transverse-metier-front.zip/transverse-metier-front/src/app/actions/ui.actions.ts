import { ErrorModel } from '@app/models/client/error.model';
import { Action } from '@ngrx/store';
import { TrackingActionPayload } from './tracking.action';
import { ClearToastMessage, InitApp, PushToastMessage } from '@ag2rlamondiale/transverse-metier-ng';

/** Synthese */
export const PUSH_SELECTED_COMPARTIMENT = '[UI]_PUSH_SELECTED_COMPARTIMENT';
/** Synthese */
export const PUSH_SELECTED_ACTION = '[UI]_PUSH_SELECTED_ACTION';


export const PUSH_ERROR = '[UI]_PUSH_ERROR';
export const CLEAR_ERROR = '[UI]_CLEAR_ERROR';
export const PUSH_TOUR_STEP = '[UI]_PUSH_TOUR_STEP';
export const RESET_TOUR = '[UI]_RESET_TOUR';
export const TOUR_FINISHED = '[UI]_TOUR_FINISHED';
export const START_TOUR = '[UI]_START_TOUR';

export const HIDE_MENU = '[UI]_HIDE_MENU';
export const SET_PARCOURS_URL = '[UI]_SET_PARCOURS_URL';
export const SET_CONTRAT_COMPTE_DEMO = '[UI]_SET_CONTRAT_COMPTE_DEMO';


export class PushSelectedCompartimentPayload extends TrackingActionPayload {
  compartimentSelected: string;
}

export class PushSelectedCompartiment implements Action {
  type = PUSH_SELECTED_COMPARTIMENT;

  constructor(public payload: PushSelectedCompartimentPayload) {
  }
}

export class PushSelectedActionPayload extends TrackingActionPayload {
}

export class PushSelectedAction implements Action {
  type = PUSH_SELECTED_ACTION;

  constructor(public payload: PushSelectedActionPayload) {
  }
}

export class PushError implements Action {
  type = PUSH_ERROR;

  constructor(public payload: ErrorModel) {
  }
}

export class ClearError implements Action {
  type = CLEAR_ERROR;

  constructor(public payload = null) {
  }
}


export class PushTourStepPayload {
  stepOrder: number;
}

export class PushTourStep implements Action {
  type = PUSH_TOUR_STEP;

  constructor(public payload: PushTourStepPayload) {
  }
}

export class ResetTour implements Action {
  type = RESET_TOUR;

  constructor(public payload = null) {
  }
}

export class StartTour implements Action {
  type = START_TOUR;

  constructor(public payload = null) {
  }
}

export class TourFinished implements Action {
  type = TOUR_FINISHED;

  constructor(public payload = null) {
  }
}


export class HideMenu implements Action {
  type = HIDE_MENU;

  constructor(public payload: boolean) {
  }
}


export class SetParcoursUrl implements Action {
  type = SET_PARCOURS_URL;

  constructor(public payload: string) {
  }
}

export class SetContratCompteDemo implements Action {
  type = SET_CONTRAT_COMPTE_DEMO;

  constructor(public payload: string) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions =
  InitApp
  | PushSelectedCompartiment
  | PushError
  | ClearError
  | PushTourStep
  | TourFinished
  | ResetTour
  | StartTour
  | PushToastMessage
  | ClearToastMessage
  | HideMenu
  | SetParcoursUrl
  | SetContratCompteDemo;

import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import {
  ChoixCoordonneesBancaires,
  ChoixRepartitionSupportPayload,
  ChoixReponsePayload,
  DetailVersement,
  EtapeVersement,
  InfoVersementContrat,
  ListQuestionResponses,
  RequestQuestionVersement,
  VersementClient,
  VersementModel,
  VersementTerminateModel
} from '@app/models/client/versement.model';
import { QuestionType } from '@app/models/question-responses.model';
import { Subtitle } from '@app/models/ui.model';
import { Action } from '@ngrx/store';
import { GetContrat } from './common.actions';
import { PostSigelecTerminate } from './sig-elec.action';

export const VERSEMENT_START = '[VERSEMENT]_START';
export const VERSEMENT_GET_QUESTION_OR_NEXT = '[VERSEMENT]_VERSEMENT_GET_QUESTION_OR_NEXT';
export const PUSH_CONTRAT_SELECTED = '[VERSEMENT]_PUSH_CONTRAT';
export const SET_SUBTITLE_VERSEMENT = '[VERSEMENT]_SET_SUBTITLE';
export const VERSEMENT_TERMINATE = '[VERSEMENT]_TERMINATE';
export const SET_PARCOURS_MANUSCRIT_VERSEMENT = '[VERSEMENT]_SET_PARCOURS_MANUSCRIT';
export const VERSEMENT_PUSH_REPONSE = '[VERSEMENT]_PUSH_REPONSE';
export const VERSEMENT_UPDATE_QUESTION_TO_SHOW = '[VERSEMENT]_UPDATE_QUESTION_TO_SHOW';
export const VERSEMENT_MODIFIER_REPONSE = '[VERSEMENT]_MODIFIER_REPONSE';
export const VERSEMENT_GOTO_ETAPE = '[VERSEMENT]_GOTO_ETAPE';
export const VERSEMENT_SET_VERSEMENT_CLIENT = '[VERSEMENT]_SET_VERSEMENT_CLIENT';
export const PUSH_VERSEMENT_ETAPE = '[VERSEMENT]_PUSH_VERSEMENT_ETAPE';
export const VERSEMENT_PUSH_CHOIX_REPARTITION_SUPPORT = '[VERSEMENT]_PUSH_CHOIX_REPARTITION_SUPPORT';
export const VERSEMENT_PUSH_CHOIX_DETAIL = '[VERSEMENT]_PUSH_CHOIX_DETAIL';
export const VERSEMENT_PUSH_COORDONNES_BANCAIRES = '[VERSEMENT]_PUSH_COORDONNES_BANCAIRES';

export class GetVersementStart extends GetContrat<VersementModel> {
  constructor() {
    super(VERSEMENT_START, 'backend/versement', '/start');
  }
}


export interface PushContratSelectedPayload {
  info: InfoVersementContrat;
  setSubtitle: boolean;
}

export class PushContratSelected implements Action {
  type = PUSH_CONTRAT_SELECTED;

  constructor(public payload: PushContratSelectedPayload) {}
}

export class GoToEtapeVersementPayload {
  etape: EtapeVersement;
}

export class GoToEtapeVersement implements Action {
  type = VERSEMENT_GOTO_ETAPE;

  constructor(public payload: GoToEtapeVersementPayload) {}
}

export class SetSubtitleVersement implements Action {
  type = SET_SUBTITLE_VERSEMENT;

  constructor(public payload: Subtitle) {}
}

export class UpdateQuestionToShow implements Action {
  type = VERSEMENT_UPDATE_QUESTION_TO_SHOW;

  constructor(public payload: QuestionType) {}
}

export class SetParcoursManuscritVersement implements Action {
  type = SET_PARCOURS_MANUSCRIT_VERSEMENT;

  constructor(public payload: boolean) {}
}

export class PushReponse implements Action {
  type = VERSEMENT_PUSH_REPONSE;

  constructor(public payload: ChoixReponsePayload) {}
}

export class ModifierReponse implements Action {
  type = VERSEMENT_MODIFIER_REPONSE;

  constructor(public payload: { questionType: QuestionType; etape: EtapeVersement; deplacement: 'next' | 'prev' }) {}
}

export class PushChoixRepartitionSupport implements Action {
  type = VERSEMENT_PUSH_CHOIX_REPARTITION_SUPPORT;

  constructor(public payload: ChoixRepartitionSupportPayload) {}
}

export class PushChoixDetailVersement implements Action {
  type = VERSEMENT_PUSH_CHOIX_DETAIL;

  constructor(public payload: DetailVersement) {}
}

export class SetVersementClient implements Action {
  type = VERSEMENT_SET_VERSEMENT_CLIENT;

  constructor(public payload: VersementClient) {}
}

export class GetVersementQuestionOrNext extends ApiAction<ListQuestionResponses> {
  constructor(request: RequestQuestionVersement) {
    super(VERSEMENT_GET_QUESTION_OR_NEXT, 'backend/versement', request);

    this.payload.url = '/question-or-next';
    this.payload.method = 'POST';
    this.payload.requestData = request;
  }
}

export class PostVersementTerminate extends PostSigelecTerminate {
  constructor(request: VersementTerminateModel) {
    super(VERSEMENT_TERMINATE, 'backend/versement', request);
    this.payload.requestData = request;
  }
}

export class PushCoordonneesBancairesVersement implements Action {
  type = VERSEMENT_PUSH_COORDONNES_BANCAIRES;
  constructor(public payload: ChoixCoordonneesBancaires) {}
}

export type Actions = GetVersementStart
  | PushContratSelected
  | GoToEtapeVersement
  | SetSubtitleVersement
  | SetParcoursManuscritVersement
  | PostVersementTerminate
  | PushReponse
  | ModifierReponse
  | GetVersementQuestionOrNext
  | PushChoixRepartitionSupport
  | PushChoixDetailVersement
  | UpdateQuestionToShow
  | SetVersementClient
  | PushCoordonneesBancairesVersement;

import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { Evenement } from '@app/models/client/evenement.model';

export const EVEN_GET_NEXT = '[EVEN]_GET_NEXT';
export const EVEN_CANCEL = '[EVEN]_CANCEL';

export class GetNextEven extends ApiAction<Evenement> {
  constructor() {
    super(EVEN_GET_NEXT, 'backend/evenements', null);
    this.payload.url = `/next`;
  }
}


export class EvenPayload {
  even: Evenement;
}

export class CancelEven extends ApiAction<Evenement> {
  type = EVEN_CANCEL;

  constructor(critere: EvenPayload) {
    super(EVEN_CANCEL, 'backend/evenements', critere);
    this.payload.url = `/cancel`;
    this.payload.method = 'POST';
    this.payload.requestData = critere.even;
  }

}


// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetNextEven | CancelEven | ApiActions;

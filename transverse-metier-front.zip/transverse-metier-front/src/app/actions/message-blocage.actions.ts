import { Action } from '@ngrx/store';

export const PUSH_MESSAGE_BLOCAGE = '[BLOCAGE]_PUSH_MESSAGE';

export class PushMessageBlocagePayload {
  message: string;
}

export class PushMessageBlocage implements Action {
  type = PUSH_MESSAGE_BLOCAGE;

  constructor(public payload: PushMessageBlocagePayload) {
  }
}

export const CLEAR_MESSAGE_BLOCAGE = 'CLEAR_MESSAGE_BLOCAGE';

export class ClearMessageBlocage implements Action {
  type = CLEAR_MESSAGE_BLOCAGE;

  constructor(public payload = null) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = PushMessageBlocage | ClearMessageBlocage;

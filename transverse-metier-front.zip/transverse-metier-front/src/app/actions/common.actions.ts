import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';

export class GetContrat<T> extends ApiAction<T> {
  hasQueryParams = false;

  constructor(label: string, endpoint: string, path: string) {
    super(label, endpoint, null);
    this.payload.inputParams = {};
    if (path) {
      this.payload.url = path;
    }
    const contratId = UrlUtils.getHashParam('onglet');
    if (contratId) {
      this.addQueryParam('contrat', contratId);
    }
    const compartimentId = UrlUtils.getHashParam('compartiment');
    if (compartimentId) {
      this.addQueryParam('compartiment', compartimentId);
    }
  }

  addQueryParam(key: string, value: string) {
    this.payload.url += this.hasQueryParams ? '&' : (this.hasQueryParams = true, '?');
    this.payload.url += key;
    if (value) {
      this.payload.url += '=' + value;
      this.payload.inputParams[key] = value;
    }
  }
}

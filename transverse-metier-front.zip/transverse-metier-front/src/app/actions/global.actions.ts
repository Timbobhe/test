import { GlobalState } from '@app/reducers/_index';
import { ChainAction, ExecuteAction, RESET_STATE, ResetStateAction as BaseResetStateAction } from '@ag2rlamondiale/transverse-metier-ng';

export { RESET_STATE };

export class ResetStateAction extends BaseResetStateAction<GlobalState> {
}

export type Actions = ChainAction | ExecuteAction | ResetStateAction;



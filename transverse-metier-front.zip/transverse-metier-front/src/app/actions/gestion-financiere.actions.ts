import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import {
  GestionFinanciereActuelleCompartiment,
  GestionFinanciereActuelleContrat,
  GestionFinanciereContrat,
  GestionFinanciereModel,
  ModeGestionMdproType
} from '@app/models/client/gestion-financiere.model';
import { CompartimentId, ContratId } from '@app/models/client/contrat.model';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng/lib/actions/api.actions';
import { GrilleInv } from '@app/models/client/grille.model';

export const DEFAULT_GRILLE_FETCH = '[GESTION_FINANCIERE]_DEFAULT_GRILLE_FETCH';
export const GESTION_FINANCIERE_COMPARTIMENT_FETCH = '[GESTION_FINANCIERE]_COMPARTIMENT_FETCH';
export const GESTION_FINANCIERE_CONTRAT_FETCH = '[GESTION_FINANCIERE]_CONTRAT_FETCH';
export const GESTION_FINANCIERE_ACTUELLE_CONTRAT_FETCH = '[GESTION_FINANCIERE]_ACTUELLE_CONTRAT_FETCH';
export const GESTION_FINANCIERE_ACTUELLE_COMPARTIMENT_FETCH = '[GESTION_FINANCIERE]_ACTUELLE_COMPARTIMENT_FETCH';

export class GestionFinancierePayload {
  contratId: ContratId;
  fonctionnalite: FonctionnaliteType;
  compartimentId?: CompartimentId;
  gerePlacementsFinanciersDifferentsAutorises?: boolean;
  modeGestion?: ModeGestionMdproType;
}

export class GestionFinanciereCompartimentFetch extends ApiAction<GestionFinanciereModel> {
  constructor(param: GestionFinancierePayload) {
    super(GESTION_FINANCIERE_COMPARTIMENT_FETCH, 'backend/gestionFinanciere', param);
    this.payload.url = `/compartiment`;
    this.payload.requestData = param;
    this.payload.method = 'POST';
  }
}

export class GestionFinanciereContratFetch extends ApiAction<GestionFinanciereContrat> {
  constructor(param: GestionFinancierePayload) {
    super(GESTION_FINANCIERE_CONTRAT_FETCH, 'backend/gestionFinanciere', param);
    this.payload.url = `/contrat`;
    this.payload.requestData = param;
    this.payload.method = 'POST';
  }
}

export class GestionFinanciereActuellePayload {
  contratId: ContratId;
  compartimentId: CompartimentId;
  tousCompartimentsSelected = false;
  placementsFinanciersDifferentsAutorises: boolean;
}

export class GestionFinanciereActuelleContratFetch extends ApiAction<GestionFinanciereActuelleContrat> {
  constructor(param: GestionFinanciereActuellePayload) {
    super(GESTION_FINANCIERE_ACTUELLE_CONTRAT_FETCH, 'backend/gestionFinanciere', param);
    this.payload.url = '/actuelle/contrat';
    this.payload.requestData = param;
    this.payload.method = 'POST';
  }
}

export class GestionFinanciereActuelleCompartimentFetch extends ApiAction<GestionFinanciereActuelleCompartiment> {
  constructor(param: GestionFinanciereActuellePayload) {
    super(GESTION_FINANCIERE_ACTUELLE_COMPARTIMENT_FETCH, 'backend/gestionFinanciere', param);
    this.payload.url = '/actuelle/compartiment';
    this.payload.requestData = param;
    this.payload.method = 'POST';
  }
}

export class DefaultGrilleFetch extends ApiAction<GrilleInv> {

  constructor() {
    super(DEFAULT_GRILLE_FETCH, 'backend/defaultGrille', null);
  }
}

export type Actions =
  | ApiActions
  | DefaultGrilleFetch
  | GestionFinanciereCompartimentFetch
  | GestionFinanciereContratFetch
  | GestionFinanciereActuelleContratFetch
  | GestionFinanciereActuelleCompartimentFetch;

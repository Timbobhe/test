import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { CompartimentId, MiniContrat, toCompartimentId } from '@app/models/client/contrat.model';
import { GlobalState } from '@app/reducers/_index';
import { Subscription } from 'rxjs';
// @ts-ignore
import arbitrageDocumentStyle from '@app/../styles/document/arbitrage-document.css';
// @ts-ignore
import qadDocumentStyle from '@app/../styles/document/base-document.css';
import { PartenaireIframeService, STEP_COMPLETED } from '@ag2rlamondiale/transverse-metier-ng';
import {Location} from '@angular/common';

export const jahiaMap = new Map([
  ['contenuFinaliserDemande', '_CONTENU_FINALISER_DEMANDE'],
  ['contenuVerifierDemande', '_CONTENU_VERIFIER_DEMANDE'],
  ['contenuImprimerDemande', '_CONTENU_IMPRIMER_DEMANDE'],
  ['contenuEnvoyerDemande', '_CONTENU_ENVOYER_DEMANDE']
]);

@Component({
  selector: 'app-arbitrage-confirmation',
  templateUrl: './arbitrage-confirmation.component.html',
  styleUrls: ['./arbitrage-confirmation.component.scss']
})
export class ArbitrageConfirmationComponent implements OnInit, OnDestroy {
  contratSelected: MiniContrat;
  compartimentId: CompartimentId;
  subscriptions: Subscription[] = [];
  htmlContentArbitrage: string;
  htmlContentQAD: string;
  isERE = false;
  contribIdPrefix: string;

  contenuFinaliserDemande: string;
  contenuVerifierDemande: string;
  contenuImprimerDemande: string;
  contenuEnvoyerDemande: string;

  constructor(private readonly download: DownloadService,
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly location: Location,
    private readonly partenaireIframe: PartenaireIframeService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      selectArbitrage(this.store).subscribe(x => {
        this.contratSelected = x.arbitrage.contratSelected.contrat;
        const choixCompartiment = x.arbitrage.questions.choixCompartimentERE;
        if (!choixCompartiment.choix.value.tousCompartiments) {
          this.compartimentId = toCompartimentId(choixCompartiment.choix.value.compartiment);
        }

        this.htmlContentQAD = x.qad.htmlContent;
        this.isERE = this.contratSelected.codeSilo === 'ERE';
      })
    );

    this.contribId();
    this.htmlContentArbitrage = document.getElementsByClassName('confirmation-choix-client').item(0).innerHTML;

    this.partenaireIframe.postStep(STEP_COMPLETED);
  }

  contribId() {
    this.contribIdPrefix = this.isERE ? 'ARBITRAGE_ERE' : 'ARBITRAGE_MDPRO'; // this.isERE à la place de true
    this.contenuFinaliserDemande = this.contribIdPrefix + jahiaMap.get('contenuFinaliserDemande');
    this.contenuVerifierDemande = this.contribIdPrefix + jahiaMap.get('contenuVerifierDemande');
    this.contenuImprimerDemande = this.contribIdPrefix + jahiaMap.get('contenuImprimerDemande');
    this.contenuEnvoyerDemande = this.contribIdPrefix + jahiaMap.get('contenuEnvoyerDemande');
  }

  downloadDocuments() {
    this.downloadArbitrage();
    this.downloadQad();
  }

  downloadArbitrage() {
    this.download.downloadDocument({
      codeDocument: this.getCodeDocumentArbitrageByCodeSilo(this.isERE),
      contratId: this.contratSelected,
      compartimentId: this.compartimentId,
      htmlContent: this.htmlContentArbitrage, htmlStyle: arbitrageDocumentStyle
    });
  }

  downloadQad() {
    if (this.htmlContentQAD != null) {
      this.download.downloadDocument({
        codeDocument: this.getCodeDocumentQadByCodeSilo(this.isERE),
        contratId: this.contratSelected,
        compartimentId: this.compartimentId,
        htmlContent: this.htmlContentQAD, htmlStyle: qadDocumentStyle
      });
    }
  }

  goToPreviousStep() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  getCodeDocumentArbitrageByCodeSilo(isEre: boolean) {
    return isEre ? 'DEMANDE_ARBITRAGE' : 'DEMANDE_ARBITRAGE_MDPRO';
  }

  getCodeDocumentQadByCodeSilo(isEre: boolean) {
    return isEre ? 'RESULTAT_QUAD' : 'DEVOIR_CONSEIL_MDPRO';
  }
}

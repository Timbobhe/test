import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ArbitrageTrackingEffects } from '@app/modules/arbitrage/arbitrage-tracking-effects.service';
import { IdentiteNumModule, SharedModule } from '@ag2rlamondiale/transverse-metier-ng';
import { EffectsModule } from '@ngrx/effects';
import { EcrsCommonModule } from '../ecrs-common/ecrs-common.module';
import { ArbitrageChoixContratComponent } from './arbitrage-choix-contrat/arbitrage-choix-contrat.component';
import { ArbitrageConfirmationComponent } from './arbitrage-confirmation/arbitrage-confirmation.component';
import { ArbitrageDemandeComponent } from './arbitrage-demande/arbitrage-demande.component';
import { ArbitrageDemsigelecComponent } from './arbitrage-demsigelec/arbitrage-demsigelec.component';
import { ArbitrageDetailChoixClientComponent } from './arbitrage-detail-choix-client/arbitrage-detail-choix-client.component';
import { ArbitrageEtapesComponent } from './arbitrage-etapes/arbitrage-etapes.component';
import { ArbitrageIdentiteNumComponent } from './arbitrage-identite-num/arbitrage-identite-num.component';
import { ArbitrageMatchAccountComponent } from './arbitrage-match-account/arbitrage-match-account.component';
import { ArbitrageEreChoixArbitrageComponent } from './arbitrage-parcours-ere/arbitrage-ere-choix-arbitrage/arbitrage-ere-choix-arbitrage.component';
import { ArbitrageEreChoixRepartitionComponent } from './arbitrage-parcours-ere/arbitrage-ere-choix-repartition/arbitrage-ere-choix-repartition.component';
import { ArbitrageEreRecapSignatureComponent } from './arbitrage-parcours-ere/arbitrage-ere-recap-signature/arbitrage-ere-recap-signature.component';
import { ArbitragePartielSupportComponent } from './arbitrage-partiel/arbitrage-partiel-support/arbitrage-partiel-support.component';
import { ArbitragePartielComponent } from './arbitrage-partiel/arbitrage-partiel.component';
import { ArbitrageQadLauncherComponent } from './arbitrage-qad-launcher/arbitrage-qad-launcher.component';
import { ArbitrageResumeChoixComponent } from './arbitrage-resume-choix/arbitrage-resume-choix.component';
import { ArbitrageRoutingModule } from './arbitrage-routing.module';
import { ArbitrageSigelecRedirectComponent } from './arbitrage-sigelec-redirect/arbitrage-sigelec-redirect.component';
import { ArbitrageComponent } from './arbitrage.component';
import { ArbitragePartenaireTrackingService } from '@app/modules/arbitrage/arbitrage-partenaire-tracking.service';
import { QadModule } from '@app/modules/qad/qad.module';
import { ArbitrageMdpConfirmationPropositionQadComponent } from './arbitrage-mdp-confirmation-proposition-qad/arbitrage-mdp-confirmation-proposition-qad.component';
import { ArbitrageConsentementComponent } from './arbitrage-consentement/arbitrage-consentement.component';
import { ArbitrageMdpChoixModeGestionComponent } from './arbitrage-mdp-choix-mode-gestion/arbitrage-mdp-choix-mode-gestion.component';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';


@NgModule({
  imports: [
    CommonModule,
    JahiaNgModule,
    SharedModule,
    EcrsCommonModule,
    ArbitrageRoutingModule,
    IdentiteNumModule,
    EffectsModule.forFeature([ArbitrageRouteEtapeService, ArbitrageTrackingEffects, ArbitragePartenaireTrackingService]),
    QadModule,
  ],
  declarations: [
    ArbitrageComponent,
    ArbitrageDemandeComponent,
    ArbitrageIdentiteNumComponent,
    ArbitrageMatchAccountComponent,
    ArbitrageChoixContratComponent,
    ArbitrageConfirmationComponent,
    ArbitrageEtapesComponent,
    ArbitrageEreChoixArbitrageComponent,
    ArbitrageResumeChoixComponent,
    ArbitrageEreRecapSignatureComponent,
    ArbitrageQadLauncherComponent,
    ArbitragePartielComponent,
    ArbitragePartielSupportComponent,
    ArbitrageEreChoixRepartitionComponent,
    ArbitrageDetailChoixClientComponent,
    ArbitrageSigelecRedirectComponent,
    ArbitrageDemsigelecComponent,
    ArbitrageMdpConfirmationPropositionQadComponent,
    ArbitrageConsentementComponent,
    ArbitrageMdpChoixModeGestionComponent
  ],
  exports: [
    ArbitragePartielComponent
  ]
})
export class ArbitrageModule {
}

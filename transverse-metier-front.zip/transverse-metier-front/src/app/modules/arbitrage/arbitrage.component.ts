import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subtitle } from '@app/models/ui.model';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { GetArbitrageStart } from '@app/actions/arbitrage.action';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';
import { EtapeInit } from '@app/models/client/arbitrage.model';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';

@Component({
  selector: 'app-arbitrage',
  templateUrl: './arbitrage.component.html',
  styleUrls: ['./arbitrage.component.scss']
})
export class ArbitrageComponent implements OnInit, OnDestroy {
  info$: Observable<{ contrats: MiniContrat[], contratSelected: MiniContrat }>;
  subtitle$: Observable<Subtitle>;

  private subscriptions: Subscription[] = [];

  constructor(
    private readonly jahiaService: JahiaService,
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly routeEtape: ArbitrageRouteEtapeService) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'arbitrage', 'prevalidation', 'identiteNum');

    this.subtitle$ = selectArbitrage(this.store).pipe(
      map(x => x.arbitrage.subtitle),
      map(s => s != null && s.id ? s : null));

    this.info$ = selectArbitrage(this.store).pipe(
      filter(x => x.arbitrage.isFetched),
      map(x => {
        const contrats = [];
        x.arbitrage.arbitrageModel.arbitrages.forEach(info => contrats.push(info.contrat));
        const contratSelected = x.arbitrage.contratSelected.contrat;
        return {contrats, contratSelected};
      })
    );

    this.store.dispatch(new GetArbitrageStart());
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  goToChoixContrat() {
    this.store.dispatch(tracking(Categorie.arbitrage, TypeOriginAction.modifierArbitrage, 'contrat'));
    this.routeEtape.navigateToEtape(EtapeInit);
  }
}

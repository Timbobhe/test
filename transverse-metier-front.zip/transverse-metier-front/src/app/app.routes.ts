import { Routes } from '@angular/router';
import { ModificationClauseBeneficiaireGuard } from '@app/authguards/modification-clause-beneficiaire.guard';
import { OnboardingGuard } from '@app/authguards/onboarding.guard';
import * as fonctionnalites from '@app/consts/fonctionnalites.const';
import { FunctionalityUnauthorizedComponent } from '@app/modules/functionality-unauthorized/functionality-unauthorized.component';
import { ArbitrageGuard } from './authguards/arbitrage.guard';
import { AuthBlocageConsole } from './authguards/auth-blocage-console.guard';
import { AuthLoginCas } from './authguards/auth-login.guard';
import { BiaGuard } from './authguards/bia.guard';
import { CoordonneesBancairesGuard } from './authguards/CoordonneesBancaires.guard';
import { SyntheseGuard } from './authguards/synthese.guard';
import { VersementGuard } from './authguards/versement.guard';
import { ObjectifModificationComponent } from './modules/synthese/objectif-complet/objectif-modification/objectif-modification.component';
import { ArretVersementProgrammeGuard } from '@app/authguards/arret-versement-programme.guard';

export const ROUTES: Routes = [
  {
    path: '',
    canActivate: [AuthLoginCas],
    canActivateChild: [AuthBlocageConsole],
    children: [
      {
        path: 'modifier-objectif',
        component: ObjectifModificationComponent,
        data: {id: 'objectif'}
      },
      {
        path: 'synthese-des-comptes',
        loadChildren: './modules/synthese/synthese.module#SyntheseModule',
        data: {id: 'synthese'},
        canActivate: [SyntheseGuard]
      },
      {
        path: 'accueil',
        loadChildren: './modules/onboarding/onboarding.module#OnboardingModule',
        data: {id: fonctionnalites.ONBOARDING},
        canActivate: [OnboardingGuard]
      },
      {
        path: 'bulletin-affiliation',
        loadChildren: './modules/bia/bia.module#BiaModule',
        data: {id: fonctionnalites.COMPLETER_BIA},
        canActivate: [BiaGuard]
      },
      {
        path: 'fonctionnalite-inaccessible',
        component: FunctionalityUnauthorizedComponent
      },
      {
        path: 'nous-contacter',
        loadChildren: './modules/contact-reclamation/contact-reclamation.module#ContactReclamationModule',
        data: {id: ['ContactFormulaire', 'ReclamationFormulaire']}
      },
      {
        path: 'coordonnees-bancaires',
        loadChildren: './modules/coordonnees-bancaires/coordonnees-bancaires.module#CoordonneesBancairesModule',
        data: {id: [fonctionnalites.COORDONNEES_BANCAIRES]},
        canActivate: [CoordonneesBancairesGuard]
      },
      {
        path: 'article',
        loadChildren: './modules/article/article.module#ArticleModule',
        data: {id: 'article'}
      },
      {
        path: 'clause-beneficiaire',
        loadChildren:
          './modules/modification-clause-beneficiaire/modification-clause-beneficiaire.module#ModificationClauseBeneficiaireModule',
        data: {id: fonctionnalites.MODIF_CLAUSE_BENEFICIAIRE},
        canActivate: [ModificationClauseBeneficiaireGuard]
      },
      {
        path: 'modification-gestion-financiere',
        loadChildren: './modules/arbitrage/arbitrage.module#ArbitrageModule',
        data: {id: fonctionnalites.ARBITRAGE},
        canActivate: [ArbitrageGuard]
      },
      {
        path: 'versement',
        loadChildren: './modules/versement/versement.module#VersementModule',
        data: {id: fonctionnalites.VERSEMENT},
        canActivate: [VersementGuard]
      },
      {
        path: 'arret-versement',
        loadChildren: './modules/arret-versement-programme/arret-versement-programme.module#ArretVersementProgrammeModule',
        data: {id: fonctionnalites.ARRET_VERSEMENT},
        canActivate: [ArretVersementProgrammeGuard]
      },
      {
        path: 'vos-donnees',
        loadChildren: './modules/versement-pagehub/versement-pagehub.module#VersementPagehubModule',
        data: {id: fonctionnalites.VERSEMENT},
        canActivate: []
      },
      {
        path: 'en-savoir-plus',
        loadChildren: './modules/en-savoir-plus/en-savoir-plus.module#EnSavoirPlusModule',
        canActivate: []
      },
      {
        path: 'compte-demo',
        loadChildren: './modules/compte-demo/compte-demo.module#CompteDemoModule',
        data: {id: fonctionnalites.COMPTE_DEMO}
      },
      {
        path: '**',
        redirectTo: 'accueil',
        pathMatch: 'full'
      }
    ]
  }
];

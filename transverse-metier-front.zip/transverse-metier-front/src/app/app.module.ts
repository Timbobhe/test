import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { GlobalErrorHandler, MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { ReduxApiNgModule } from '@ag2rlamondiale/redux-api-ng';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BiaGuard } from '@app/authguards/bia.guard';
import { ModificationClauseBeneficiaireGuard } from '@app/authguards/modification-clause-beneficiaire.guard';
import { OnboardingGuard } from '@app/authguards/onboarding.guard';
import { FunctionalityUnauthorizedComponent } from '@app/modules/functionality-unauthorized/functionality-unauthorized.component';
import * as fromRoot from '@app/reducers/_index';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { JoyrideModule } from 'ngx-joyride';
import { ButtonModule } from 'primeng/button';
import { ChartModule } from 'primeng/chart';
import { DialogModule } from 'primeng/dialog';
import { PanelModule } from 'primeng/panel';
import { ToastModule } from 'primeng/toast';
import { AppComponent } from './app.component';
import { ROUTES } from './app.routes';
import { ArbitrageGuard } from './authguards/arbitrage.guard';
import { AuthBlocageConsole } from './authguards/auth-blocage-console.guard';
import { AuthLoginCas } from './authguards/auth-login.guard';
import { SyntheseGuard } from './authguards/synthese.guard';
import { MessageBlocageComponent } from './components/message-blocage/message-blocage.component';
import { PostLazyLoaderComponent } from './components/post-lazy-loader/post-lazy-loader.component';
import { EcrsEffects } from './effects/ecrs.effects';
import { jahiaConfig } from './jahia.config';
import { EcrsCommonModule } from './modules/ecrs-common/ecrs-common.module';
import { ObjectifModificationComponent } from './modules/synthese/objectif-complet/objectif-modification/objectif-modification.component';
import {
  APP_CONFIG,
  BackendService,
  CasService,
  GlobalEffects,
  Globals,
  SharedModule,
  TagCommanderEffect,
  THEME_CONFIG,
  TRACKING_CONFIG
} from '@ag2rlamondiale/transverse-metier-ng';
import { AppTrackingEffects } from '@app/app-tracking-effects.service';
import { EcrsTrackingConfig } from '@app/consts/tag-commander.consts';
import { RouterModule } from '@angular/router';
import { AppConfiguration } from '@app/consts/app.consts';
import { HttpInterceptorProviders2 } from '@app/interceptors';
import { EcrsThemeConfig } from '@app/themes/theme.config';
import { HttpClientXsrfModule } from '@angular/common/http';
import { DynatraceService } from './services/dynatrace.service';
import { MessageIndisponibiliteComponent } from './modules/ecrs-common/components/message-indisponibilite/message-indisponibilite.component';


registerLocaleData(localeFr, 'fr');

@NgModule({
  declarations: [
    AppComponent,
    PostLazyLoaderComponent,
    MessageBlocageComponent,
    ObjectifModificationComponent,
    FunctionalityUnauthorizedComponent,
    MessageIndisponibiliteComponent
  ],
  imports: [
    BrowserModule,
    HttpClientXsrfModule.withOptions({
      headerName: 'X-XSRF-A1573-TOKEN',
      cookieName: 'XSRF-A1573-TOKEN'
    }),
    BrowserAnimationsModule,
    StoreModule.forRoot(fromRoot.reducers, {metaReducers: fromRoot.metaReducers}),
    EffectsModule.forRoot([EcrsEffects, AppTrackingEffects, GlobalEffects, TagCommanderEffect]),
    StoreRouterConnectingModule.forRoot(),
    StoreDevtoolsModule.instrument({
      maxAge: 25 //  Retains last 25 states
    }),
    JoyrideModule.forRoot(),
    SharedModule,
    RouterModule.forRoot(ROUTES, {useHash: true, enableTracing: false}),
    MetisNgModule.forRoot(),
    ReduxApiNgModule,
    JahiaNgModule.forRoot({config: jahiaConfig}),
    DialogModule,
    ButtonModule,
    PanelModule,
    ChartModule,
    EcrsCommonModule,
    ToastModule
  ],
  providers: [
    {provide: ErrorHandler, useClass: GlobalErrorHandler},
    {provide: TRACKING_CONFIG, useValue: EcrsTrackingConfig},
    {provide: APP_CONFIG, useValue: AppConfiguration},
    {provide: THEME_CONFIG, useValue: EcrsThemeConfig},
    HttpInterceptorProviders2,
    BackendService,
    CasService,
    AuthLoginCas,
    AuthBlocageConsole,
    OnboardingGuard,
    SyntheseGuard,
    BiaGuard,
    ArbitrageGuard,
    ModificationClauseBeneficiaireGuard,
    Globals,
    DynatraceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

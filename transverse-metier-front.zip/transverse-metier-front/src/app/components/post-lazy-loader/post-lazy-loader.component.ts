import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-lazy-loader',
  templateUrl: './post-lazy-loader.component.html',
  styleUrls: ['./post-lazy-loader.component.scss']
})
export class PostLazyLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

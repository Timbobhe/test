import { Menu } from '@app/models/client/menu.model';
import { menuJson } from '../../../test/menu.mocks';

describe('menu.model', () => {

  let menu: Menu;

  beforeAll(() => {
    menu = Menu.fromMenuJson(menuJson);
  });

  it('menu with fonctionnalites', () => {
    for (let item of menu.items) {
      expect(item.fonctionnalites.length).toBeGreaterThan(0);
    }
  });

  it('menu find completerBIA', () => {
    const menuItem = menu.findMenuItem('completerBIA');
    expect(menuItem).toBeTruthy();
    expect(menuItem.application).toEqual('ecrs');
  });

  it('menu find contact', () => {
    const menuItemContactFormulaire = menu.findMenuItem('ContactFormulaire');
    const menuItemReclamationFormulaire = menu.findMenuItem('ReclamationFormulaire');
    expect(menuItemContactFormulaire).toBeTruthy();
    expect(menuItemContactFormulaire).toEqual(menuItemReclamationFormulaire);
    expect(menuItemContactFormulaire.application).toEqual('ecrs');
  });

});

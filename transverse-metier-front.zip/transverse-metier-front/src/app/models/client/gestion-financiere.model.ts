import {
  GrilleInvestissementModel,
  InfosRepartitionSupport,
  RepartitionSupport,
  Support
} from '@app/models/client/grille.investissement.model';
import { CompartimentId } from '@app/models/client/contrat.model';

export class GestionFinanciereActuelleMdp {
  fiscalitePEP = false;
  fiscalitePERP = false;
  modeGestionMDPROSource: ModeGestionMdproType;
  idGrilleSource: string;
}

export class GestionFinanciereModel {
  grillesProfilsNiveau1: GrilleInvestissementModel[];
  qadEligible: boolean;
  hasUniteDeCompte: boolean;
}

export class GestionFinanciereCompartiments {
  compartimentIds: CompartimentId[];
  gestionFinanciere: GestionFinanciereModel;
}

export class GestionFinanciereContrat {
  listePourCompartiments: GestionFinanciereCompartiments[];
}

export class GestionFinanciereActuelleCompartiment {
  compartimentIds: CompartimentId[];
  gestionFinanciere: Support[];
  montantARepartir: number;
}

export class GestionFinanciereActuelleContrat {
  listePourCompartiments: GestionFinanciereActuelleCompartiment[];
}

export class SupportNouvelleRepartitionCompartiment {
  compartimentId: CompartimentId;
  repartition: RepartitionSupport[];
}

export class SupportRepartitionActuelleCompartiment {
  compartimentId: CompartimentId;
  repartition: InfosRepartitionSupport[];
  arbitragePartiel: boolean;
  unite: string;
}

export class GestionFinanciereResponse {
  gestionFinanciereContrat: GestionFinanciereContrat;
  gestionFinanciereCompartiment: GestionFinanciereModel;
  gestionFinanciereActuelleContrat: GestionFinanciereActuelleContrat;
  gestionFinanciereActuelleCompartiment: GestionFinanciereActuelleCompartiment;
}

export type ModeGestionMdproType = 'LIBRE' | 'PILOTEE' | 'HORIZON' | 'DYNAMISATION' | 'PEP' | 'TERME';

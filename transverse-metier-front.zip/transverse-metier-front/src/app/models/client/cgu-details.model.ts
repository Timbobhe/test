
export class CguDetails {
  idCgu: string;
  textCgu: string;
  urlPdfCgu: string;
}

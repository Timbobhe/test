export type OperationType = 'EBIA' | 'RIBA' | 'VR' | 'VRLI' | 'VRPG' | 'CBF' | 'ARBI';

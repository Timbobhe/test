// {"id":null,
// "typeEvenement":{"codeEvenement":"ERE_PND_3","categorie":{"codeCategorie":"CAT_DONNEES_PERSO","codeApplication":"A1324","ordre":1,"description":"Categorie données perso"},"ordre":3,"dateDebut":null,"dateFin":null,"nbDeclenchementsMaxPeriode":3,"periodeDeclenchement":null,"delaiAvantReactivation":null,"modeAction":"OBLI","titre":"ERE_PND_Titre","contenu":"ere.evenements.contenu.erePnd3","actionTraiter":"ERE_PND_TRAITER","actionAnnuler":null,"lienRedirection":"ModifDonneesPerso","perimetreEvenements":[],"libEvenement":"Pli non distribué 3 fois","dirty":false},
// "idGdi":"5qkpcx","numContrat":null,"etatTraitement":null,"dateDebut":"2019-08-02T10:13:01.899+0000","dateFin":null}

// { "id": 22461, "typeEvenement": { "codeEvenement": "ERE_PND_3", "categorie": { "codeCategorie": "CAT_DONNEES_PERSO", "codeApplication": "A1324", "ordre": 1, "description": "Categorie données perso" }, "ordre": 3, "dateDebut": null, "dateFin": null, "nbDeclenchementsMaxPeriode": 3, "periodeDeclenchement": null, "delaiAvantReactivation": null, "modeAction": "OBLI", "titre": "ERE_PND_Titre", "contenu": "ere.evenements.contenu.erePnd3", "actionTraiter": "ERE_PND_TRAITER", "actionAnnuler": null, "lienRedirection": "ModifDonneesPerso", "perimetreEvenements": [], "libEvenement": "Pli non distribué 3 fois", "dirty": false }, "idGdi": "5qkpcx", "numContrat": null, "etatTraitement": null, "dateDebut": "2019-08-05T11:43:27.241+0000", "dateFin": null }

export class TypeEvenement {
  codeEvenement: string;
  categorie: CategorieEvenement;
  ordre: number;
  dateDebut?: Date;
  dateFin?: Date;
  nbDeclenchementsMaxPeriode: number;
  periodeDeclenchement?: any;
  delaiAvantReactivation?: any;
  modeAction: string;
  titre: string;
  contenu: string;
  actionTraiter: string;
  actionAnnuler?: any;
  lienRedirection: string;
  perimetreEvenements: any[];
  libEvenement: string;
  dirty: boolean;
}

export class CategorieEvenement {
  codeCategorie: string;
  codeApplication: string;
  ordre: number;
  description: string;
}


export type EtatTraitement = 'TRAI' | 'ANNU';

export class Evenement {
  id?: any;
  typeEvenement: TypeEvenement;
  idGdi: string;
  numContrat?: any;
  etatTraitement?: EtatTraitement;
  dateDebut: Date;
  dateFin?: Date;
}

import {
  CodeSiloType,
  CompartimentId,
  ContratId,
  MiniContrat,
  toCompartimentId
} from '@app/models/client/contrat.model';

import { Question, QuestionReponses, QuestionState, QuestionType, Reponse } from '@app/models/question-responses.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import {
  ChoixCompartiment,
  FrequenceVirementType,
  ListQuestionResponses,
  ModeVersement,
  ResponseVersementDeductibiliteType,
  VersementProgramme
} from '@app/models/client/versement.model';
import { Document } from '@app/modules/ecrs-common/services/download.service';
import { ArretVersementProgrammeState } from '@app/reducers/arret-versement-programme.reducer';
import { GetArretVersementQuestionOrNext } from '@app/actions/arret-versement-programme.actions';


export class InfoArretVersementContrat {
  contrat: MiniContrat;
  arretVersements: ArretVersement[];
  sigElecOff: boolean; //TODO sigelec autorisé ou pas
  bloque: boolean;
}

export class ArretVersementProgrammeModel {
  infos: InfoArretVersementContrat[];
  sigElecOff: boolean;
}

export class ArretVersement {
  compartimentSelected: MiniContrat;
  versementProgramme: VersementProgramme;
}

export class ArretVersementClient {
  contrat: MiniContrat;
  compartimentId: CompartimentId;
  montantVersement: number;
  periodiciteVersement: FrequenceVirementType;
  dateVersement: Date;
  dateFinVersement: Date;
  parcoursManuscrit: boolean;
  deductibilite: ResponseVersementDeductibiliteType;
}

export type ConsentementId = keyof EngagementsEre;

export class EngagementsEre {
  certificationRenseignement: boolean;
}

export interface Etape {
  index: number;
  label: string;
  questionsType?: { [silo in CodeSiloType]: QuestionType[] };
}

export const EtapeInit: Etape = {index: -1, label: 'Choix du contrat'};
export const Etape0: Etape = {
  index: 0,
  label: 'Arrêt du versement',
  questionsType: {
    ERE: ['VERSEMENT_CHOIX_COMPARTIMENT', 'VERSEMENT_CHOIX_MODE_TYPE'],
    MDP: ['VERSEMENT_CHOIX_COMPARTIMENT', 'VERSEMENT_CHOIX_MODE_TYPE']
  }
};

export const EtapeFin: Etape = {index: 2, label: 'Signature'};
export type EtapeArretVersementProgramme = typeof EtapeInit | typeof Etape0 | typeof EtapeFin;

export const EtapesArretVersement: Array<Etape> = [EtapeInit, Etape0, EtapeFin];

export function findEtapeForQuestion(questionType: QuestionType, silo: CodeSiloType): Etape {
  return EtapesArretVersement.find(e => e.questionsType ? e.questionsType[silo].includes(questionType) : false);
}

export function findEtapesPrecedentes(etape: Etape): Etape[] {
  return EtapesArretVersement.filter(e => e.index < etape.index);
}

export class ArretVersementContexte {
  contratSelectionne: ContratId;
  compartimentSelectionne: CompartimentId;
  parcoursManuscrit: boolean;

  constructor(infoArretVersementContrat: InfoArretVersementContrat) {
    this.contratSelectionne = infoArretVersementContrat.contrat;
    if (infoArretVersementContrat.arretVersements.length === 1) {
      this.compartimentSelectionne = toCompartimentId(infoArretVersementContrat.arretVersements[0].compartimentSelected);
    }
  }
}

export class RequestQuestionArretVersement {
  questionType: QuestionType;
  contexte: ArretVersementContexte;
  questionTypeList: QuestionType[];
}

/**
 * Liste des questions à envoyer au back (question-or-next)
 */
export const QuestionsReellesERE: QuestionType[] = [
  'VERSEMENT_CHOIX_COMPARTIMENT',
  'VERSEMENT_CHOIX_MODE_TYPE',
];

export const QuestionsReellesMDP: QuestionType[] = [];

export const QuestionsReelles = {
  ERE: QuestionsReellesERE,
  MDP: QuestionsReellesMDP
};

export interface ChoixReponsePayload {
  questionType: QuestionType;
  reponse: Reponse;
}

export interface QuestionStates {
  choixCompartiment: QuestionState<ChoixCompartiment>;
  choixModeVersement: QuestionState<ModeVersement>;
}

export class QuestionModel implements QuestionStates {
  choixCompartiment: QuestionState<ChoixCompartiment> = new QuestionState<ChoixCompartiment>();
  choixModeVersement: QuestionState<ModeVersement> = new QuestionState<ModeVersement>();

  setQuestionReponses(questionReponse: QuestionReponses) {
    const questionType = questionReponse.question.id;
    const choix = questionReponse.defaultValue;
    const attr = this.toAttr(questionType);
    this[attr] = Object.assign(new QuestionState(), {isFetched: true, questionReponse, choix});
    return this;
  }

  setChoix(choix: ChoixReponsePayload) {
    const reponse = choix.reponse;
    const attr = this.toAttr(choix.questionType);
    this[attr] = Object.assign(new QuestionState(),
      {...this[attr], choix: reponse});
    if (choix.questionType === 'VERSEMENT_CHOIX_COMPARTIMENT') {
      this['choixModeVersement'] = new QuestionState();
    }
    return this;
  }

  setListQuestionResponses(liste: ListQuestionResponses) {
    liste.questionResponsesList.forEach(qr => this.setQuestionReponses(qr));
  }

  toContexte(modificationVersement: InfoArretVersementContrat, parcoursManuscrit: boolean): ArretVersementContexte {
    const context = new ArretVersementContexte(modificationVersement);
    context.parcoursManuscrit = parcoursManuscrit;
    this.choixCompartiment.use(v => context.compartimentSelectionne = v.compartiment ? toCompartimentId(v.compartiment) : null);
    return context;
  }

  fromType(questionType: QuestionType): QuestionState {
    const attr = this.toAttr(questionType);
    return this[attr];
  }

  toAttr(questionType: QuestionType): keyof QuestionStates {
    switch (questionType) {
      case 'VERSEMENT_CHOIX_COMPARTIMENT':
        return 'choixCompartiment';
      case 'VERSEMENT_CHOIX_MODE_TYPE':
        return 'choixModeVersement';
    }
    throw new Error(`${questionType} non gérée`);
  }
}


/**
 * Cette methode fait appel au back pour recupérer dans l'ordre les questions
 * en fonction du silo et de l'etape de arretVersement
 * @param store
 * @param etapeCourante l'etape de arretVersement courante
 * @param arretVersement l'etat de arretVersement dans le store
 */
export function getQuestionsOrNextFromEtape(store: Store<GlobalState>,
                                            etapeCourante: EtapeArretVersementProgramme,
                                            arretVersement: ArretVersementProgrammeState): { loading: boolean } {
  const questions = arretVersement.questions;
  const contrat = arretVersement.contratSelected.contrat;

  const questionsEtape = etapeCourante.questionsType[contrat.codeSilo];
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    const qs = questions.fromType(questionType);
    if (qs.isError) {
      throw new Error(`${questionType} en erreur`);
    }

    if (!qs.isFetched && QuestionsReelles[contrat.codeSilo].includes(questionType)) {
      store.dispatch(new GetArretVersementQuestionOrNext({
        questionType,
        questionTypeList: QuestionsReelles[contrat.codeSilo],
        contexte: questions.toContexte(arretVersement.contratSelected, arretVersement.parcoursManuscrit)
      }));
      return {loading: true};
    } else if (qs.questionReponse.show && !qs.choix) {
      return {loading: false};
    }
  }
  return {loading: false};
}

/**
 * Si il y a une question a afficher, cette methode indique si la question a afficher
 * appartient a la liste des questions d'une etape
 * @param questions l'etat des questions dans le store
 * @param questionToShow la question a afficher
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isQuestionEnAttenteDeReponse(questions: QuestionModel,
                                             questionToShow: QuestionType,
                                             questionsEtape: QuestionType[]): boolean {
  if (!questions || !questionToShow) {
    return false;
  }
  let result = false;
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    if (questionToShow === questionType) {
      result = true;
    }
  }
  return result;
}


/**
 * Cette methode verifie que toutes les questions d'une etape de versement
 * ont une reponse enregistree dans le store
 * @param questions l'etat des questions dans le store
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isToutesQuestionsRepondues(questions: QuestionModel, questionsEtape: QuestionType[]): boolean {
  if (!questions) {
    return false;
  }
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    if (!questions.fromType(questionType).choix) {
      return false;
    }
  }
  return true;
}

export class ArretVersementTerminateModel {
  contratSelected: ContratId;
  arretVersementClient: ArretVersementClient;
  contenuVersement: Document;
  baseUrl: String;
}

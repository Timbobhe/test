import { GrilleInvestissementModel, InfosTrackingRepartition, RepartitionSupport } from './grille.investissement.model';

export class Desinvestissement<C> {
    clientMetier: C;
    desinvestissementsSupport: RepartitionSupport[];


    constructor(clientMetier: C) {
        this.clientMetier = clientMetier;
    }

    montantDesinvesti(): number {
        return sommeMontants(this.desinvestissementsSupport);
    }

    clone(clientMetier: C) {
        const desinv = new Desinvestissement(clientMetier);
        if (this.desinvestissementsSupport) {
            desinv.desinvestissementsSupport = [...this.desinvestissementsSupport];
        }
        return desinv;
    }

    isNotEmpty() {
        return this.desinvestissementsSupport != null && this.desinvestissementsSupport.length > 0;
    }

    getDesinvestissement(repartitionSupport: RepartitionSupport) {
        if (!this.desinvestissementsSupport) {
            return null;
        }
        return this.desinvestissementsSupport.find(e => e.id === repartitionSupport.id);
    }

    clean() {
        this.clientMetier = undefined;
    }
}

export class NouvelleRepartition<C> {
    clientMetier: C;
    repartitions: RepartitionSupport[];
    propositionSupports: GrilleInvestissementModel[];


    constructor(clientMetier: C) {
        this.clientMetier = clientMetier;
    }

    clone(clientMetier: C) {
        const nr = new NouvelleRepartition(clientMetier);
        if (this.repartitions) {
            nr.repartitions = [...this.repartitions];
        }
        if (this.propositionSupports) {
            nr.propositionSupports = [...this.propositionSupports];
        }
        return nr;
    }

    isNotEmpty() {
        return this.repartitions != null && this.repartitions.length > 0;
    }

    isEmpty() {
        return !this.isNotEmpty();
    }

    clean() {
        this.clientMetier = undefined;
    }

    getInfosTracking(): InfosTrackingRepartition {
        const res = new InfosTrackingRepartition();
        if (this.isNotEmpty()) {
          res.avecChoixParDefaut = !!this.repartitions.filter(e => e.selectionned).find(e => e.defaut);
          res.avecChoixRecommande = !!this.repartitions.filter(e => e.selectionned).find(e => e.recommande);
          res.avecAutreChoix = !!this.repartitions.filter(e => e.selectionned).find(e => !e.defaut && !e.recommande);
        }
        return res;
      }
}

export class RepartitionActuelle<C> {
    clientMetier: C;
    repartitions: RepartitionSupport[];


    constructor(clientMetier: C) {
        this.clientMetier = clientMetier;
    }

    clone(clientMetier: C) {
        return Object.assign(new RepartitionActuelle(clientMetier), { repartitions: [...this.repartitions] });
    }

    clean() {
        this.clientMetier = undefined;
    }
}

export function sommeMontants(repartitionsSupport: RepartitionSupport[]): number {
    if (!repartitionsSupport) {
        return 0;
    }
    const res = repartitionsSupport.map(e => e.montant || 0).reduce((total, curr) => total + curr, 0);
    return res;
}

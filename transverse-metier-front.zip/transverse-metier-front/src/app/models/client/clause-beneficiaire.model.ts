import { Document } from '@app/modules/ecrs-common/services/download.service';
import { ContratId } from '@app/models/client/contrat.model';

export const CLAUSE_STANDARD = 'Clause standard';
export const CLAUSE_SPECIFIQUE = 'Clause spécifique';

export type TypeClause = typeof CLAUSE_STANDARD | typeof CLAUSE_SPECIFIQUE;

export class ClauseBeneficiaireModel {
  clauseStandard: boolean;
  typeClause: TypeClause;
  contenuClause: string;
}

export class ClauseBeneficiaireTerminateModel {
  contratSelected: ContratId;
  clauseBeneficiaire: ClauseBeneficiaireModel;
  contenuClauseBeneficiaire: Document;
}

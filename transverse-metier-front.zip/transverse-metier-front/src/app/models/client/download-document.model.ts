import { CodeSiloType, CompartimentId, ContratId } from '@app/models/client/contrat.model';

export class DownloadDocument {
  codeDocument: string;
  contratId: ContratId;
  compartimentId?: CompartimentId;
  htmlContent?: string;
  htmlStyle?: string;
  rib?: Rib;
  lienFiche?: string;

  docGed?: IdDocGedDto;
}

export class IdDocGedDto {
  idDocGED: string;
  codeSilo: CodeSiloType;
}

export class Rib {
  titulaire: string;
  bic: string;
  iban: string;
}

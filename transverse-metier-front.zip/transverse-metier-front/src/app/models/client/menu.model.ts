import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { buildUrl } from '@ag2rlamondiale/redux-api-ng';
import { MenuJson } from '@app/actions/menu.actions';
import { AqeaRedirectService } from '@app/services/aqea-redirect.service';
import { containsAll } from '@ag2rlamondiale/transverse-metier-ng';

export const APPLICATION_ECRS = 'ecrs';
export const APPLICATION_AQEA = 'aqea';
export const APPLICATION_PC = 'pc';

export const APPLICATION_ENDPOINTS = {
  [APPLICATION_ECRS]: {
    endpoint: null,
    buildLink: (menuId: string) => `/${menuId}`,
    toRouterLink: (link: string) => {
      if (link && link.startsWith('/#/')) {
        // Pour retourner un ComputedLink avec routerLink : lien interne à l'application
        return link.substring(2);
      }
      return link;
    },
  },
  [APPLICATION_AQEA]: {endpoint: 'aqea_endpoint'},
  [APPLICATION_PC]: {endpoint: 'parcours_client_endpoint'},
};

export interface MenuItemData {
  id?: string;
  libelle: string;
  link?: string; // ''
  hasLink?: boolean;
  application?: string;
  enable?: boolean;
  sousMenus?: Array<MenuItemData>;
  fonctionnalites?: Array<string>;
}

export interface ComputedLink {
  /** lien Externe */
  url?: string;

  /** lien Interne */
  routerLink?: string;
  routerLinkActiveOptions?: {
    exact: boolean;
  };
}

export const NOLINK: ComputedLink = {};

export class MenuItem implements MenuItemData {
  id: string;
  link: string;
  libelle: string;
  enable = true;
  hasLink = true;
  application: string = APPLICATION_ECRS;
  sousMenus?: Array<MenuItem>;
  fonctionnalites: Array<string>;

  constructor(menu: Menu, data?: MenuItemData) {
    if (!data) {
      return;
    }

    const fonctionnalites = data.fonctionnalites ? data.fonctionnalites : [data.id];

    Object.assign(this, data, {fonctionnalites});
    if (data.sousMenus) {
      this.sousMenus = [];
      data.sousMenus.forEach((e) => this.add(e, menu));
    }
    menu.registerPourFonctionnalites(this);
  }

  add(item: MenuItemData, menu: Menu) {
    if (!this.sousMenus) {
      this.sousMenus = [];
    }
    this.sousMenus.push(new MenuItem(menu, item));
    return this;
  }


  setEnableFonctionnalite(enable: boolean, fonctionnalites: Set<string>) {
    if (containsAll(fonctionnalites, this.fonctionnalites)) {
      this.enable = enable;

      if (this.enable === false && this.sousMenus) {
        this.sousMenus.forEach((e) => (e.enable = false));
      }
    }

    if (this.sousMenus) {
      this.sousMenus.forEach((e) => e.setEnableFonctionnalite(enable, fonctionnalites));
    }
  }

  tousSousMenuDisabled() {
    if (this.sousMenus && this.sousMenus.length > 0) {
      for (const e of this.sousMenus) {
        if (e.enable) {
          return false;
        }
      }
      return true;
    }
    return false;
  }

  /**
   * Regle pour le calcul du lien
   * 0. avec hasLink à false = NOLINK
   * 1. avec link sans application = link absolu
   * 2. avec link et application = link relatif à l'application
   * 3. sans link et application
   *   - pour AQEA : /#{id}:
   *   - pour ECRS : /#/{id}
   */
  computeLink(configService: ConfigService, aqeaRedirect: AqeaRedirectService): ComputedLink {
    if (this.hasLink === false) {
      // 0
      return NOLINK;
    }

    if (!this.application && this.link) {
      // 1
      return {url: this.link};
    }
    if (this.application) {
      return this.computeLinkWithApplication(configService, aqeaRedirect);
    }
    return NOLINK;
  }

  private computeLinkWithApplication(configService: ConfigService, aqeaRedirect: AqeaRedirectService): ComputedLink {
    const app = APPLICATION_ENDPOINTS[this.application];
    if (!app) {
      console.warn(
        `Impossible de retrouver la config pour l'application de code ${this.application}, pour le menuItem`,
        this
      );
      return {url: '/'};
    }

    if (this.application === APPLICATION_AQEA) {
      if (this.link) {
        return {url: aqeaRedirect.redirectToLink(this.link, {}, false)};
      }
      return {url: aqeaRedirect.redirectToPage(this.id, {}, false)};
    }

    let clink = this.link;
    if (!this.link && app.buildLink) {
      clink = app.buildLink(this.id);
    }

    const endpoint = app.endpoint;
    if (endpoint) {
      // Lien externe
      const cep = configService.config[endpoint];
      if (!cep) {
        console.warn(
          `Impossible de retrouver l'URL du endpoint depuis le configService pour l'application de code ${this.application}, pour le menuItem`,
          this
        );
      }
      return {url: buildUrl(cep, clink)};
    }

    // Lien interne
    if (app.toRouterLink) {
      return {routerLink: app.toRouterLink(clink), routerLinkActiveOptions: {exact: false}};
    }

    return {routerLink: clink, routerLinkActiveOptions: {exact: false}};
  }
}

export class Menu {
  items: Array<MenuItem> = [];
  itemsByFonctionnalites: { [k: string]: MenuItem } = {};

  static fromMenuJson(menuJson: MenuJson) {
    const res = new Menu();
    res.items = [];
    menuJson.menu.forEach((e) => res.add(e));
    return res;
  }

  add(item: MenuItemData) {
    this.items.push(new MenuItem(this, item));
    return this;
  }

  registerPourFonctionnalites(menuItem: MenuItem) {
    menuItem.fonctionnalites.forEach(fonc => this.itemsByFonctionnalites[fonc] = menuItem);
  }

  setEnableFonctionnalite(enable: boolean, ids: Set<string>) {
    this.items.forEach((e) => e.setEnableFonctionnalite(enable, ids));
    this.items.forEach((e) => {
      if (e.tousSousMenuDisabled()) {
        e.enable = false;
      }
    });
  }

  findMenuItem(idFonctionnalite: string): MenuItem {
    return this.itemsByFonctionnalites[idFonctionnalite];
  }

}

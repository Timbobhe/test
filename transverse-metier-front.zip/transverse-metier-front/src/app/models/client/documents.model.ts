import { CodeSiloType, ContratId, toStringContratId } from '@app/models/client/contrat.model';

export class Fiche {
  titre: string;
  description: string;
  lien: string;
  poids: string;
  extension: string;
  codeSilo: CodeSiloType;
  codeTypeDocument: string;
}
export class DocumentDto {
  code: string;
  name: string;
  date: string;
  contratId: ContratId;
}

export interface Fiches {
  [idSupport: string]: Fiche;
}


export type DocRefType = 'NS' | 'NIF';


export const documentId = (contratId: ContratId, codeDocument: string) => {
  return `${toStringContratId(contratId)}-${codeDocument}`;
};

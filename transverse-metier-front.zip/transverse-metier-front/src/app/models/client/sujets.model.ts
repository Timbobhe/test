export class LectureSujet {
  idSujet: number;
  idSujetParent: number;
  dateLecture: Date;
  titre: string;
  termine?: boolean;
  url: string;
  typeSujet: string;
  sousSujets: LectureSujet[];
}

export function isSousSujetLu(lectureSujet: LectureSujet) {
  return lectureSujet && lectureSujet.dateLecture != null;
}

export function isObjectifTermine(lectureSujet: LectureSujet) {
  if (lectureSujet.sousSujets.findIndex(s => s.dateLecture == null) !== -1) {
    return false;
  }
  return true;
}

export class Sujet {
  idSujet: number;
  titre: string;
  typeSujet: string;
  sousSujets: number[];
}

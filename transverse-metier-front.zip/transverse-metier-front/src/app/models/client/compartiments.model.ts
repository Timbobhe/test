import { Contrat as ContraBase, Encours } from '@app/models/client/contrat.model';

export const LABELS_COMPARTIMENTS = {
  c1: 'Votre épargne retraite individuelle',
  c2: 'Votre épargne salariale',
  c3: 'Votre épargne retraite entreprise'
};


export class ContratSansEncours {
  nomContrat: string;
  description?: string;
  raisonSociale: string;
}

/**
 * La représentation du Contrat **uniquement** pour la synthèse
 */
export class Contrat extends ContraBase {
  dateAffiliation: Date;
  deductible: boolean;
  encours: Encours;
  vifPossible: boolean;
  encoursEnErreur: boolean;
  disabled: boolean;
  selectable: boolean;
}

export class Compartiment {
  encoursCompartiment: number;
  pourcentage: number;
  contrats: Contrats;
}

export class Contrats {
  disponible?: Contrat[];
  retraite?: Contrat[];
  conditions?: Contrat[];
}

export class ListeCompartiments {
  c1?: Compartiment;
  c2?: Compartiment;
  c3?: Compartiment;
}

export class Compartiments {
  encoursTotal: number;
  compartiments: ListeCompartiments;
  autresContrats: Contrat[];
  contientPacte: boolean;
  uniquementPacte: boolean;
  contratSansEncours: ContratSansEncours[];
  sansEncoursSurTousLesContrats: boolean;
  uniquementAutresContrats: boolean;
  contientVif?: boolean;
}

export function isCompartimentEmpty(compartiment: Compartiment) {
  return !(compartiment.contrats['disponible'] && compartiment.contrats['disponible'].length ||
    compartiment.contrats['retraite'] && compartiment.contrats['retraite'].length ||
    compartiment.contrats['conditions'] && compartiment.contrats['conditions'].length);
}

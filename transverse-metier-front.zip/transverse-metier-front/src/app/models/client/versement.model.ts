import { BasicMessage, CoordonneesBancaires } from '@ag2rlamondiale/transverse-metier-ng';
import { FileUploadModel } from '@ag2rlamondiale/transverse-metier-ng';
import { GetVersementQuestionOrNext } from '@app/actions/versement.action';
import { Rib } from '@app/models/client/download-document.model';
import { GestionFinanciereActuelleMdp, GestionFinanciereResponse } from '@app/models/client/gestion-financiere.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Document } from '@app/modules/ecrs-common/services/download.service';
import { VersementState } from '@app/reducers/versement.reducer';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Question, QuestionReponses, QuestionState, QuestionType, Reponse } from '../question-responses.model';
import {
  CodeSiloType,
  CompartimentId,
  ContratId,
  ContratParcours,
  MiniContrat,
  toCompartimentId
} from './contrat.model';
import { NouvelleRepartition, RepartitionActuelle } from './repartition.model';
import { PaiementCbConsole } from '@app/modules/paiement-digital/models/paiement-model';

export type ModePaiement = 'Prelevement' | 'Cheque' | 'Carte bancaire';

export class InfoVersementContrat {
  contrat: MiniContrat;
  choixCompartiment: QuestionReponses<ChoixCompartiment>;
  bloque: boolean;
  sigElecOff: boolean;
  raisonBlocage: BasicMessage;
  gestionFinanciereActuelleMdp: GestionFinanciereActuelleMdp;
  fiscalite: string;
  codeFiliale: string;
}

export type ConsentementId = keyof ConsentementsMdp | keyof EngagementsEre;

export class ConsentementsMdp {
  tutelle: boolean;
}

export class EngagementsEre {
  connaissanceGestionFinanciere: boolean;
  connaissanceGestionFinanciereEtSupportsUC: boolean;
  certificationRenseignement: boolean;
  certificationPorteurCarteBancaire: boolean;
  certificationExactitudeCarteBancaire: boolean;
}

export const ConsentementsJahia: { [id in keyof ConsentementsMdp | keyof EngagementsEre]: string } = {
  tutelle: 'VERSEMENT_MDPRO_QUESTION_RM07QUATER_TITRE',
  connaissanceGestionFinanciere: 'VERSEMENT_ENGAGEMENT_CONNAISSANCE_GESTION_FINANCIERE',
  connaissanceGestionFinanciereEtSupportsUC: 'VERSEMENT_ENGAGEMENT_CONNAISSANCE_GESTION_FINANCIERE_ET_SUPPORT_UC',
  certificationRenseignement: 'VERSEMENT_ENGAGEMENT_CERTIFICATION_RENSEIGNEMENTS',
  certificationPorteurCarteBancaire: 'VERSEMENT_CERTIFICATION_PORTEUR_CARTE_BANCAIRE',
  certificationExactitudeCarteBancaire: 'VERSEMENT_CERTIFICATION_EXACTITUDE_CARTE_BANCAIRE'
};

export class VersementModel {
  versements: InfoVersementContrat[];
  sigElecOff: boolean;
}

export class ChoixCompartiment {
  compartiment: ContratParcours;
  selonDispositionsContractuelles: boolean;
  memePlacementCotisationObligatoires: boolean;
}

export class ModeVersement {
  minMontantPossible: number;
  maxMontantPossible: number;
  /**
   * Versement programmé précedent s'il existe
   */
  versementProgramme: VersementProgramme;
  modeType: ResponseVersementModeType;
  sigElecOff: boolean;
}

export class DetailVersement {
  montant: number;
  frequence: FrequenceVirementType;
  date: Date;
}

export class ChoixRepartitionSupport {
  versementClient: VersementClient;
  repartitionAutomatiqueMdpro: boolean;
  repartitionCotisationsObligatoires: boolean;
  repartitionDispositionsContractuelles: boolean;
}

export class MoyenPaiement {
  moyenPaiementType: ResponseVersementModeDePaiementType;
  coordonneesBancairesDto: CoordonneesBancaires;
}

export class ChoixCoordonneesBancaires {
  coordonneesBancaires: CoordonneesBancaires;
  ribStatus: RibStatusType;
}

export class ChoixCarteBancaire {
  rechercherConditionPaiement: any;
  carHolder: string;
  cardNumber: string;
  expireAt: Date;
  cvc: number;
}

export class VersementProgramme {
  montantActuel: number;
  frequence: FrequenceVirementType;
  minDateDebutPrelevement: Date;
  datePremierVersement: Date;
  dateFinVersement: Date;
}

export class VersementClient {
  contrat: MiniContrat;
  compartimentId: CompartimentId;
  montantVersement: number;
  periodiciteVersement: FrequenceVirementType;
  dateVersement: Date;
  coordonneesBancaires: Rib;
  fichiercoordonneesBancaires: FileUploadModel;
  ribStatus: RibStatusType;
  idTransactionPaiementCB: string;
  hasUniteDeCompte: boolean;
  parcoursManuscrit: boolean;

  nouvelleRepartition = new NouvelleRepartition<VersementClient>(this);
  repartitionActuelle = new RepartitionActuelle<VersementClient>(this);

  montantVersementActuel: number;
  periodiciteVersementActuel: FrequenceVirementType;

  deductibilite: ResponseVersementDeductibiliteType;
  modeVersement: ResponseVersementModeType;
  moyenPaiement: ResponseVersementModeDePaiementType;

  repartitionAutomatiqueMdpro: boolean;
  repartitionCotisationsObligatoires: boolean;
  repartitionDispositionsContractuelles: boolean;

  clone() {
    const c = new VersementClient();
    return Object.assign(c, {
      ...this,
      nouvelleRepartition: this.nouvelleRepartition.clone(c),
      repartitionActuelle: this.repartitionActuelle.clone(c)
    });
  }

  clean() {
    this.nouvelleRepartition.clean();
    this.repartitionActuelle.clean();
    return this;
  }
}

export type RibStatusType = 'KNOWN' | 'NEW';

export type FrequenceVirementType = 'MENSUELLE' | 'TRIMESTRIELLE' | 'SEMESTRIELLE' | 'ANNUELLE';

export type ResponseVersementDeductibiliteType = 'DEDUCTIBLE' | 'NON_DEDUCTIBLE';

export type ResponseVersementModeDePaiementType = 'CHEQUE_BANCAIRE' | 'PRELEVEMENT_AUTOMATIQUE' | 'CARTE_BANCAIRE';

export type ResponseVersementModeType = 'VERSEMENT_LIBRE' | 'VERSEMENT_PROGRAMME';


export interface Etape {
  index: number;
  label: string;
  questionsType?: { [silo in CodeSiloType]: QuestionType[] };
  url?: string;
}

export const EtapeInit: Etape = {index: -1, label: 'Choix du contrat', url: '/versement/choix-contrat'};
export const Etape0: Etape = {
  index: 0,
  label: 'Initialisation du versement',
  questionsType: {
    ERE: ['VERSEMENT_CHOIX_COMPARTIMENT', 'VERSEMENT_CHOIX_MODE_TYPE', 'VERSEMENT_CHOIX_DETAIL'],
    MDP: ['VERSEMENT_CHOIX_COMPARTIMENT', 'VERSEMENT_CHOIX_MODE_TYPE', 'VERSEMENT_CHOIX_DETAIL']
  },
  url: '/versement/etape/choix-versement'
};
export const Etape1: Etape = {
  index: 1,
  label: 'Choisir une répartition',
  questionsType: {
    ERE: ['VERSEMENT_CHOIX_REPARTITION'],
    MDP: ['VERSEMENT_CHOIX_REPARTITION']
  },
  url: '/versement/etape/choix-repartition',
};
export const Etape2: Etape = {
  index: 2,
  label: 'Choisir le mode de paiement',
  questionsType: {
    ERE: ['VERSEMENT_CHOIX_PAIEMENT', 'VERSEMENT_CHOIX_RIB', 'VERSEMENT_CHOIX_CB'],
    MDP: ['VERSEMENT_CHOIX_PAIEMENT', 'VERSEMENT_CHOIX_RIB']
  },
  url: '/versement/etape/choix-paiement'
};
export const Etape3: Etape = {index: 3, label: 'Confirmer mon choix', url: '/versement/etape/recapitulatif-signature'};
export const EtapeFin: Etape = {index: 4, label: 'Signature'};
export type EtapeVersement =
  typeof EtapeInit
  | typeof Etape0
  | typeof Etape1
  | typeof Etape2
  | typeof EtapeFin;

export const EtapesVersement: Array<Etape> = [EtapeInit, Etape0, Etape1, Etape2, Etape3, EtapeFin];

export function findEtapeForQuestion(questionType: QuestionType, silo: CodeSiloType): Etape {
  return EtapesVersement.find(e => e.questionsType ? e.questionsType[silo].includes(questionType) : false);
}

export function findEtapesPrecedentes(etape: Etape): Etape[] {
  return EtapesVersement.filter(e => e.index < etape.index);
}

export class VersementContexte {
  contratSelectionne: ContratId;
  compartimentSelectionne?: CompartimentId;
  reponseModeVersementType?: ResponseVersementModeType;
  responseModePaiementType?: ResponseVersementModeDePaiementType;
  parcoursManuscrit: boolean;
  montantVersement: number;

  repartitions: RepartitionSupport[];

  constructor(contratSelectionne: ContratId) {
    this.contratSelectionne = contratSelectionne;
  }
}

export class RequestQuestionVersement {
  questionType: QuestionType;
  contexte: VersementContexte;
  questionTypeList: QuestionType[];
}

/**
 * Liste des questions à envoyer au back (question-or-next)
 */
export const QuestionsReellesERE: QuestionType[] = [
  'VERSEMENT_CHOIX_COMPARTIMENT',
  'VERSEMENT_CHOIX_MODE_TYPE',
  'VERSEMENT_CHOIX_PAIEMENT',
];

export const QuestionsReellesMDP: QuestionType[] = [
  'VERSEMENT_CHOIX_COMPARTIMENT',
  'VERSEMENT_CHOIX_MODE_TYPE',
  'VERSEMENT_CHOIX_PAIEMENT',
];

export const QuestionsReelles = {
  ERE: QuestionsReellesERE,
  MDP: QuestionsReellesMDP
};

export interface ChoixReponsePayload {
  questionType: QuestionType;
  reponse: Reponse;
}

export class ChoixRepartitionSupportPayload {
  repartitions: RepartitionSupport[];
  repartitionAutomatiqueMdpro = false;
  repartitionCotisationsObligatoires = false;
  repartitionDispositionsContractuelles = false;
}

export interface QuestionStates {
  choixCompartiment: QuestionState<ChoixCompartiment>;
  choixModeVersement: QuestionState<ModeVersement, GestionFinanciereResponse>;
  choixDetailVersement: QuestionState<DetailVersement>;
  choixRepartition: QuestionState<ChoixRepartitionSupport>;
  choixMoyenPaiement: QuestionState<MoyenPaiement>;
  choixCoordonneesBancaires: QuestionState<ChoixCoordonneesBancaires>;
  choixCarteBancaire: QuestionState<ChoixCarteBancaire>;
}

function questionFictiveCoordonneesBancaires() {
  const qFictive = new QuestionState<ChoixCoordonneesBancaires>();
  qFictive.isFetched = true;
  qFictive.questionReponse = new QuestionReponses();
  qFictive.questionReponse.isFictive = true;
  qFictive.questionReponse.question = new Question();
  qFictive.questionReponse.question.id = 'VERSEMENT_CHOIX_RIB';
  qFictive.questionReponse.show = true;
  qFictive.questionReponse.hideLienModifier = true;
  return qFictive;
}

function questionFictiveCarteBancaire() {
  const qFictive = new QuestionState<ChoixCarteBancaire>();
  qFictive.isFetched = true;
  qFictive.questionReponse = new QuestionReponses();
  qFictive.questionReponse.isFictive = true;
  qFictive.questionReponse.question = new Question();
  qFictive.questionReponse.question.id = 'VERSEMENT_CHOIX_CB';
  qFictive.questionReponse.show = true;
  qFictive.questionReponse.hideLienModifier = true;
  return qFictive;
}

function questionFictiveRepartition() {
  const qFictive = new QuestionState<ChoixRepartitionSupport>();
  qFictive.isFetched = true;
  qFictive.questionReponse = new QuestionReponses();
  qFictive.questionReponse.isFictive = true;
  qFictive.questionReponse.question = new Question();
  qFictive.questionReponse.question.id = 'VERSEMENT_CHOIX_REPARTITION';
  qFictive.questionReponse.show = true;
  return qFictive;
}

function questionFictiveDetailVersement() {
  const qFictive = new QuestionState<DetailVersement>();
  qFictive.isFetched = true;
  qFictive.questionReponse = new QuestionReponses();
  qFictive.questionReponse.isFictive = true;
  qFictive.questionReponse.question = new Question();
  qFictive.questionReponse.question.id = 'VERSEMENT_CHOIX_DETAIL';
  qFictive.questionReponse.show = true;
  return qFictive;
}

export class QuestionModel implements QuestionStates {
  choixCompartiment: QuestionState<ChoixCompartiment> = new QuestionState<ChoixCompartiment>();
  choixModeVersement: QuestionState<ModeVersement, GestionFinanciereResponse> = new QuestionState<ModeVersement, GestionFinanciereResponse>();
  choixDetailVersement: QuestionState<DetailVersement> = questionFictiveDetailVersement();
  choixRepartition: QuestionState<ChoixRepartitionSupport> = questionFictiveRepartition();
  choixMoyenPaiement: QuestionState<MoyenPaiement> = new QuestionState<MoyenPaiement>();
  choixCoordonneesBancaires: QuestionState<ChoixCoordonneesBancaires> = questionFictiveCoordonneesBancaires();
  choixCarteBancaire: QuestionState<ChoixCarteBancaire> = questionFictiveCarteBancaire();

  setQuestionLoading(questionType: QuestionType) {
    const attr = this.toAttr(questionType);
    const questionState = this[attr];
    this[attr] = Object.assign(new QuestionState(), {...questionState, isLoading: true});
    return this;
  }

  setQuestionError(questionType: QuestionType) {
    const attr = this.toAttr(questionType);
    const questionState = this[attr];
    this[attr] = Object.assign(new QuestionState(), {
      ...questionState,
      isError: true,
      isLoading: false,
      isFetched: true
    });
    return this;
  }


  setQuestionReponses(questionReponse: QuestionReponses) {
    const questionType = questionReponse.question.id;
    const choix = questionReponse.defaultValue;
    const attr = this.toAttr(questionType);
    this[attr] = Object.assign(new QuestionState(), {isFetched: true, questionReponse, choix});
    return this;
  }

  setChoix(choix: ChoixReponsePayload) {
    const reponse = choix.reponse;
    const attr = this.toAttr(choix.questionType);
    this[attr] = Object.assign(new QuestionState(),
      {...this[attr], choix: reponse});
    if (choix.questionType === 'VERSEMENT_CHOIX_COMPARTIMENT') {
      this['choixModeVersement'] = new QuestionState();
      this['choixDetailVersement'] = questionFictiveDetailVersement();
      this['choixRepartition'] = questionFictiveRepartition();
      this['choixMoyenPaiement'] = new QuestionState();
      this['choixCoordonneesBancaires'] = questionFictiveCoordonneesBancaires();
    } else if (choix.questionType === 'VERSEMENT_CHOIX_MODE_TYPE') {
      this['choixDetailVersement'] = questionFictiveDetailVersement();
      this['choixRepartition'] = questionFictiveRepartition();
      this['choixMoyenPaiement'] = new QuestionState();
      this['choixCoordonneesBancaires'] = questionFictiveCoordonneesBancaires();
    } else if (choix.questionType === 'VERSEMENT_CHOIX_DETAIL') {
      this['choixRepartition'] = questionFictiveRepartition();
      this['choixMoyenPaiement'] = new QuestionState();
      this['choixCoordonneesBancaires'] = questionFictiveCoordonneesBancaires();
    } else if (choix.questionType === 'VERSEMENT_CHOIX_REPARTITION') {
      this['choixMoyenPaiement'] = new QuestionState();
      this['choixCoordonneesBancaires'] = questionFictiveCoordonneesBancaires();
    } else if (choix.questionType === 'VERSEMENT_CHOIX_PAIEMENT') {
      this['choixCoordonneesBancaires'] = questionFictiveCoordonneesBancaires();
    }
    return this;
  }

  setListQuestionResponses(liste: ListQuestionResponses) {
    liste.questionResponsesList.forEach(qr => this.setQuestionReponses(qr));
  }

  toContexte(contratSelectionne: ContratId, parcoursManuscrit: boolean, montantVersement: number, repartitions: RepartitionSupport[]): VersementContexte {
    const context = new VersementContexte(contratSelectionne);
    context.parcoursManuscrit = parcoursManuscrit;
    context.montantVersement = montantVersement;
    context.repartitions = repartitions;
    this.choixCompartiment.use(v => context.compartimentSelectionne = v.compartiment ? toCompartimentId(v.compartiment) : null);
    this.choixModeVersement.use(v => context.reponseModeVersementType = v.modeType);
    this.choixMoyenPaiement.use(v => context.responseModePaiementType = v.moyenPaiementType);

    return context;
  }

  fromType(questionType: QuestionType): QuestionState {
    const attr = this.toAttr(questionType);
    return this[attr];
  }

  toAttr(questionType: QuestionType): keyof QuestionStates {
    switch (questionType) {
      case 'VERSEMENT_CHOIX_COMPARTIMENT':
        return 'choixCompartiment';
      case 'VERSEMENT_CHOIX_MODE_TYPE':
        return 'choixModeVersement';
      case 'VERSEMENT_CHOIX_DETAIL':
        return 'choixDetailVersement';
      case 'VERSEMENT_CHOIX_REPARTITION':
        return 'choixRepartition';
      case 'VERSEMENT_CHOIX_PAIEMENT':
        return 'choixMoyenPaiement';
      case 'VERSEMENT_CHOIX_RIB':
        return 'choixCoordonneesBancaires';
      case 'VERSEMENT_CHOIX_CB':
        return 'choixCarteBancaire';
    }
    throw new Error(`${questionType} non gérée`);
  }
}

export class ListQuestionResponses {
  questionTypeDisplayed: QuestionType;
  questionResponsesList: QuestionReponses[];
}

/**
 * Cette methode fait appel au back pour recupérer dans l'ordre les questions
 * en fonction du silo et de l'etape de versement
 * @param store
 * @param etapeCourante l'etape de versement courante
 * @param versement l'etat de versement dans le store
 */
export function getQuestionsOrNextFromEtape(store: Store<GlobalState>,
                                            etapeCourante: EtapeVersement,
                                            versement: VersementState): { loading: boolean } {
  const questions = versement.questions;
  const contrat = versement.contratSelected.contrat;
  const parcoursManuscrit = versement.parcoursManuscrit;
  const versementClientState = versement.versementClient;
  const montantVersement = versementClientState != null ? versementClientState.montantVersement : 0;
  const repartitions = versementClientState != null && versementClientState.nouvelleRepartition != null && versementClientState.nouvelleRepartition.repartitions
    ? versementClientState.nouvelleRepartition.repartitions.filter(repartition => repartition.selectionned) : null;
  const questionsEtape = etapeCourante.questionsType[contrat.codeSilo];
  for (const questionType of questionsEtape) {
    const qs = questions.fromType(questionType);
    if (qs.isError) {
      throw new Error(`${questionType} en erreur`);
    }
    if (qs.canFetch() && QuestionsReelles[contrat.codeSilo].includes(questionType)) {
      store.dispatch(new GetVersementQuestionOrNext({
        questionType,
        questionTypeList: QuestionsReelles[contrat.codeSilo],
        contexte: questions.toContexte(contrat, parcoursManuscrit, montantVersement, repartitions)
      }));
      return {loading: true};
    } else if (qs.isLoading) {
      return {loading: true};
    } else if (qs.isFetched && qs.questionReponse.show && !qs.choix) {
      return {loading: false};
    }
  }
  return {loading: false};
}

/**
 * Si il y a une question a afficher, cette methode indique si la question a afficher
 * appartient a la liste des questions d'une etape
 * @param questions l'etat des questions dans le store
 * @param questionToShow la question a afficher
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isQuestionEnAttenteDeReponse(questions: QuestionModel,
                                             questionToShow: QuestionType,
                                             questionsEtape: QuestionType[]): boolean {
  if (!questions || !questionToShow) {
    return false;
  }
  let result = false;
  for (const questionType of questionsEtape) {
    if (questionToShow === questionType) {
      result = true;
    }
  }
  return result;
}

/**
 * Cette methode verifie que toutes les questions d'une etape de versement
 * ont une reponse enregistree dans le store
 * @param questions l'etat des questions dans le store
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isToutesQuestionsRepondues(questions: QuestionModel, questionsEtape: QuestionType[]): boolean {
  if (!questions) {
    return false;
  }
  for (const questionType of questionsEtape) {
    if (!questions.fromType(questionType).choix) {
      return false;
    }
  }
  return true;
}

/**
 * Cette methode verifie que toutes les questions des etapes precedentes
 * ont une reponse enregistree dans le store
 * @param questions
 * @param etapeCourante
 * @param codeSilo
 */
export function isQuestionEtapesPrecedentesRepondues(questions: QuestionModel,
                                                     etapeCourante: EtapeVersement,
                                                     codeSilo: CodeSiloType | string): boolean {
  const etapePrecedentes = findEtapesPrecedentes(etapeCourante);
  for (const etape of etapePrecedentes) {
    if (etape.questionsType && !isToutesQuestionsRepondues(questions,
      etape.questionsType[codeSilo])) {
      return false;
    }
  }
  return true;
}

export class VersementTerminateModel {
  contratSelected: ContratId;
  versementClient: VersementClient;
  contenuVersement: Document;
  contenuQad: Document;
}

/**
 * Classe qui représente le Contexte du versement enregistré dans la table PCB pour poursuivre suite redirection 3DS.
 */
export class VersementContextPaiementCB {
  contratSelected: MiniContrat;
  versementClient: VersementClient;
  contenuVersementHtml: string;
  contenuQadHtml: string;

  static decodeContexte(paiemenCbConsole: PaiementCbConsole): VersementContextPaiementCB {
    if (paiemenCbConsole.codeFormatContexte === 'json/1.0') {
      const json = JSON.parse(paiemenCbConsole.valeurContexte);
      const ctx = VersementContextPaiementCB.fromObject(json);
      ctx.versementClient.idTransactionPaiementCB = paiemenCbConsole.idTransactionPaiementCB;
      return ctx;
    }
    return null;
  }


  static fromObject(obj: any) {
    const res = new VersementContextPaiementCB();
    Object.assign(res, obj);
    res.versementClient = Object.assign(new VersementClient(), obj.versementClient);

    res.versementClient.nouvelleRepartition = Object.assign(new NouvelleRepartition(res.versementClient),
      obj.versementClient.nouvelleRepartition, {clientMetier: res.versementClient});

    res.versementClient.repartitionActuelle = Object.assign(new RepartitionActuelle(res.versementClient),
      obj.versementClient.repartitionActuelle, {clientMetier: res.versementClient});

    return res;
  }

  toJson() {
    return JSON.stringify({...this, versementClient: this.versementClient.clone().clean()});
  }
}

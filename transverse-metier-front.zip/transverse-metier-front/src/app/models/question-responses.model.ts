import { BasicMessage, Reponse } from '@ag2rlamondiale/transverse-metier-ng';

export { Reponse };

export type ARBITRAGE_QUESTION_TYPE =
  'ARBITRAGE_CHOIX_COMPARTIMENT'
  | 'ARBITRAGE_CHOIX_FLUXSTOCK'
  | 'ARBITRAGE_CHOIX_TOTALPARTIEL'
  | 'ARBITRAGE_CHOIX_EUROSPOURCENT'
  | 'ARBITRAGE_CHOIX_DESINVESTISSEMENT'
  | 'ARBITRAGE_CHOIX_REPARTITION'
  | 'ARBITRAGE_CHOIX_MODEGESTION';

export type VERSEMENT_QUESTION_TYPE =
  'VERSEMENT_CHOIX_COMPARTIMENT'
  | 'VERSEMENT_CHOIX_MODE_TYPE'
  | 'VERSEMENT_CHOIX_DETAIL'
  | 'VERSEMENT_CHOIX_REPARTITION'
  | 'VERSEMENT_CHOIX_PAIEMENT'
  | 'VERSEMENT_CHOIX_RIB'
  | 'VERSEMENT_CHOIX_CB';

export type QuestionType = VERSEMENT_QUESTION_TYPE | ARBITRAGE_QUESTION_TYPE;


export class Question<I = QuestionType> implements BasicMessage {
  id: I;
  label?: string;
  jahiaDicoEntry?: string;
}

export class QuestionReponses<T = any, I = QuestionType, Q = any> {
  question: Question<I>;
  affirmativeMessage: BasicMessage;
  propositions: Reponse<T>[];
  isMultipleChoice?: boolean;
  isFictive?: boolean;
  hideLienModifier?: boolean;
  show?: boolean;
  warningMessage?: BasicMessage;
  defaultValue?: Reponse<T>;
  data?: Q;
}

export interface ChoixQuestion<T = any, Q = any> {
  questionReponse: QuestionReponses<T, QuestionType, Q>;
  choix: Reponse<T>;
}

export class QuestionState<T = any, Q = any> implements ChoixQuestion<T, Q> {
  questionReponse: QuestionReponses<T, QuestionType, Q>;
  isFetched = false;
  isLoading = false;
  isError = false;
  choix: Reponse<T>;

  get value(): T {
    if (this.choix) {
      return this.choix.value;
    } else if (this.questionReponse && !this.questionReponse.show) {
      return this.questionReponse.defaultValue.value;
    }
    return null;
  }

  use(consumer: (v: T) => any) {
    const v = this.value;
    if (v) {
      consumer(v);
    }
  }

  canFetch(): boolean {
    return !this.isFetched && !this.isLoading && !this.isError;
  }
}

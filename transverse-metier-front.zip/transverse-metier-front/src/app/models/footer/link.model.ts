export class LinkModel {
  label: string;
  url: string;
}

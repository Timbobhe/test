export class ColModel {
  label: string;
  url: string;
}

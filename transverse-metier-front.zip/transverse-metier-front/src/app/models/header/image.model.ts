export class Image {
  alt: string;
  url: string;
  urlMobile?: string;
  urlToRedirect: string;
}

import { Image } from './image.model';

export class HeaderTitle {
  image: Image;
  label: string;
}

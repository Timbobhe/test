var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: true }));

const HEADERS = { 'Content-Type': 'text/xml' };

// '/sso/dev$alm2/login'
// /cas/sso/dev$alm2/login?service=http%3A%2F%2Flocalhost%3A8080%2Fecrs%2Fj_spring_cas_security_check
// http://loginalm-qualif/cas/sso/dev$alm2/login?service=http%3A%2F%2Flocalhost%3A8080%2Fecrs%2Fj_spring_cas_security_check
router.get(/^\/sso.+\/login/, function(req, res) {
  res.send(`
    <html>
      <head>
        <title>Connexion</title>
      </head>
      <body>
        <form action="sso/dev$alm2/login" method="POST">
          <p>Login <input id="username" type="text" name="username"></p>
          <p>Password <input id="password" type="text" name="password"></p>
          <p><input id="connection" type="submit" name="Connexion"></p>
        </form>
      </body>
    </html>
    `
  );
});

router.post(/^\/sso.+\/login/, function(req, res) {
  const ticket = `${req.body.username}-${Math.random()}`;
  const service = req.query.service || 'http://localhost:8080/ecrs/j_spring_cas_security_check';
  res.redirect(`${service}?ticket=${ticket}`);
});

const cas = (data) => {
  return `
<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>
  <cas:authenticationSuccess>
  <cas:user>${data.uid}</cas:user>
  <cas:attributes>
    <cas:uid>${data.uid}</cas:uid>
    <cas:agGDIModeCreation>indirect</cas:agGDIModeCreation>
    <cas:mail>${data.uid}@mail.com</cas:mail>
    <cas:sn>NOM_${data.uid}</cas:sn>
    <cas:agIdTechnique>1000015478</cas:agIdTechnique>
    <cas:agGDIDateDerniereConnexion>20200322190743+0100</cas:agGDIDateDerniereConnexion>
    <cas:cn>NOM_${data.uid} PRENOM_${data.uid}</cas:cn>
    <cas:roles>NET-Utilisateur</cas:roles>
    <cas:roles>EERE-Salarie</cas:roles>
    <cas:entryDN>uid=${data.uid},ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr</cas:entryDN>
    <cas:agDateNaissance>19580901000000+0100</cas:agDateNaissance>
    <cas:givenName>PRENOM_${data.uid}</cas:givenName>
    <cas:agGDIDateModification>20180523111313+0200</cas:agGDIDateModification>
  </cas:attributes>
  </cas:authenticationSuccess>
</cas:serviceResponse>
  `;
}

router.get('/proxyValidate', function (req, res) {
  res.set(HEADERS);
  const e = req.query.ticket.indexOf('-');
  const data = {uid: req.query.ticket.substring(0, e)};
  const xml = cas(data);
  res.send(xml);
});


module.exports = router;

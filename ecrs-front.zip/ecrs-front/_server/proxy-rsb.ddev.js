'use strict';

//require('colors');

var express = require('express'),
  bodyParser = require('body-parser'),
  cors = require('cors'),
  proxy = require('express-http-proxy');

var app = express();
var router = express.Router();
const contextName = '/ecrs';

app.set('port', process.env.PORT || 9797);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//CORS
// var corsOptions = {
//   origin: true,
//   credentials: true,
//   methods: ['GET', 'PUT', 'POST', 'DELETE']
// };
// app.use(cors(corsOptions));


app.use('/proxy', proxy('http://rsb.ddev/', {
  preserveHostHdr: true,
  userResHeaderDecorator(headers, userReq, userRes, proxyReq, proxyRes) {
    // recieves an Object of headers, returns an Object of headers.
    // console.log("REQUEST", userReq);
    // delete headers['access-control-allow-credentials'];
    // Object.assign(headers, { 'access-control-allow-origin': `http://localhost:4200` });
    console.log("HEADERS", headers);
    return headers;
  }
}));

app.listen(app.get('port'), function () {
  console.log(
    `✔Express server listening on http://localhost:%d`,
    app.get('port')
  );
});

import { AppConfig } from '@ag2rlamondiale/transverse-metier-ng';

export const featureMap = {
  EBIA: {libelle: 'bulletin individuel d\'affiliation', dico: 'dictionnaireBia', image: '--bia-mobile-url'},
  VRPG: {libelle: 'versement programmé', dico: 'dictionnaireVersement', image: '--versement-programme-mobile-url'},
  VRLI: {libelle: 'versement libre', dico: 'dictionnaireVersement', image: '--versement-libre-mobile-url'},
  RIBA: {
    libelle: 'coordonnées bancaires',
    dico: 'dictionnaireCoordonneesBancaires',
    image: '--coordonnees-bancaires-mobile-url'
  },
  ARBI: {libelle: 'gestion financière', dico: 'dictionnaireArbitrage', image: '--arbitrage-mobile-url'},
  CBF: {libelle: 'clause bénéficiaire', dico: 'dictionnaireClauseBenef', image: '--bia-mobile-url'}
};

export const AppConfiguration: AppConfig = {
  homeRoute: '/synthese-des-comptes',
  featureMap: featureMap
};

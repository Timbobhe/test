import { TrackingConfig } from '@ag2rlamondiale/transverse-metier-ng';
import { Categorie } from '@app/actions/tracking.action';
import { selectArbitrage, selectBia, selectVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

/**
 * --- EVENT : pageview ----
 */
export const TC_VARS = [
  {
    path: '/synthese-des-comptes',
    vars: {
      client_profil: 'particuliers'
    }
  },
  {
    path: '/aqea',
    vars: {
      notag: true
    }
  },
  {
    path: '/accueil',
    vars: {
      form_profil: 'particuliers'
    },
    children: [
      {
        path: 'configurer-votre-espace',
        vars: {
          notag: true
        },
        children: [
          {
            path: 'beneficiaires',
            vars: {
              notag: false,
              form_step: 'beneficiaires'
            }
          },
          {
            path: 'gestion-financiere',
            vars: {
              notag: false,
              form_step: 'gestion-financiere'
            }
          },
          {
            path: 'objectifs',
            vars: {
              notag: false,
              form_step: 'objectifs'
            }
          }
        ]
      }
    ]
  },
  {
    path: '/nous-contacter',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'type-demande',
        vars: {
          notag: false,
          form_step: 'type-demande'
        }
      },
      {
        path: 'contact',
        vars: {
          notag: false,
          form_step: 'contact'
        }
      },
      {
        path: 'reclamation',
        vars: {
          notag: false,
          form_step: 'reclamation'
        }
      }
    ]
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'consultation',
        vars: {
          notag: false,
          form_step: 'consultation'
        }
      },
      {
        path: 'modification',
        vars: {
          notag: false,
          form_step: 'modification'
        }
      },
      {
        path: 'verification-donnees-personnelles',
        vars: {
          notag: false,
          form_step: 'verification'
        }
      }
    ]
  },
  {
    path: '/contrat-detail',
    vars: {
      client_profil: 'particuliers'
    }
  },
  {
    path: '/modification-gestion-financiere',
    children: [
      {
        path: 'etape',
        vars: {
          type_parcours$: (store: Store<GlobalState>): Observable<string> =>
            selectArbitrage(store).pipe(
              map(x => (x.arbitrage.contratSelected.parcoursSimplifie ? 'simplifie' : 'non_simplifie')),
              take(1)
            )
        }
      }
    ]
  },
  {
    path: '/bulletin-affiliation',
    children: [
      {
        path: 'mes-choix',
        vars: {
          type_parcours$: (store: Store<GlobalState>): Observable<string> =>
            selectBia(store).pipe(
              map(x => (x.bia.contratSelected.parcoursSimplifie ? 'simplifie' : 'non_simplifie')),
              take(1)
            )
        }
      }
    ]
  },
  {
    path: '/versement',
    children: [
      {
        path: 'etape',
        vars: {
          type_parcours$: (store: Store<GlobalState>): Observable<string> =>
            selectVersement(store).pipe(
              map(x => (x.versement.contratSelected.parcoursSimplifie ? 'simplifie' : 'non_simplifie')),
              take(1)
            )
        }
      }
    ]
  }
];

/**
 * --- EVENT : eventGA ----
 */
export const TC_CATEGORY_URL = [
  {
    path: '/accueil',
    vars: {
      category: Categorie.onboarding
    }
  },
  {
    path: '/synthese-des-comptes',
    vars: {
      category: Categorie.synthese
    }
  },
  {
    path: '/modifier-objectif',
    vars: {
      category: Categorie.modificationObjectif
    }
  },
  {
    path: '/bulletin-affiliation',
    vars: {
      category: Categorie.bia
    }
  },
  {
    path: '/nous-contacter',
    vars: {
      category: Categorie.contact
    }
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      category: Categorie.coordonneesBancaires
    }
  },
  {
    path: '/clause-beneficiaire',
    vars: {
      category: Categorie.modificationClauseBeneficiaire
    }
  },
  {
    path: '/modification-gestion-financiere',
    vars: {
      category: Categorie.arbitrage
    }
  },
  {
    path: '/versement',
    vars: {
      category: Categorie.versement
    }
  },
  {
    path: '/en-savoir-plus',
    vars: {
      category: Categorie.EREContratRetraite
    }
  },
  {
    path: '/contrat-detail',
    vars: {
      category: Categorie.EREContratRetraite
    }
  }
];

export const EcrsTrackingConfig: TrackingConfig = {
  appNameContext: '/retraite-supplementaire',
  varsPath: TC_VARS,
  categoriesPath: TC_CATEGORY_URL
};

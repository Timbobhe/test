import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { ApiEffects, Performance } from '@ag2rlamondiale/redux-api-ng';
import { ExecuteAction, INIT_APP } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { AqeaCache } from '@app/actions/aqea-cache.actions';
import { GetClientInfos } from '@app/actions/client-infos.actions';
import { GET_COMPARTIMENTS } from '@app/actions/compartiments.actions';
import { ContratsAssureFetch } from '@app/actions/contrats-assure.actions';
import { EVEN_CANCEL } from '@app/actions/evenement.actions';
import { LOAD_MENU, LoadMenu } from '@app/actions/menu.actions';
import { GetOnboardingStart } from '@app/actions/onboarding.action';
import { GetPersonnePhysiqueInfos } from '@app/actions/personne-physique-infos.action';
import { TrackingInfoFetch } from '@app/actions/tracking.action';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { debounceTime, filter, map, switchMap, tap } from 'rxjs/operators';
import { ROUTER_NAVIGATED, RouterRequestAction } from '@ngrx/router-store';
import { MARKS } from '@app/consts/performance.consts';

@Injectable({
  providedIn: 'root'
})
export class EcrsEffects {

  @Effect({dispatch: true})
  initApp$ = this.actions$.pipe(
    ofType(INIT_APP),
    tap(e => Performance.mark(MARKS.INIT_APP)),
    switchMap(() => [
      this.prefetchJahia(),
      new TrackingInfoFetch(),
      new GetClientInfos(),
      new GetPersonnePhysiqueInfos(),
      new ContratsAssureFetch(),
      new GetOnboardingStart(),
      new LoadMenu(),
      this.configService.getConfig().aqea_init_cache ? new AqeaCache() : {type: 'NOOP', payload: {label: 'Cache AQEA'}}
    ])
  );
  @Effect({dispatch: true})
  loadMenu$ = this.actions$.pipe(
    ofType(LOAD_MENU),
    switchMap(action => this.apiEffects.executeApi(action))
  );
  @Effect({dispatch: true})
  fetchCompartiments$ = this.actions$.pipe(
    ofType(GET_COMPARTIMENTS),
    debounceTime(5000),
    switchMap(action => this.apiEffects.executeApi(action))
  );
  @Effect({dispatch: true})
  cancelEven$ = this.actions$.pipe(
    ofType(EVEN_CANCEL),
    switchMap(action => this.apiEffects.executeApi(action))
  );
  @Effect({dispatch: false})
  routing$ = this.actions$.pipe(
    ofType(ROUTER_NAVIGATED),
    map(e => e as RouterRequestAction),
    filter(e => e.payload.event.url === '/synthese-des-comptes'),
    tap(e => Performance.mark(MARKS.SyntheseNavigated))
  );

  constructor(
    private readonly actions$: Actions,
    private readonly apiEffects: ApiEffects,
    private readonly jahia: JahiaService,
    private readonly configService: ConfigService) {
  }

  private prefetchJahia() {
    if (this.configService.config['jahia_static_loading_active']) {
      return new ExecuteAction(() => this.jahia.prefetchPathsDomaines(
        'common',
        'prevalidation',
        'identiteNum',
        'evenements',
        'objectifs',
        'onboarding',
        'synthese',
      ));
    }
    return {type: 'NOOP'};
  }
}

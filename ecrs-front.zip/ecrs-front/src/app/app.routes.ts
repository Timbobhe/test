import { Routes } from '@angular/router';
import { ArretVersementProgrammeGuard } from '@app/authguards/arret-versement-programme.guard';
import { ModificationClauseBeneficiaireGuard } from '@app/authguards/modification-clause-beneficiaire.guard';
import { OnboardingGuard } from '@app/authguards/onboarding.guard';
import * as fonctionnalites from '@app/consts/fonctionnalites.const';
import { FunctionalityUnauthorizedComponent } from '@app/modules/functionality-unauthorized/functionality-unauthorized.component';
import { ArbitrageGuard } from './authguards/arbitrage.guard';
import { AuthBlocageConsole } from './authguards/auth-blocage-console.guard';
import { AuthLoginCas } from './authguards/auth-login.guard';
import { BiaGuard } from './authguards/bia.guard';
import { CoordonneesBancairesGuard } from './authguards/CoordonneesBancaires.guard';
import { SyntheseGuard } from './authguards/synthese.guard';
import { VersementGuard } from './authguards/versement.guard';
import { ObjectifModificationComponent } from './components/objectif-modification/objectif-modification.component';
import { ContratDetailGuard } from '@app/authguards/contrat-detail.guard';

export const ROUTES: Routes = [
  {
    path: '',
    canActivate: [AuthLoginCas],
    canActivateChild: [AuthBlocageConsole],
    children: [
      {
        path: 'modifier-objectif',
        component: ObjectifModificationComponent,
        data: {id: 'objectif'}
      },
      {
        path: 'synthese-des-comptes',
        loadChildren: () => import('./modules/synthese/synthese.module').then(m => m.SyntheseModule),
        data: {id: 'synthese', preload: true},
        canActivate: [SyntheseGuard]
      },
      {
        path: 'accueil',
        loadChildren: () => import('./modules/onboarding/onboarding.module').then(m => m.OnboardingModule),
        data: {id: fonctionnalites.ONBOARDING},
        canActivate: [OnboardingGuard]
      },
      {
        path: 'bulletin-affiliation',
        loadChildren: () => import('./modules/bia/bia.module').then(m => m.BiaModule),
        data: {id: fonctionnalites.COMPLETER_BIA},
        canActivate: [BiaGuard]
      },
      {
        path: 'fonctionnalite-inaccessible',
        component: FunctionalityUnauthorizedComponent
      },
      {
        path: 'nous-contacter',
        loadChildren: () => import('./modules/contact-reclamation/contact-reclamation.module').then(m => m.ContactReclamationModule),
        data: {id: ['ContactFormulaire', 'ReclamationFormulaire']}
      },
      {
        path: 'coordonnees-bancaires',
        loadChildren: () => import('./modules/coordonnees-bancaires/coordonnees-bancaires.module').then(m => m.CoordonneesBancairesModule),
        data: {id: [fonctionnalites.COORDONNEES_BANCAIRES]},
        canActivate: [CoordonneesBancairesGuard]
      },
      {
        path: 'article',
        loadChildren: () => import('./modules/article/article.module').then(m => m.ArticleModule),
        data: {id: 'article'}
      },
      {
        path: 'clause-beneficiaire',
        loadChildren:
          () => import('./modules/modification-clause-beneficiaire/modification-clause-beneficiaire.module').then(m => m.ModificationClauseBeneficiaireModule),
        data: {id: fonctionnalites.MODIF_CLAUSE_BENEFICIAIRE},
        canActivate: [ModificationClauseBeneficiaireGuard]
      },
      {
        path: 'modification-gestion-financiere',
        loadChildren: () => import('./modules/arbitrage/arbitrage.module').then(m => m.ArbitrageModule),
        data: {id: fonctionnalites.ARBITRAGE},
        canActivate: [ArbitrageGuard]
      },
      {
        path: 'versement',
        loadChildren: () => import('./modules/versement/versement.module').then(m => m.VersementModule),
        data: {id: fonctionnalites.VERSEMENT},
        canActivate: [VersementGuard]
      },
      {
        path: 'arret-versement',
        loadChildren: () => import('./modules/arret-versement-programme/arret-versement-programme.module').then(m => m.ArretVersementProgrammeModule),
        data: {id: fonctionnalites.ARRET_VERSEMENT},
        canActivate: [ArretVersementProgrammeGuard]
      },
      {
        path: 'vos-donnees',
        loadChildren: () => import('./modules/versement-pagehub/versement-pagehub.module').then(m => m.VersementPagehubModule),
        data: {id: fonctionnalites.VERSEMENT},
        canActivate: []
      },
      {
        path: 'en-savoir-plus',
        loadChildren: () => import('./modules/en-savoir-plus/en-savoir-plus.module').then(m => m.EnSavoirPlusModule),
        canActivate: []
      },
      {
        path: 'compte-demo',
        loadChildren: () => import('./modules/compte-demo/compte-demo.module').then(m => m.CompteDemoModule),
        data: {id: fonctionnalites.COMPTE_DEMO}
      },
      {
        path: 'contrat-detail',
        loadChildren: () => import('./modules/contrat-detail/contrat-detail.module').then(m => m.ContratDetailModule),
        data: {id: fonctionnalites.DETAILS_CONTRAT},
        canActivate: [ContratDetailGuard]
      },
      {
        path: 'aqea',
        loadChildren: () => import('./modules/aqe-frame/aqe-frame.module').then(m => m.AqeFrameModule),
      },
      {
        path: 'simulateur',
        loadChildren: () => import('./modules/simulateur/simulateur.module').then(m => m.SimulateurModule)
      },
      {
        path: '**',
        redirectTo: 'accueil',
        pathMatch: 'full'
      }
    ]
  }
];

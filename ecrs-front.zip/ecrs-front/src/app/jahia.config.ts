/**
 * Malgré les apparences les clés des PATH (contrib, dico, questionResponse, ressources) doivent être globalement unique.
 */
import { JahiaConfig } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import * as CONFIG from '../assets/jahia.config.json';


export function cleanContentHtml(html: string, config: JahiaConfig, configService: ConfigService): string {
  if (!html) {
    return null;
  }

  // suppression <jahia:resource>
  // transformation lien adapter à Angular (1)
  const href1 = /#(\w.+):(\w.+)/gm;
  // transformation lien adapter à Angular (2)
  const href2 = /#(\w.+):/gm;

  // Correction des url localhost
  const jahia_files_host = configService.config[config.jahiaFiles];
  const defaultHost = /^(https?:)?\/\/localhost(:\d+)?(\/.+)/;

  const parser = new DOMParser();
  const htmlBody = `<body>${html}</body>`;
  const parsedHtml = parser.parseFromString(htmlBody, 'text/html');

  const anchors = parsedHtml.getElementsByTagName('a');
  for (let i = 0; i < anchors.length; i++) {
    let tmpHref = anchors[i].href;

    // Correction des URL localhost
    tmpHref = tmpHref.replace(defaultHost, `$3`);

    anchors[i].href = tmpHref;
  }

  // Correction des URL des images
  for (let i = 0; i < parsedHtml.images.length; i++) {
    const tmpSrc = parsedHtml.images[i].src.replace(defaultHost, `${jahia_files_host}$3`);
    parsedHtml.images[i].src = tmpSrc;
  }

  return parsedHtml.documentElement.innerHTML;
}

export const jahiaConfig = {
  apiBase: 'jahia_endpoint',
  apiJahiaEval: 'backend/jahiaConditionEval',
  apiJahiaMultiEval: 'backend/jahiaConditionsMultiEval',
  apiJahiaNgServer: 'jahia_ng_server_endpoint',
  cleanerContentHtml: cleanContentHtml,
  ...(CONFIG as any).default
};

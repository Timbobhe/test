import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

/**
 * Intercepteur permettant d'ajouter automatiquemnt l'option `withCredentials=true`
 * pour les appels sécurisés cross domain (voir HTTP CORS - Access-Control-Allow-Credentials: true)
 */
@Injectable()
export class WithCredentialsHttpInterceptor2 implements HttpInterceptor {

  constructor(private readonly configService: ConfigService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url.indexOf(this.configService.config.backend_base.host) !== -1
      || request.url.indexOf(this.configService.config.aqea_init_cache_endpoint) !== -1
      /*|| request.url.indexOf(this.configService.config.jahia_endpoint) !== -1*/) {
      request = request.clone({
        withCredentials: true
      });
    }
    return next.handle(request);
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { selectOnboarding } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { map, tap } from 'rxjs/operators';


@Injectable()
export class SyntheseGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>, private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return selectOnboarding(this.store).pipe(
      map(x => x.onboarding.onboardingDejaEffectue),
      tap((onboardingDejaEffectue: boolean) => {
        if (!onboardingDejaEffectue) {
          this.router.navigate(['/accueil/bienvenue']);
        }
      })
    );
  }
}

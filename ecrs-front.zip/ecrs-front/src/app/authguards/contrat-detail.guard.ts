import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/actions/accessibilite.actions';
import { DETAILS_CONTRAT } from '@app/consts/fonctionnalites.const';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subject, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ContratDetailGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
              private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    trace('ContratDetailGuard#start');
    const canActivate = new Subject<boolean>();
    const getAccessibiliteVersement = new GetAccessibilite(DETAILS_CONTRAT);

    getAccessibiliteVersement.payload.onSuccess = (data => {
      if (data.accessible) {
        canActivate.next(true);
        canActivate.complete();
      } else {
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible',
          {functionality: DETAILS_CONTRAT}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });

    this.store.dispatch(getAccessibiliteVersement);
    return canActivate.pipe(tap(r => trace('ContratDetailGuard#stop', r)));
  }
}

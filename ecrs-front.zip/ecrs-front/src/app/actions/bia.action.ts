import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng/lib/actions/api.actions';
import { BiaModel, BiaTerminateModel, InfoBiaContrat } from '@app/models/client/bia.model';
import { ClauseBeneficiaireModel } from '@app/models/client/clause-beneficiaire.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Subtitle } from '@app/models/ui.model';
import { Action } from '@ngrx/store';
import { GetContrat } from './common.actions';
import { PostSigelecTerminate } from './sig-elec.action';

export const BIA_START = '[BIA]_START';
export const BIA_TERMINATE = '[BIA]_TERMINATE';
export const PUSH_BIA_ETAPE = '[BIA]_PUSH_BIA_ETAPE';
export const PUSH_CHOIX_CLAUSE = '[BIA]_PUSH_CHOIX_CLAUSE';
export const PUSH_CHOIX_GESTION_FINANCIERE = '[BIA]_PUSH_CHOIX_GESTION_FINANCIERE';
export const PUSH_CONTRAT_SELECTED = '[BIA]_PUSH_CONTRAT';
export const CLEAR_CHOIX_CLAUSE = '[BIA]_CLEAR_CHOIX_CLAUSE';
export const SET_PARCOURS_MANUSCRIT = '[BIA]_SET_PARCOURS_MANUSCRIT';
export const SET_SUBTITLE_BIA = '[BIA]_SET_SUBTITLE';

export class GetBiaStart extends GetContrat<BiaModel> {
  constructor() {
    super(BIA_START, 'backend/bia', '/start');
  }
}

export class PostBiaTerminate extends PostSigelecTerminate {
  constructor(param: BiaTerminateModel) {
    super(BIA_TERMINATE, 'backend/bia', param);
    this.payload.requestData = param;
    this.payload.responseType = 'text';
  }
}

export class PushEtapeBiaPayload {
  etape: number;
}

export class PushEtapeBia implements Action {
  type = PUSH_BIA_ETAPE;

  constructor(public payload: PushEtapeBiaPayload) {
  }
}

export class PushClauseSelected implements Action {
  type = PUSH_CHOIX_CLAUSE;

  constructor(public payload: ClauseBeneficiaireModel) {
  }
}

export class PushContratSelected implements Action {
  type = PUSH_CONTRAT_SELECTED;

  constructor(public payload: InfoBiaContrat) {
  }
}

export class PushGestionFinanciereSelected implements Action {
  type = PUSH_CHOIX_GESTION_FINANCIERE;

  constructor(public payload: RepartitionSupport[]) {
  }
}

export class ClearClauseSelected implements Action {
  type = CLEAR_CHOIX_CLAUSE;

  constructor(public payload: ClauseBeneficiaireModel) {
  }
}

export class SetParcoursManuscritBia implements Action {
  type = SET_PARCOURS_MANUSCRIT;

  constructor(public payload: boolean) {
  }
}

export class SetSubtitleBia implements Action {
  type = SET_SUBTITLE_BIA;

  constructor(public payload: Subtitle) {
  }
}

export type Actions = GetBiaStart
  | PostBiaTerminate
  | PushEtapeBia
  | PushClauseSelected
  | PushContratSelected
  | PushGestionFinanciereSelected
  | ClearClauseSelected
  | SetParcoursManuscritBia
  | SetSubtitleBia
  | ApiActions;


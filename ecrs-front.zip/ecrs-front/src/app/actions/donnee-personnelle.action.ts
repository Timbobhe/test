import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { FileUploadModel } from '@ag2rlamondiale/transverse-metier-ng';
import { DonneePersoModel, DonneesPersoParcoursType, IdentiteInfo } from '@app/models/client/donnee-personnelle.model';
import { Action } from '@ngrx/store';

export const GET_DONNEE_PERSO = '[DONNEE_PERSO]_GET';
export const MODIFIER_DONNEE_PERSO = '[DONNEE_PERSO]_MODIFIER_DONNEE_PERSO';
export const CONFIRMER_DONNEE_PERSO = '[DONNEE_PERSO]_CONFIRMER_DONNEE_PERSO';
export const OPEN_DIALOG_DONNEES_PERSO = '[DONNEE_PERSO]_OPEN_DIALOG_DONNEES_PERSO';


export class ValidationDonneePersoPayload {
  modificationsIdentiteInfo: IdentiteInfo;
  donneesPersoParcoursType: DonneesPersoParcoursType;
  titreSujet: string;

  piecesJointes?: FileUploadModel[];
}

export class GetDonneePerso extends ApiAction<DonneePersoModel> {
  constructor() {
    super(GET_DONNEE_PERSO, 'backend/donneePersonnelle', null);
    this.payload.url = '/get-donnees-perso';
    this.payload.method = 'GET';
  }
}

export class OpenDonneesPersoPopUp implements Action {
  type = OPEN_DIALOG_DONNEES_PERSO;

  constructor(public payload: { open: boolean; type?: string, titreSujet?: string }) {
  }
}

export class ModifierDonneePerso extends ApiAction<any> {
  constructor(donneePersoPayload: ValidationDonneePersoPayload) {
    super(MODIFIER_DONNEE_PERSO, 'backend/donneePersonnelle', null);
    this.payload.requestData = donneePersoPayload;
    this.payload.method = 'POST';
    this.payload.url = '/validation-donnees-perso';
  }
}

export class ConfirmerDonneePerso extends ApiAction<any> {
  constructor(donneePersoPayload: ValidationDonneePersoPayload) {
    super(CONFIRMER_DONNEE_PERSO, 'backend/donneePersonnelle', null);
    this.payload.requestData = donneePersoPayload;
    this.payload.method = 'POST';
    this.payload.url = '/validation-donnees-perso';
  }
}

export type Actions = GetDonneePerso | OpenDonneesPersoPopUp | ModifierDonneePerso | ConfirmerDonneePerso | ApiActions;

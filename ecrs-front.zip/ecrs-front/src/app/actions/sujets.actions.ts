import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { LectureSujet, Sujet } from '@app/models/client/sujets.model';
import { Action } from '@ngrx/store';

export const GET_SUJETS = '[SUJETS]_GET';
export const GET_SUJETS_PAR_UTILISATEUR = '[SUJETS]_GET_PAR_UTILISATEUR';
export const GET_OBJECTIFS_PAR_UTILISATEUR = '[OBJECTIFS]_GET_PAR_UTILISATEUR';
export const CLEAR_OBJECTIFS_PAR_UTILISATEUR = '[OBJECTIFS]_CLEAR_PAR_UTILISATEUR';
export const SUJETS_CREATE = '[SUJETS]_CREATE';
export const SUJET_UPDATE = '[SUJETS]_UPDATE';
export const OBJECTIF_SUJET_TERMINE = '[OBJECTIFS]_SUJET_TERMINE';
export const PUSH_CARD_SUJET_SELECTED = '[SUJETS]_PUSH_CARD_SUJET_SELECTED';
export const CLEAR_CARDS_SUJETS = '[SUJETS]_CLEAR_CARDS_SUJETS';
export const VALIDATE_COORDONNEES_CLIENT = '[SUJETS]_VALIDATE_COORDONNEES_CLIENT';

export class GetSujets extends ApiAction<Sujet> {

  constructor() {
    super(GET_SUJETS, 'backend/sujets', null);
  }
}

export class GetSujetsParUtilisateur extends ApiAction<LectureSujet> {

  constructor() {
    super(GET_SUJETS_PAR_UTILISATEUR, 'backend/sujetsParUtilisateur', null);
  }
}

export class ClearObjectifsParUtilisateur implements Action {
  type = CLEAR_OBJECTIFS_PAR_UTILISATEUR;

  constructor(public payload = null) {
  }
}

export class GetObjectifsParUtilisateur extends ApiAction<LectureSujet> {

  constructor() {
    super(GET_OBJECTIFS_PAR_UTILISATEUR, 'backend/objectifsParUtilisateur', null);
  }
}

export class LectureSujetPayload {
  lectureSujet: LectureSujet;
  onObjectifTermine?: (parent: LectureSujet) => void;
}

export class CreateSujetPayload {
  idSujets: number[];
}

export class CreateSujetParUtilisateur extends ApiAction<LectureSujet> {

  constructor(body: CreateSujetPayload) {
    super(SUJETS_CREATE, 'backend/createSujets', body);
    this.payload.url = `/create`;
    this.payload.method = 'POST';
    this.payload.requestData = body.idSujets;
  }
}

export class UpdateSujetParUtilisateur extends ApiAction<LectureSujet> {

  constructor(body: LectureSujetPayload) {
    super(SUJET_UPDATE, 'backend/updateSujet', body);
    this.payload.url = `/update`;
    this.payload.method = 'POST';
    this.payload.requestData = body.lectureSujet.idSujet;
  }
}

export class ObjectifSujetTermine implements Action {
  type = OBJECTIF_SUJET_TERMINE;

  constructor(public payload: LectureSujet) {
  }
}


export class PushCardSujetSelected implements Action {
  type = PUSH_CARD_SUJET_SELECTED;

  constructor(public payload: number) {
  }
}

export class ClearCardsSujets implements Action {
  type = CLEAR_CARDS_SUJETS;

  constructor(public payload: number[]) {
  }
}


export class ValidateCoordonneesClient extends ApiAction<LectureSujet> {
  constructor(body: LectureSujetPayload) {
    super(VALIDATE_COORDONNEES_CLIENT, 'backend/validateCoordonneesClient', body.lectureSujet);
    this.payload.method = 'POST';
    this.payload.requestData = body.lectureSujet;
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions =
  GetSujets
  | GetSujetsParUtilisateur
  | CreateSujetParUtilisateur
  | UpdateSujetParUtilisateur
  | GetObjectifsParUtilisateur
  | ClearObjectifsParUtilisateur
  | ObjectifSujetTermine
  | PushCardSujetSelected
  | ClearCardsSujets
  | ValidateCoordonneesClient
  | ApiActions;

import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng';
import { Contrat } from '@app/models/client/contrat.model';
import { GetContrat } from './common.actions';

export const CONTRAT_ASSURE_FETCH = '[CONTRAT_ASSURE]_FETCH';
export const DEFAULT_GRILLE_FETCH = '[DEFAULT_GRILLE]_FETCH';

export class ContratsAssureFetch extends GetContrat<Array<Contrat>> {

  constructor() {
    super(CONTRAT_ASSURE_FETCH, 'backend/contratsAssures', null);
    this.payload.transcoder = this.transcode.bind(this);
  }

  transcode(data: any) {
    if (Array.isArray(data)) {
      return data.map(e => Object.assign(new Contrat(), e));
    }
    return data;
  }

}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = ContratsAssureFetch
  | ApiActions;

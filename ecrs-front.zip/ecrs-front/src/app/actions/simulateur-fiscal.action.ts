import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { ContratId } from '@app/models/client/contrat.model';
import { ResultatCalculEpargne } from '@app/models/client/resultatCalculEpargne';
import { Etape, EtapeSimulateurFiscal, InfoSimulateurContrat, RevenuStatut, SimulateurFiscalModel } from '@app/models/client/simulateur-fiscal.model';
import { Action } from '@ngrx/store';

export const SIMULATEUR_FISCAL_START = '[SIMULATEUR_FISCAL]_SIMULATEUR_FISCAL_START';
export const SIMULATEUR_FISCAL_SET_START = '[SIMULATEUR_FISCAL]_SIMULATEUR_FISCAL_SET_START';
export const SIMULATEUR_FISCAL_CALCUL_DISPO_FISCAL = '[SIMULATEUR_FISCAL]_SIMULATEUR_CALCUL_DISPO_FISCAL';

export const PUSH_CONTRAT_SELECTED = '[SIMULATEUR_FISCAL]_PUSH_CONTRAT';
export const PUSH_REVENU_NET_IMPOSABLE = '[SIMULATEUR_FISCAL]_PUSH_REVENU_NET_IMPOSABLE';
export const PUSH_TMI_SELECTED = '[SIMULATEUR_FISCAL]_PUSH_TMI_SELECTED';
export const PUSH_ABONDEMENT = '[SIMULATEUR_FISCAL]_PUSH_ABONDEMENT';
export const PUSH_VERSEMENT_AUTRES_ORGANISMES = '[SIMULATEUR_FISCAL]_PUSH_VERSEMENT_AUTRES_ORGANISMES';
export const SIMULATEUR_FISCAL_GOTO_ETAPE = '[SIMULATEUR_FISCAL]_GOTO_ETAPE';
export const PUSH_MONTANT_SANTE = '[SIMULATEUR_FISCAL]_PUSH_MONTANT_SANTE';
export const PUSH_MONTANT_CHOMAGE = '[SIMULATEUR_FISCAL]_PUSH_MONTANT_CHOMAGE';
export const PUSH_ETAPE0_SIMULATEUR = '[SIMULATEUR_FISCAL]_PUSH_ETAPE0_SIMULATEUR';

export class StartSimulateurFiscalPayload {
  revenuImposable: number;
  abondement?: number;
  cotisation?:number;
  versementsAutresOrganismes?: number;
  tmi: number;
  contrat: ContratId;
}

export class GoToEtapeSimulateurFiscalPayload {
  etape: EtapeSimulateurFiscal;
}

export class GoToEtapeSimulateurFiscal implements Action {
  type = SIMULATEUR_FISCAL_GOTO_ETAPE;

  constructor(public payload: GoToEtapeSimulateurFiscalPayload) {
  }
}

export class PushContratSelected implements Action {
  type = PUSH_CONTRAT_SELECTED;

  constructor(public payload: InfoSimulateurContrat) {
  }
}

export class PushRevenuNetImposable implements Action {
  type = PUSH_REVENU_NET_IMPOSABLE;

  constructor(public payload: number | RevenuStatut) {
  }
}

export class PushTmiSelected implements Action {
  type = PUSH_TMI_SELECTED;

  constructor(public payload: number) {
  }
}

export class PushAbondement implements Action {
  type = PUSH_ABONDEMENT;

  constructor(public payload: number) {
  }
}

export class PushMontantSante implements Action {
  type = PUSH_MONTANT_SANTE;

  constructor(public payload: number) {
  }
}
export class PushMontantChomage implements Action {
  type = PUSH_MONTANT_CHOMAGE;

  constructor(public payload: number) {
  }
}

export class PushVersementAutresOrganismes implements Action {
  type = PUSH_VERSEMENT_AUTRES_ORGANISMES;

  constructor(public payload: number) {
  }
}

export class GetSimulateurFiscalStart extends ApiAction<SimulateurFiscalModel> {
  constructor() {
    super(SIMULATEUR_FISCAL_START, 'backend/simulateurFiscal', null);
    this.payload.url = `/start`;
    this.payload.method = 'GET';
  }
}

export class SetSimulateurFiscalStart implements Action {
  type = SIMULATEUR_FISCAL_SET_START;

  constructor(public readonly payload: SimulateurFiscalModel) {
  }

}

export class CalculDisponibleFiscalGlobal extends ApiAction<ResultatCalculEpargne> {
  constructor(param: StartSimulateurFiscalPayload) {
    super(SIMULATEUR_FISCAL_CALCUL_DISPO_FISCAL, 'backend/simulateurFiscal', param);
    this.payload.url = `/calcul-disponible-fiscal`;
    this.payload.requestData = param;
    this.payload.method = 'POST';
  }
}


export class PushEtape0Simulateur  implements Action {
  type = PUSH_ETAPE0_SIMULATEUR;

  constructor(public payload: Etape) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions =
  | CalculDisponibleFiscalGlobal
  | GoToEtapeSimulateurFiscal
  | PushContratSelected
  | PushRevenuNetImposable
  | PushAbondement
  | PushVersementAutresOrganismes
  | GetSimulateurFiscalStart
  | SetSimulateurFiscalStart
  | PushMontantSante
  | PushMontantChomage
  | PushEtape0Simulateur;

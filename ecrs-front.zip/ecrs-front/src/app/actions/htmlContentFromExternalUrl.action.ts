import { Actions as ApiActions, ApiAction, ApiActionPayload, LEVEL_SEVERITY_MINOR } from '@ag2rlamondiale/redux-api-ng';

export const GET_HTML_CONTENT_FROM_EXTERNAL_URL = '[HTML_CONTENT_FROM_EXTERNAL_URL]_GET';

export class GetHtmlContentFromExternalUrl extends ApiAction<any> {

  constructor(url: string) {
    super(new ApiActionPayload<any>(), GET_HTML_CONTENT_FROM_EXTERNAL_URL, null, null);
    this.payload.url = url;
    this.payload.responseType = 'text';
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

export type Actions = GetHtmlContentFromExternalUrl | ApiActions;

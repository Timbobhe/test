import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import * as base from '@ag2rlamondiale/transverse-metier-ng';
import { SetTrackingEnvTemplate, TrackingActionPayload, TRACKING_INFO_FETCH } from '@ag2rlamondiale/transverse-metier-ng';
import { TrackingInfo } from '@app/models/client/tracking.model';

export { TrackingActionPayload, SetTrackingEnvTemplate };


export enum Categorie {
  onboarding = 'ERE INTEGRATION',
  bia = 'ERE_BIA',
  synthese = 'synthese-des-comptes',
  modificationObjectif = 'modificationObjectif',
  contact = 'ERE_contact',
  coordonneesBancaires = 'ERE_coordonnees_bancaires',
  modificationClauseBeneficiaire = 'modification-clause-beneficiaire',
  arbitrage = 'ERE_arbitrage',
  hubVersement = 'versement',
  versement = 'ERE_parcours_versement',
  contratDetail = 'contrat-detail',
  lyfePlateforme = 'lyfe-plateforme',
  EREContratRetraite= 'ERE_contrat_retraite'
}

export enum TypeOriginAction {
  synthese_camembert = 'Clic_camembert',
  synthese_onglet = 'Onglet',
  vos_actions = 'Vos_actions',
  simulateur_retraite = 'Simulateur_retraite',
  affichage = 'affichage',
  objectifTermine = 'Objectif_termine',
  objectifChoisi = 'Objectif_choisi',
  objectifSupprime = 'Objectif_supprime',
  objectifDefinir = 'definir_des_objectifs',
  objectifValidation = 'validation_mes_objectifs',
  objectifModifier = 'modifier_des_objectifs',
  objetDemande = 'objet_demande',
  coordonneesBancaires_modification = 'demande-modification',
  coordonneesBancaires_confirmation = 'confirmation-modification',
  downloadDocument = 'consultation_document',
  clauseSpecifique = 'clause_specifique',
  signature = 'signature',
  consultationQuestion = 'consultation-question',

  typeContrat = 'type-contrat',
  basculeArbitrageManuscrit = 'bascule-arbitrage-manuscrit',
  modifierDonneesPersonnelles = 'modifier-donnees-personnelles',
  modifierInformationsSignature = 'modifier-informations-signature',
  modifierArbitrage = 'modifier-arbitrage',
  qadLancement = 'QAD-lancement',
  qadRecommandation = 'QAD-recommandation',
  qadValidation = 'QAD-validation',
  qadTelecharger = 'QAD-telecharger',
  qadRefuser = 'QAD-refuser',
  telechargementDemandeManuscrite = 'telechargement-demande-manuscrite',
  redirectionUniversign = 'redirection-universign',
  erreurTechnique = 'erreur-technique',

  choixArbitreContinuerFinEtape0 = 'CHOIXARBITRE-continuer',
  choixArbitreValiderFinEtape1 = 'CHOIXARBITRE-valider',
  choixArbitreConfirmerFinEtape2 = 'CHOIXARBITRE-confirmer',

  clic = 'clic',

  choixManuscrit = 'choix_manuscrit',
  choixContrat = 'choix_contrat',
  modifier = 'modifier',
  choixTypeVersement = 'choix_type_versement',
  choixModeVersement = 'choix_mode_versement',
  previsualierVersement = 'previsualier_versement',
  choixRepartitionVersement = 'choix-repartition_valider',
  choixModePaiement = 'choix_mode_paiement',
  previsualierActeVersement = 'previsualier_acte_versement',
  finaliserSigner = 'finaliser_signer',
  enSavoirPlus= 'en_savoir_plus',
  enSavoirPlusThemes= 'en_savoir_plus_themes',
  enSavoirPlusContrats= 'en_savoir_plus_contrats',
  FAQ= 'questions_fréquentes',

  autresContrats = 'vos_autres_contrats',
  arbitrage = 'aller_vers_arbitrage',
  detailOperation = 'suivi_operations',
  evolutionEncours = 'evolution_encours',
  consultationDocuments= 'vos_documents',
  plusSurContrat= 'plus_sur_contrat',
  simulezRente= 'simulez_rente',
  constitutionContrat= 'constitution_contrat',
}


export function tracking(
  tc_category: Categorie | string,
  tc_action: TypeOriginAction | string,
  tc_label: string = null,
  by_user = true) {
  return base.tracking<Categorie | string, TypeOriginAction | string>(tc_category, tc_action, tc_label, by_user);
}


export class TrackingInfoFetch extends ApiAction<TrackingInfo> {
  constructor() {
    super(TRACKING_INFO_FETCH, 'backend/trackingInfo', null);
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = TrackingInfoFetch | base.SetTrackingEnvTemplate | ApiActions;

import { GetContrat } from '@app/actions/common.actions';
import { Action } from '@ngrx/store';
import { Subtitle } from '@app/models/ui.model';
import {
  ArretVersementProgrammeModel,
  ArretVersementTerminateModel,
  EtapeArretVersementProgramme,
  InfoArretVersementContrat,
  RequestQuestionArretVersement
} from '@app/models/client/arret-versement-programme.model';
import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { ChoixReponsePayload, ListQuestionResponses } from '@app/models/client/versement.model';
import { QuestionType } from '@app/models/question-responses.model';
import { PostSigelecTerminate } from '@app/actions/sig-elec.action';

export const ARRET_VERSEMENT_PROGRAMME_START = '[ARRET_VERSEMENT]_START';
export const SET_SUBTITLE_ARRET_VERSEMENT_PROGRAMME = '[ARRET_VERSEMENT]_SET_SUBTITLE';
export const SET_PARCOURS_MANUSCRIT_ARRET_VERSEMENT = '[ARRET_VERSEMENT]_SET_PARCOURS_MANUSCRIT';
export const ARRET_VERSEMENT_GET_QUESTION_OR_NEXT = '[ARRET_VERSEMENT]_VERSEMENT_GET_QUESTION_OR_NEXT';
export const ARRET_VERSEMENT_PUSH_CONTRAT_SELECTED = '[ARRET_VERSEMENT]_PUSH_CONTRAT_SELECTED';
export const ARRET_VERSEMENT_PUSH_REPONSE = '[ARRET_VERSEMENT]_PUSH_REPONSE';
export const ARRET_VERSEMENT_MODIFIER_REPONSE = '[ARRET_VERSEMENT]_MODIFIER_REPONSE';
export const ARRET_VERSEMENT_TERMINATE = '[ARRET_VERSEMENT]_TERMINATE';

export class GetArretVersementProgrammeStart extends GetContrat<ArretVersementProgrammeModel> {
  constructor() {
    super(ARRET_VERSEMENT_PROGRAMME_START, 'backend/arretVersementProgramme', '/start');
  }
}

export class SetSubtitleArretVersement implements Action {
  type = SET_SUBTITLE_ARRET_VERSEMENT_PROGRAMME;

  constructor(public payload: Subtitle) {
  }
}

export class PushContratSelected implements Action {
  type = ARRET_VERSEMENT_PUSH_CONTRAT_SELECTED;

  constructor(public payload: { info: InfoArretVersementContrat, setSubtitle: boolean }) {
  }
}

export class SetParcoursManuscritArretVersement implements Action {
  type = SET_PARCOURS_MANUSCRIT_ARRET_VERSEMENT;

  constructor(public payload: boolean) {
  }
}

export class GetArretVersementQuestionOrNext extends ApiAction<ListQuestionResponses> {
  constructor(request: RequestQuestionArretVersement) {
    super(ARRET_VERSEMENT_GET_QUESTION_OR_NEXT, 'backend/arretVersementProgramme', request);

    this.payload.url = '/question-or-next';
    this.payload.method = 'POST';
    this.payload.requestData = request;
  }
}

export class PushReponse implements Action {
  type = ARRET_VERSEMENT_PUSH_REPONSE;

  constructor(public payload: ChoixReponsePayload) {
  }
}

export class ModifierReponse implements Action {
  type = ARRET_VERSEMENT_MODIFIER_REPONSE;

  constructor(public payload: { questionType: QuestionType, etape: EtapeArretVersementProgramme, deplacement: 'next' | 'prev' }) {
  }
}

export class PostArretVersementTerminate extends PostSigelecTerminate {
  constructor(request: ArretVersementTerminateModel) {
    super(ARRET_VERSEMENT_TERMINATE, 'backend/arretVersementProgramme', request);
    this.payload.requestData = request;
    this.payload.responseType = 'text';
  }
}

export type Actions = GetArretVersementProgrammeStart
  | SetSubtitleArretVersement
  | SetParcoursManuscritArretVersement
  | GetArretVersementQuestionOrNext
  | PushReponse
  | ModifierReponse
  | PushContratSelected
  | PostArretVersementTerminate;

export type choixOuiNon = 'oui' | 'non';

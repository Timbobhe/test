import { Image } from '@app/models/header/image.model';
import {CompartimentType, ContratParcours} from './client/contrat.model';
import { Observable } from 'rxjs';
import { ContratId } from '@ag2rlamondiale/transverse-metier-ng';

export class ContratsDetailInfo {
  contrat: ContratDetail;
  autresContrats: ContratParcours[];
}

export class ContratDetail extends ContratParcours {
  personId: string;
  raisonSocialeAdherente: string;
  raisonSocialeContractante: string;
  statut: string;
  dateAffiliation: Date;
  dateEffet: Date;
  dateTerme: Date;
  versementAccessible: boolean;
  arbitrageAccessible: boolean;
  infoCompartiments: InfoCompartimentDto[];
}

export interface ContratDetailImages {
  contratDetailCoverImage: Image;
  contratDetailHeaderImage: Image;
}


export class SupportDetailContratDto {
  libelle: string;
  codeISIN?: string;
  nombreParts?: number;
  montant?: number;
  valeurPart?: number;
  pourcentageRepartition: number;
}

export class GestionFinanciereDetailContratDto {
  dateValeur: Date;
  montantEncours: number;
  supports: SupportDetailContratDto[] = [];
}

export class InfoCompartimentDto {
  contratId: ContratId;
  type: CompartimentType;
  idAssure: string;
  pourcentage: number;
  encours: number;
  college: string;
  titre: string;
  description: string;
  statut: string;
  dateAffiliation: Date;
  gestFinCompartiment$?: Observable<GestionFinanciereDetailContratDto>;
}

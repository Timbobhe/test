export class Block {
  imgUrl: string;
  type: string;
  title: string;
  body: string;
  url: string;

  video?: Video;
}

export interface Video {
  url: string;
  width?: string | number;
  height?: string | number;
}

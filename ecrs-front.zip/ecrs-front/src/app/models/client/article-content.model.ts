export class ArticleContribs {
  /**
   * blockId=titre
   */
  titre?: string;

  /**
   * blockId=video
   */
  video?: string;

  /**
   * blockId=hashtags
   */
  hashtags?: string;

  /**
   * blockId=dateRedaction
   */
  dateRedaction?: string;

  /**
   * blockId=introduction
   */
  introduction?: string;

  /**
   * blockId=texte0
   */
  texte0?: string;

  /**
   * blockId=image1
   */
  image1?: string;

  /**
   * blockId=texte1
   */
  texte1?: string;

  /**
   * blockId=sousTitre1
   */
  sousTitre1?: string;

  /**
   * blockId=exemple1
   */
  exemple1?: string;

  /**
   * blockId=exemple2
   */
  exemple2?: string;

  /**
   * blockId=texte2
   */
  texte2?: string;

  /**
   * blockId=texte3
   */
  texte3?: string;
}


export function buildPathFromArticleName(name: string, repertoire: string, isBodyContent: boolean): string {
  const suffix = isBodyContent ? 'body-content' : 'area-simple-content';
  const res = `${repertoire}/${name}/${suffix}.apiV2.html.ajax?typeUrlResource=absolute`;
  console.log(`---> ArticlePath\t\"${name}\": \"${res}\"`);
  return res;
}

export class ResultatCalculEpargne {
  disponibleFiscal: number;
  montantEpargne: number;
  partEffort: number;
  partGain: number;
  plafondVersement: number;
  versementsDeductibles: number;
  dejaVerse: number;
  resteAverser: number;
}

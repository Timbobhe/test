import { ResponseArbitrageEurosPourcentageType, ResponseArbitrageFluxStockType } from '@app/models/client/arbitrage.model';
import { CompartimentId, MiniContrat } from '@app/models/client/contrat.model';
import { Reponse } from '@app/models/question-responses.model';
import { Desinvestissement, NouvelleRepartition, RepartitionActuelle } from './repartition.model';

/**
 * L'objet qui represente l'arbirage d'un Contrat ou d'un Compartiment.<br>
 * Il peut y avoir <u>plusieurs instances</u> de **ArbitrageClient** pour un parcours d'Arbitrage dans le cas d'un ERE Non pacte.<br>
 * Ces objets sont construits au fur et à mesure dans le parcours après la sélection du contrat et des réponses aux questions.
 */
export class ArbitrageClient {
  ordre: number;
  contrat: MiniContrat;
  compartimentIds: CompartimentId[];
  montantEncours: number;
  repartitionActuelle = new RepartitionActuelle<ArbitrageClient>(this);
  desinvestissement = new Desinvestissement<ArbitrageClient>(this);
  nouvelleRepartition = new NouvelleRepartition<ArbitrageClient>(this);
  unite: ResponseArbitrageEurosPourcentageType;
  typeArbitrage: Reponse<ResponseArbitrageFluxStockType>;
  hasUniteDeCompte = false;

  montantARepartir: number;
  impossible = false;

  hasNewRepartitionDifferentThanCurrent = true;

  calculerMontantARepartir(): number {
    if (this.typeArbitrage.value === 'ARBITRAGE_FLUX' || this.typeArbitrage.value === 'ARBITRAGE_FLUXSTOCK') {
      return 100; // 100%
    }

    if (this.desinvestissement.isNotEmpty()) {
      return this.desinvestissement.montantDesinvesti();
    }

    return this.montantEncours;
  }

  clone() {
    const c = new ArbitrageClient();
    return Object.assign(c, {
      ...this,
      nouvelleRepartition: this.nouvelleRepartition.clone(c),
      desinvestissement: this.desinvestissement.clone(c),
      repartitionActuelle: this.repartitionActuelle.clone(c)
    });
  }

  clean() {
    this.desinvestissement.clean();
    this.nouvelleRepartition.clean();
    this.repartitionActuelle.clean();
    return this;
  }
}

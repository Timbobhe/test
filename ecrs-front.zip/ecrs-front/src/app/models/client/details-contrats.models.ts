import { ContratParcours } from './contrat.model';

export class OperationDetailContrat {
  operationId: string;
  typeOperation: string;
  libelleOperation: string;
  montant: number;
  dateOperation: string;
  contrat: ContratParcours;
  dateValeur: Date;
  avecDetail: boolean;
  avecMontant: boolean;
  groupByDateOperation: string;
}

export class DetailsOperationDto {
  typeOperation: string;
  montantNetOperation: number;
  operationInvestissements: OperationDetailInfoDto[];
}

export class OperationDetailInfoDto {
  identifiantStrucInv: string;
  label: string;
  montant: number;
  nbreParts: number;
  valeurLiquidative: number;
}

export class DownloadValeursLiquidativesDto {
  codeIsin: string;
  periodicite: string;
}

export class ValeurEvolution {
  date: Date;
  value: number;
}

export class EvolutionDto {
  periodicite: string;
  valeursEvolution: ValeurEvolution[] = [];
}

export class EvolutionSupportDto {
  nomSupport: string;
  codeIsin: string;
  devise: string;

  evolutions: EvolutionDto[] = [];
}

export const HEBDOMADAIRE = {
  label: '12 dernières semaines',
  value: 'HEBDOMADAIRE'
};
export const MENSUELLE = {
  label: '12 derniers mois',
  value: 'MENSUELLE'
};
export const TRIMESTRIELLE = {
  label: '12 derniers trimestres',
  value: 'TRIMESTRIELLE'
};
export const SEMESTRIELLE = {
  label: '12 derniers semestres',
  value: 'SEMESTRIELLE'
};
export const ANNUELLE = {
  label: '12 dernières années',
  value: 'ANNUELLE'
};
export type Periodicite = {
  HEBDOMADAIRE,
  MENSUELLE,
  TRIMESTRIELLE,
  SEMESTRIELLE,
  ANNUELLE
};

export const Periodicites: Periodicite = {
  HEBDOMADAIRE,
  MENSUELLE,
  TRIMESTRIELLE,
  SEMESTRIELLE,
  ANNUELLE
};

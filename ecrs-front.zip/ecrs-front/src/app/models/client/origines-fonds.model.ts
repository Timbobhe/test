import { FileUploadModel } from '@ag2rlamondiale/transverse-metier-ng';

export class OriginesFondsModel {
  revenus: Revenus;
  patrimoine: Patrimoine;
  epargne: Epargne;
  gainJeu: InfoOrigineFonds;
  autres: InfoOrigineFonds;
  piecesJointes?: FileUploadModel[];
}

export class InfoOrigineFonds {
  montant: number;
  natureTransaction?: string;
  dateAcquisition?: Date;
}

export class Revenus {
  revenusAnnuelsBrut: number;
  montantInvesti: number;
}

export class Patrimoine {
  patrimoineGlobale: number;
  heritage: InfoOrigineFonds;
  donation: InfoOrigineFonds;
  cessionActifPro: InfoOrigineFonds;
  cessionImmo: InfoOrigineFonds;
}

export class Epargne extends InfoOrigineFonds {
  patrimoineGlobale: number;
}

export class CategoriePatrimoine {
  libelle: string;
  checked: boolean;
  inputId: string;
  checkInput: string;
}

export type NatureOdfType = 'REVENU'
  | 'PATRIMOINE'
  | 'PATRIMOINE_HERITAGE'
  | 'PATRIMOINE_DONATION'
  | 'PATRIMOINE_CESSION_IMMO'
  | 'PATRIMOINE_ACTIF_PROFESSIONNEL'
  | 'EPARGNE'
  | 'GAIN_JEU'
  | 'AUTRES';

export type TypeJustificatif =
  'autres'
  | 'revenu'
  | 'gain_jeu'
  | 'epargne'
  | 'patrimoine_heritage'
  | 'patrimoine_don'
  | 'patrimoine_cession_immobiliere'
  | 'patrimoine_cession_actif_professionnel';

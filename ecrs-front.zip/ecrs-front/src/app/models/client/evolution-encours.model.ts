import { CompartimentType } from './contrat.model';
import { Encours } from './contrat.model';


export class CompartimenteEncourDto {

  compartimentType: CompartimentType;
  pourcentage: number;
  encours: number;
  dateEncours: Date | number;
  deductible?: boolean;
}
export interface EvolutionEncours {
  encours: Encours;
  compartiments: CompartimenteEncourDto[];
}

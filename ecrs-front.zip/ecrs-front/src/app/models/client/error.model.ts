export type ErrorType = 'API' | 'FRONT';

export class ErrorModel {
  errorType: ErrorType;

  constructor(
    public readonly error: Error,
    public readonly severity?: number,
    public readonly idRequest?: string) {}
}

export function errorDescription(errorModel: ErrorModel) {
  if (errorModel) {
    let severite;
    switch (errorModel.severity) {
      case 0:
        severite = 'majeure';
        break;
      case 1:
        severite = 'moderee';
        break;
      case 2:
        severite = 'mineure';
        break;
    }
    return `Erreur ${errorModel.errorType} : ${errorModel.error.name} ${errorModel.error.message} - severité : ${severite}`;
  }
  return null;
}

import {
  AffichageType,
  CodeSiloERE,
  CodeSiloMDP,
  CodeSiloType,
  CompartimentId,
  CompartimentType,
  ContratId,
  DisponibiliteType,
  Encours,
  MiniContrat,
  toCompartimentId,
  toQueryParamsContratId,
  toStringContratId
} from '@ag2rlamondiale/transverse-metier-ng';

export {
  CodeSiloMDP,
  CodeSiloERE,
  CodeSiloType,
  ContratId,
  AffichageType,
  MiniContrat,
  CompartimentId,
  Encours,
  CompartimentType,
  toStringContratId,
  toQueryParamsContratId,
  toCompartimentId,
  DisponibiliteType
};

export class Contrat implements MiniContrat {
  codeSilo: CodeSiloType | string;
  nomContrat: string;
  college?: string;
  idCollege?: string;
  idAdherente?: string;
  idContractante?: string;

  identifiantAssure?: string;
  descriptionFront: string;
  raisonSocialeFront?: string;
  affichageType: AffichageType;
  pacte: boolean;
  personId: string;
  codeFiliale: string;
  petitCollectifPTV: boolean;
  compartiments: Compartiment[];
  descClauseBenef: string;
  codeCadreFiscal: string;
  libCadreFiscal: string;
  madelin: boolean;
  classeAutreContrat: boolean;


  get id(): string {
    return this.nomContrat;
  }

  set id(nomContrat) {
    this.nomContrat = nomContrat;
  }

  get description() {
    return this.descriptionFront;
  }

  set description(descriptionFront) {
    this.descriptionFront = descriptionFront;
  }

  get raisonSociale() {
    return this.raisonSocialeFront;
  }

  set raisonSociale(raisonSocialeFront: string) {
    this.raisonSocialeFront = raisonSocialeFront;
  }
}

export class Compartiment {
  compartimentId: CompartimentId;
  identifiantAssure: string;
  type: CompartimentType;
  college: string;
  libelleEtat: string;
  affichageType: AffichageType;
  deductible: boolean;
  disponibilite: DisponibiliteType;
  idCollege?: string;
  raisonSocialeFront?: string;
}

export function siloContrat(contrat: Contrat): CodeSiloType {
  if (contrat.codeSilo === 'MDP' || contrat.petitCollectifPTV === true) {
    return 'MDP';
  }
  return 'ERE';
}

export class ContratParcours implements MiniContrat {
  nomContrat: string;
  college: string;
  identifiantAssure: string;
  description: string;
  raisonSociale: string;
  codeSilo: CodeSiloType | string;
  idAdherente: string;
  idContractante: string;
  avecEncours: boolean;
  encours: Encours;
  estCompartiment: boolean;
  compartimentType: CompartimentType;
  pacte: boolean;
  descClauseBenef: string;
  affichageType: AffichageType;
  disponibilite: DisponibiliteType;
  deductible?: boolean;
  codeCadreFiscal: string;
  libCadreFiscal: string;
}

export interface Subtitle {
  id: string;
  url?: string;
}

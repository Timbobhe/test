import { LinkModel } from './link.model';

export class  FooterColModel {
  title: string;
  links: LinkModel [];
}

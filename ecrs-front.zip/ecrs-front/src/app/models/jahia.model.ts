import { Image } from '@app/models/header/image.model';
import { ContratDetailImages } from './contrat-detail.model';
import { HeaderModel } from './header/header.model';
import { SimulateurImages } from './simulateur.model';
import { SyntheseImages } from './synthese.model';

export class JahiaModel {
  headerAg2r: HeaderModel;
  headerArialCNP: HeaderModel;
  headerPartenaireAdding: HeaderModel;
  headerPartenaireNie: HeaderModel;
  onboardingImage: Image;
  biaImage: Image;
  coordonneesBancairesImage: Image;
  versementImage: Image;
  contactImage: Image;
  arbitrageImage: Image;
  syntheseImages: SyntheseImages;
  contratDetailImages: ContratDetailImages;
  simulateurImages: SimulateurImages;
}

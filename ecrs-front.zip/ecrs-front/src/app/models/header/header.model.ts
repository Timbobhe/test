import { HeaderTitle } from './header-title.model';
import { HeaderUser } from './header-user.model';

export class HeaderModel {
  title: HeaderTitle;
  user: HeaderUser;
}

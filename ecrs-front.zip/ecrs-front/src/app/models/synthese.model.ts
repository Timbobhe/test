import { Image } from '@app/models/header/image.model';
export interface SyntheseImages {
  mkgDefaultBloc: Image;
  mkgLyfeBloc: Image;
}

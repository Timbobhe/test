import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Performance } from '@ag2rlamondiale/redux-api-ng';
import { ClearToastMessage, HeaderData, LogoType, MessagesService, PartenaireInfo, selectUiToastMessage, ThemeService, ThemeType, TraceFrontService, UrlService, UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';
import { AfterContentChecked, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { getHeaderUserEre, getHeaderUserMdpro, getHeaderUserPartenaire } from '@app/consts/jahia_default_response';
import { MARKS, MEASURES } from '@app/consts/performance.consts';
import { DevApiInterceptorService } from '@app/dev-api-interceptor.service';
import { EvenementService } from '@app/modules/ecrs-common/services/evenement.service';
import { selectAppInitialized, selectUi, selectUiError } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { environment } from 'environments/environment';
import { MessageService } from 'primeng/api';
import { InfoPersonne } from './models/client/info.client.model';
import { CompteDemoComponent } from './modules/compte-demo/compte-demo.component';
import { GlobalState } from './reducers/_index';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy, AfterContentChecked {

  subscriptions = [];
  display = false;
  infoPersonne: InfoPersonne;
  headerData: HeaderData;

  hasMajorError: boolean;
  routerActivate = false;
  themeSwitcherActive = false;
  spinnerActive = true;
  Compte: CompteDemoComponent;
  hideMenu: boolean;
  partenaire: PartenaireInfo;
  displayUser = true;
  isFilialeAcaFlag: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly configService: ConfigService,
    private readonly cd: ChangeDetectorRef,
    private readonly ecrsMessages: MessagesService,
    private readonly primeMessageService: MessageService,
    public readonly urlService: UrlService,
    private readonly themeService: ThemeService,
    private readonly evenService: EvenementService,
    private readonly devApiInterceptor: DevApiInterceptorService,
    private readonly traceFrontNePasSupprimer: TraceFrontService) {
  }

  get mock() {
    return environment.mock;
  }

  ngOnInit() {
    Performance.measure(MEASURES.bootstrapToAppComponentNgOnInit, MARKS.bootstrapAppModule, MARKS.AppComponentNgOnInit);


    this.themeSwitcherActive = this.configService.config['theme_switcher'];
    this.spinnerActive = !this.configService.config['spinner_deactivate'];

    if (!environment.production) {
      this.devApiInterceptor.prepare();
    }

    this.subscriptions.push(
      selectAppInitialized(this.store).subscribe(selected => {
        this.infoPersonne = selected.infoClient;
        this.isFilialeAcaFlag = this.infoPersonne.filialeACA;
        this.partenaire = this.infoPersonne.partenaire;
        this.selectTheme(this.infoPersonne.partenaire, this.isFilialeAcaFlag);
        this.display = this.checkPartnerInUrl(this.infoPersonne.partenaire);
        if (this.partenaire) {
          this.displayUser = false;
          this.headerData = getHeaderUserPartenaire(this.configService);
        } else if (this.infoPersonne.hasContratEre) {
          this.headerData = getHeaderUserEre(this.isFilialeAcaFlag, this.configService);
        } else {
          this.headerData = getHeaderUserMdpro(this.configService);
        }
      }),

      this.store.select(selectUiError).subscribe(e => {
        if (e && e.error) {
          // Ne pas afficher le Header pour les erreurs majeurs
          this.hasMajorError = e.severity === 0;
        } else {
          this.hasMajorError = false;
        }
      }),

      this.store.select(selectUiToastMessage).subscribe(messages => {
        if (messages && messages.length > 0) {
          this.ecrsMessages.addAll(messages, this.primeMessageService);
          this.clearToastMessage();
        }
      }),

      this.store.select(selectUi).subscribe(sub => {
        this.hideMenu = sub.hideMenu;
      }),
    );
  }

  checkPartnerInUrl(partner: PartenaireInfo): boolean {
    const partenaireFromUrl: string = UrlUtils.getSearchParam('fdi');
    if (partner && partner.codePartenaire !== partenaireFromUrl) {
      UrlUtils.setSearchParam('fdi', partner.codePartenaire);
      return false;
    }
    if (!partner && partenaireFromUrl) {
      UrlUtils.deleteSearchParam('fdi');
      return false;
    }
    return true;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  selectTheme(partenaire: PartenaireInfo, isFilialeAcaFlag: boolean) {
    let theme: ThemeType;
    let logo: LogoType;
    const codePartenaire = partenaire ? partenaire.codePartenaire : '';
    if (codePartenaire === '49504') {
      theme = 'adding';
      logo = 'adding';
    } else if (codePartenaire === '49505') {
      theme = 'nie';
      logo = 'nie';
    } else {
      logo = isFilialeAcaFlag ? 'aca' : 'ag2r';
      theme = 'ag2r';
    }
    this.themeService.changeTheme(theme, logo);
  }

  onRouterActivate() {
    this.routerActivate = true;
  }

  ngAfterContentChecked(): void {
    this.cd.detectChanges();
  }

  clearToastMessage() {
    this.store.dispatch(new ClearToastMessage());
  }
}

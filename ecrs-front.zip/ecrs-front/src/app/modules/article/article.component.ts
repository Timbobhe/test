import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.scss']
})
export class ArticleComponent implements OnInit, OnDestroy {

  constructor(private readonly route: ActivatedRoute) {}

  id: string;
  rep = '/sites/aqe/ecrs/sujet';
  subscriptions: Subscription[] = [];

  ngOnInit() {
    this.subscriptions.push(this.route.paramMap.subscribe(paramMap => {
      this.id = paramMap.get('id');
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}

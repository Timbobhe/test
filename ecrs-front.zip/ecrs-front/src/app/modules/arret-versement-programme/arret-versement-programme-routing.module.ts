import { pieceIdentiteRoutes } from '@ag2rlamondiale/transverse-metier-ng';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArretVersementChoixContratComponent } from './arret-versement-choix-contrat/arret-versement-choix-contrat.component';
import { ArretVersementConfirmationComponent } from './arret-versement-confirmation/arret-versement-confirmation.component';
import { ArretVersementDemandeComponent } from './arret-versement-demande/arret-versement-demande.component';
import { ArretVersementIdentiteNumComponent } from './arret-versement-identite-num/arret-versement-identite-num.component';
import { ArretVersementMatchAccountComponent } from './arret-versement-match-account/arret-versement-match-account.component';
import { ArretVersementChoixVersementComponent } from './arret-versement-parcours/arret-versement-choix-versement/arret-versement-choix-versement.component';
import { ArretVersementProgrammeComponent } from './arret-versement-programme.component';
import { ArretVersementSigelecRedirectComponent } from './arret-versement-sigelec-redirect/arret-versement-sigelec-redirect.component';
import { ArretVersementProgrammeStateGuard } from './guards/arret-versement-programme-state-guard';
import { ContratUniqueGuard } from './guards/contrat-unique.guard';
import { ArretVersementRepriseComponent } from './arret-versement-reprise/arret-versement-reprise.component';
import { ResetGuard } from './guards/reset.guard';

const routes: Routes = [{
  path: '',
  component: ArretVersementProgrammeComponent,
  canActivate: [ResetGuard],
  canActivateChild: [ArretVersementProgrammeStateGuard],
  children: [
    {
      path: 'ma-demande',
      component: ArretVersementDemandeComponent
    },
    {
      path: 'validation-piece-identite',
      component: ArretVersementIdentiteNumComponent,
      children: pieceIdentiteRoutes
    },
    {
      path: 'verification-donnees-personnelles',
      component: ArretVersementMatchAccountComponent
    },
    {
      path: 'choix-contrat',
      component: ArretVersementChoixContratComponent,
      canActivate: [ContratUniqueGuard]
    },
    {
      path: 'arret-versement',
      component: ArretVersementChoixVersementComponent
    },
    {
      path: 'signature/:status',
      component: ArretVersementSigelecRedirectComponent
    },
    {
      path: 'confirmation-manuscrit',
      component: ArretVersementConfirmationComponent
    },
    {
      path: 'reprise-versement',
      component: ArretVersementRepriseComponent
    },
    {
      path: '**',
      redirectTo: 'ma-demande',
      pathMatch: 'full'
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ArretVersementProgrammeRoutingModule {
}

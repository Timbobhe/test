import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Subtitle } from '@app/models/ui.model';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { filter, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import {
  GetArretVersementProgrammeStart,
  SetSubtitleArretVersement
} from '@app/actions/arret-versement-programme.actions';

@Component({
  selector: 'app-arret-versement-programme',
  templateUrl: './arret-versement-programme.component.html',
  styleUrls: ['./arret-versement-programme.component.scss']
})
export class ArretVersementProgrammeComponent implements OnInit, OnDestroy {
  info$: Observable<{ contrats: MiniContrat[], contratSelected: MiniContrat }>;
  subtitle$: Observable<Subtitle>;
  private readonly subscriptions: Subscription[] = [];

  constructor(private readonly jahiaService: JahiaService,
              private readonly store: Store<GlobalState>,
              private readonly router: Router) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'arretVersement', 'prevalidation', 'identiteNum');
    this.subtitle$ = selectArretVersement(this.store).pipe(
      map(x => x.arretVersement.subtitle),
      map(s => s != null && s.id ? s : null));

    this.info$ = selectArretVersement(this.store).pipe(
      filter(x => x.arretVersement.isFetched),
      map(x => {
        const contrats = [];
        x.arretVersement.arretVersementModel.infos.forEach(info => contrats.push(info.contrat));
        const contratSelected = x.arretVersement.contratSelected.contrat;
        return {contrats, contratSelected};
      })
    );

    this.store.dispatch(new GetArretVersementProgrammeStart());
  }

  goToChoixContrat() {
    this.store.dispatch(new SetSubtitleArretVersement({id: null}));
    this.router.navigate(['/arret-versement/choix-contrat'], {queryParamsHandling: 'preserve'});
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

}

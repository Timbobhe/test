import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { ActivatedRoute, Router } from '@angular/router';
import { IdentiteNumIntegrationComponent, StartIdentiteNumAction } from '@ag2rlamondiale/transverse-metier-ng';
import {
  SetParcoursManuscritArretVersement,
  SetSubtitleArretVersement
} from '@app/actions/arret-versement-programme.actions';

@Component({
  selector: 'app-arret-versement-identite-num',
  templateUrl: './arret-versement-identite-num.component.html',
  styleUrls: ['./arret-versement-identite-num.component.scss']
})
export class ArretVersementIdentiteNumComponent implements OnInit, OnDestroy {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly jahiaService: JahiaService,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'identiteNum', 'prevalidation');
    this.store.dispatch(new StartIdentiteNumAction({ urlRetourOk: '/arret-versement/ma-demande' }));
    this.store.dispatch(new SetSubtitleArretVersement({
      id: 'cancelLink',
      url: '/arret-versement/ma-demande'
    }));
  }

  setCurrentComponent(componentReference: IdentiteNumIntegrationComponent) {
    componentReference.setOnParcoursManuscrit(() => {
        this.store.dispatch(new SetParcoursManuscritArretVersement(true));
        this.router.navigate(['../choix-contrat'], { relativeTo: this.activeRoute, queryParamsHandling: 'preserve'});
      }
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new SetSubtitleArretVersement(null));
  }
}

import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import { ArretVersementProgrammeState } from '@app/reducers/arret-versement-programme.reducer';

@Component({
  selector: 'app-arret-versement-detail-choix-client',
  templateUrl: './arret-versement-detail-choix-client.component.html',
  styleUrls: ['./arret-versement-detail-choix-client.component.scss']
})
export class ArretVersementDetailChoixClientComponent implements OnInit {
  info$: Observable<{ arretVersement: ArretVersementProgrammeState}>;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.info$ = selectArretVersement(this.store).pipe(
      map(x => {
        return {arretVersement: x.arretVersement};
      })
    );
  }

}

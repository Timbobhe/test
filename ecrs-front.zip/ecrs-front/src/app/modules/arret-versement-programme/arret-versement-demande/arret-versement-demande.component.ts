import { DemandeSigElec } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, OnInit } from '@angular/core';
import { SetParcoursManuscritArretVersement } from '@app/actions/arret-versement-programme.actions';
import { InfoArretVersementContrat } from '@app/models/client/arret-versement-programme.model';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Component({
  selector: 'app-arret-versement-demande',
  templateUrl: './arret-versement-demande.component.html',
  styleUrls: ['./arret-versement-demande.component.scss']
})
export class ArretVersementDemandeComponent implements OnInit {
  demande$: Observable<{ demande: DemandeSigElec; contratSelected: InfoArretVersementContrat }>;
  info: InfoArretVersementContrat;

  constructor(private readonly store: Store<GlobalState>) {}

  ngOnInit() {
    this.demande$ = selectArretVersement(this.store).pipe(
      filter(x => x.arretVersement.isFetched),
      map(x => {
        this.info = x.arretVersement.arretVersementModel.infos.find(
          infoContrat => infoContrat.demandeExistante !== null
        );
        return {
          demande: this.info != null ? this.info.demandeExistante : null,
          contratSelected: this.info
        };
      })
    );
  }
  updateParcoursManuscrit(event: { isBlockedSigElec: boolean; isManuscrit: boolean }) {
    this.store.dispatch(new SetParcoursManuscritArretVersement(event.isManuscrit));
  }
}

import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { IdentiteNumModule, SharedModule } from '@ag2rlamondiale/transverse-metier-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EcrsCommonModule } from '@app/modules/ecrs-common/ecrs-common.module';
import { ArretVersementChoixContratComponent } from './arret-versement-choix-contrat/arret-versement-choix-contrat.component';
import { ArretVersementDemandeComponent } from './arret-versement-demande/arret-versement-demande.component';
import { ArretVersementIdentiteNumComponent } from './arret-versement-identite-num/arret-versement-identite-num.component';
import { ArretVersementMatchAccountComponent } from './arret-versement-match-account/arret-versement-match-account.component';
import { ArretVersementChoixVersementComponent } from './arret-versement-parcours/arret-versement-choix-versement/arret-versement-choix-versement.component';
import { ArretVersementProgrammeRoutingModule } from './arret-versement-programme-routing.module';
import { ArretVersementProgrammeComponent } from './arret-versement-programme.component';
import { ArretVersementResumeChoixComponent } from './arret-versement-resume-choix/arret-versement-resume-choix.component';
import { ArretVersementConfirmationComponent } from './arret-versement-confirmation/arret-versement-confirmation.component';
import { ArretVersementDetailChoixClientComponent } from './arret-versement-detail-choix-client/arret-versement-detail-choix-client.component';
import { ArretVersementRepriseComponent } from './arret-versement-reprise/arret-versement-reprise.component';
import { ArretVersementSigelecRedirectComponent } from './arret-versement-sigelec-redirect/arret-versement-sigelec-redirect.component';

@NgModule({
  declarations: [
    ArretVersementProgrammeComponent,
    ArretVersementDemandeComponent,
    ArretVersementMatchAccountComponent,
    ArretVersementIdentiteNumComponent,
    ArretVersementChoixContratComponent,
    ArretVersementChoixVersementComponent,
    ArretVersementResumeChoixComponent,
    ArretVersementDetailChoixClientComponent,
    ArretVersementSigelecRedirectComponent,
    ArretVersementConfirmationComponent,
    ArretVersementRepriseComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    EcrsCommonModule,
    JahiaNgModule,
    ArretVersementProgrammeRoutingModule,
    IdentiteNumModule,
  ]
})
export class ArretVersementProgrammeModule {
}

import { DemandeSigElec } from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PushContratSelected } from '@app/actions/arret-versement-programme.actions';
import { InfoArretVersementContrat } from '@app/models/client/arret-versement-programme.model';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-arret-versement-reprise',
  templateUrl: './arret-versement-reprise.component.html',
  styleUrls: ['./arret-versement-reprise.component.scss']
})
export class ArretVersementRepriseComponent implements OnInit {

  @Input() demande: DemandeSigElec;

  @Input() contratSelected: InfoArretVersementContrat;

  demandeEncours: DemandeSigElec;
  fonctionnalite = 'Arrêt Versement';

  constructor(private readonly router: Router, private readonly activeRoute: ActivatedRoute,  private readonly store: Store<GlobalState>) { }

  ngOnInit() {
  }


  goToNext() {
    this.router.navigate(['../arret-versement'], { relativeTo: this.activeRoute, queryParamsHandling: 'preserve' });
    this.store.dispatch(new PushContratSelected({ info: this.contratSelected, setSubtitle: true }));
  }


}

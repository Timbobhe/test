import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { PushContratSelected, SetParcoursManuscritArretVersement, SetSubtitleArretVersement } from '@app/actions/arret-versement-programme.actions';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ContratUniqueGuard implements CanActivate {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return selectArretVersement(this.store).pipe(
      take(1),
      map(x => {
        return {arretVersement: x.arretVersement.arretVersementModel.infos, blocage: x.info.infosBlocagesClient};
      }),
      map(x => {
        const list = x.arretVersement;

        if (list && list.length === 1 && !list[0].bloque) {
          if (list[0].sigElecOff) {
            this.store.dispatch(new SetParcoursManuscritArretVersement(true));
          }

          this.store.dispatch(new PushContratSelected({info: list[0], setSubtitle: true}));
          this.router.navigate(['/arret-versement/arret-versement'],
            {replaceUrl: false, queryParamsHandling: 'preserve'});
          return false;
        } else {
          this.store.dispatch(new SetSubtitleArretVersement({id: null}));
        }

        return true;
      })
    );
  }
}

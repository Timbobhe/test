import { Component, Input, OnInit } from '@angular/core';
import { CodeSiloType, ContratId } from '@app/models/client/contrat.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ChoixQuestion, QuestionState } from '@app/models/question-responses.model';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import {
  EtapeArretVersementProgramme,
  findEtapeForQuestion,
  findEtapesPrecedentes,
  QuestionModel
} from '@app/models/client/arret-versement-programme.model';
import { ModifierReponse } from '@app/actions/arret-versement-programme.actions';

export type VarianteResume = 'EtapeCourante' | 'EtapePrecedente' | 'EtapeFinale';

@Component({
  selector: 'app-arret-versement-resume-choix',
  templateUrl: './arret-versement-resume-choix.component.html',
  styleUrls: ['./arret-versement-resume-choix.component.scss']
})
export class ArretVersementResumeChoixComponent implements OnInit {

  @Input() contrat: ContratId = null;
  @Input() collapsed: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  get etapeCourante(): EtapeArretVersementProgramme {
    return this._etapeCourante;
  }

  @Input() set etapeCourante(value: EtapeArretVersementProgramme) {
    this._etapeCourante = value;
    this.resetQuestionsState();
  }

  get variante(): VarianteResume {
    return this._variante;
  }

  @Input() set variante(value: VarianteResume) {
    this._variante = value;
    this.resetQuestionsState();
  }

  @Input() closable = true;

  private _etapeCourante: EtapeArretVersementProgramme;
  private _variante: VarianteResume;
  questionsState$: Observable<{ choixQuestions: QuestionState[], silo: CodeSiloType | string }>;

  ngOnInit() {
  }

  private resetQuestionsState() {
    if (this._etapeCourante && this._variante) {
      this.questionsState$ = selectArretVersement(this.store).pipe(
        map(x => {
          return {
            choixQuestions: this.selectQuestions(x.arretVersement.questions, x.arretVersement.contratSelected.contrat.codeSilo),
            silo: x.arretVersement.contratSelected.contrat.codeSilo
          };
        })
      );
    }
  }


  private selectQuestions(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    if (this._variante === 'EtapeCourante') {
      return this.selectQuestionsEtapeCourante(questions, silo);
    } else if (this._variante === 'EtapePrecedente') {
      return this.selectQuestionsEtapePrecedente(questions, silo);
    } else if (this._variante === 'EtapeFinale') {
      return this.selectQuestionsEtapePrecedente(questions, silo);
    }

    return [];
  }

  private selectQuestionsEtapeCourante(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    return this._etapeCourante.questionsType[silo]
      .map(type => questions.fromType(type))
      .filter(qs => qs.isFetched && qs.value);
  }

  private selectQuestionsEtapePrecedente(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    const res: QuestionState[] = [];

    findEtapesPrecedentes(this._etapeCourante)
      .filter(e => !!e.questionsType)
      .map(e => e.questionsType[silo])
      .filter(e => !!e)
      .forEach(types => {
        types
          .map(type => questions.fromType(type))
          .filter(qs => qs.isFetched && qs.value)
          .forEach(qs => res.push(qs));
      });

    return res;
  }


  handleModifierChoix(choixQuestion: ChoixQuestion, silo: CodeSiloType) {
    const target = findEtapeForQuestion(choixQuestion.questionReponse.question.id, silo);
    this.store.dispatch(new ModifierReponse({
      questionType: choixQuestion.questionReponse.question.id,
      etape: target,
      deplacement: this.etapeCourante.index > target.index ? 'prev' : 'next'
    }));
  }
}

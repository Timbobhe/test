import { DeviceSize, InfosBlocagesClient } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  PushContratSelected,
  SetParcoursManuscritArretVersement
} from '@app/actions/arret-versement-programme.actions';
import { InfoArretVersementContrat } from '@app/models/client/arret-versement-programme.model';
import { DisponibiliteType } from '@app/models/client/contrat.model';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-arret-versement-choix-contrat',
  templateUrl: './arret-versement-choix-contrat.component.html',
  styleUrls: ['./arret-versement-choix-contrat.component.scss']
})
export class ArretVersementChoixContratComponent implements OnInit, OnDestroy {
  disponibiliteTypeMap = new Map([
    ['DISPONIBLE', 'Disponible à la retraite'],
    ['DISPO_RETRAITE', 'Disponible à la retraite'],
    ['DISPO_SOUS_CONDITIONS', 'Disponible sous conditions']
  ]);

  onResize$: Observable<DeviceSize>;

  choixContrats$: Observable<{ arretVersements: InfoArretVersementContrat[]; blocage: InfosBlocagesClient }>;
  subscriptions = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.choixContrats$ = selectArretVersement(this.store).pipe(
      map(x => {
        const arretVersements = x.arretVersement.arretVersementModel ? x.arretVersement.arretVersementModel.infos : [];
        return { arretVersements, blocage: x.info.infosBlocagesClient };
      })
    );
  }

  getContratsByDisponibility(
    contrats: InfoArretVersementContrat[],
    disponibilite: DisponibiliteType
  ): InfoArretVersementContrat[] {
    return contrats.filter(c => c.contrat.disponibilite === disponibilite);
  }

  goToNextStep(infoArretVersementContrat: InfoArretVersementContrat) {
    if (infoArretVersementContrat.sigElecOff) {
      this.store.dispatch(new SetParcoursManuscritArretVersement(true));
    }
    this.store.dispatch(new PushContratSelected({ info: infoArretVersementContrat, setSubtitle: true }));
    this.router.navigate(['../arret-versement'], { relativeTo: this.activeRoute, queryParamsHandling: 'preserve' });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}

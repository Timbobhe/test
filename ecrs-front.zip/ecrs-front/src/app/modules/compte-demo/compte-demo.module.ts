import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CompteDemoRoutingModule } from './compte-demo-routing.module';
import { CompteDemoComponent } from './compte-demo.component';

@NgModule({
  imports: [CommonModule, CompteDemoRoutingModule],
  declarations: [CompteDemoComponent]
})
export class CompteDemoModule {}

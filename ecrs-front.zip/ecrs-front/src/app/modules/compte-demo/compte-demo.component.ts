import { ClearJahiaContrib } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { selectBasicArbitrage, selectInfoClient, selectUi } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { HideMenu } from '@app/actions/ui.actions';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { filter, map } from 'rxjs/operators';
import { ResponseArbitrageFluxStockType } from '@app/models/client/arbitrage.model';

@Component({
  selector: 'app-compte-demo',
  templateUrl: './compte-demo.component.html',
  styleUrls: ['./compte-demo.component.scss']
})
export class CompteDemoComponent implements OnInit, OnDestroy {
  firstName: string;
  lastName: string;
  hideMenu: boolean;
  parcoursUrl: string;
  route: any;
  contrat: string;
  typeArbitrage: ResponseArbitrageFluxStockType;

  subscriptions = [];

  constructor(private readonly store: Store<GlobalState>, private readonly router: Router, private readonly configService: ConfigService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select(selectInfoClient).subscribe(client => {
        this.lastName = client.nom;
        this.firstName = client.prenom;
      }),
      this.store.select(selectUi).subscribe(e => {
        this.parcoursUrl = e.parcoursUrl;
        this.contrat = e.contratCompteDemo;
      }),
      this.store.select(selectBasicArbitrage).pipe(
        filter(x => x.isFetched && !!x.arbitragesClient && x.arbitragesClient.length > 0 && !!x.arbitragesClient[0]),
        map(x => x.arbitragesClient[0])
      ).subscribe(x => {
        this.typeArbitrage = x.typeArbitrage.value;
      })
    );
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  mapToNieName(parcours: string) {
    switch (parcours) {
      case 'bulletin-affiliation':
        return 'bia';
      case 'modification-gestion-financiere':
        if (this.typeArbitrage === 'ARBITRAGE_STOCK') {
          return 'arbitrage&type=stock';
        } else if (this.typeArbitrage === 'ARBITRAGE_FLUX') {
          return 'arbitrage&type=flux';
        }
        return 'arbitrage';
      case 'clause-beneficiaire':
        return 'clause_benef';
    }
  }

  goToTerminateSigelecCompteDemo() {
    const baseUrlNie = this.configService.config['nie_platform_base_url_endpoint'];
    this.store.dispatch(new HideMenu(false));
    this.store.dispatch(new ClearJahiaContrib('SIGELEC_SUCCESS_MSG'));
    if (baseUrlNie) {
      window.top.location.href = `${baseUrlNie}/def_int_ep/ep/gestion_signature.do?contrat=${this.contrat}&parcours=${this.mapToNieName(this.parcoursUrl)}&action=succes`;
    } else {
      this.router.navigate([`${this.parcoursUrl}/signature/terminee`]);
    }
  }
}

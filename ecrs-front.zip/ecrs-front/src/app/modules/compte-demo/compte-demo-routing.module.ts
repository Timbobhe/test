import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompteDemoComponent } from './compte-demo.component';

const routes: Routes = [
  {
    path: '',
    component: CompteDemoComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompteDemoRoutingModule {}

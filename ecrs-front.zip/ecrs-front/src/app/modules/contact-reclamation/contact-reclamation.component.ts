import { Component, OnInit } from '@angular/core';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';

@Component({
  selector: 'app-contact-reclamation',
  templateUrl: './contact-reclamation.component.html',
  styleUrls: ['./contact-reclamation.component.scss']
})
export class ContactReclamationComponent implements OnInit {

  constructor(private readonly jahia: JahiaService) {
  }

  ngOnInit() {
    this.jahia.prefetchPathsDomaines('common', 'contact');
  }

}

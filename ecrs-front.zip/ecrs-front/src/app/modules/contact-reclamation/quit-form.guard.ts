import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ContactReclamationComponent } from '@app/modules/contact-reclamation/contact-reclamation.component';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class QuitFormGuard implements CanDeactivate<ContactReclamationComponent> {
  constructor(private readonly store: Store<GlobalState>) {
  }

  canDeactivate(component: ContactReclamationComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot) {
    return this.store.select('contactReclamation').pipe(
      map(e => !e.loading),
    );
  }

}

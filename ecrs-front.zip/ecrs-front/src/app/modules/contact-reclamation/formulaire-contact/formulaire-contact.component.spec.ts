import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormulaireContactComponent } from './formulaire-contact.component';
import {testingModule} from '../../../../test/ecrs-testing';

describe('FormulaireContactComponent', () => {
  let component: FormulaireContactComponent;
  let fixture: ComponentFixture<FormulaireContactComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [ FormulaireContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormulaireContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

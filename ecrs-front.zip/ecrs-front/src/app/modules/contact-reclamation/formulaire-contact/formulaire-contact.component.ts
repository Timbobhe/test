import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulaire-contact',
  templateUrl: './formulaire-contact.component.html',
  styleUrls: ['./formulaire-contact.component.scss']
})
export class FormulaireContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

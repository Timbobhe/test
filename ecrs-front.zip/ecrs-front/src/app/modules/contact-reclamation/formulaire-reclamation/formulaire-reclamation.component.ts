import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulaire-reclamation',
  templateUrl: './formulaire-reclamation.component.html',
  styleUrls: ['./formulaire-reclamation.component.scss']
})
export class FormulaireReclamationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectionTypeContact, TypeContact } from '@app/actions/contact-reclamation.actions';
import { CONTACT, RECLAMATION } from '@app/consts/fonctionnalites.const';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { Reponse } from '@app/models/question-responses.model';

@Component({
  selector: 'app-choix-type-demande',
  templateUrl: './choix-type-demande.component.html',
  styleUrls: ['./choix-type-demande.component.scss']
})
export class ChoixTypeDemandeComponent implements OnInit, OnDestroy {
  typesDmd: Reponse<TypeContact>[];
  subscriptions: Subscription[] = [];

  constructor(private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select('clientInfos').subscribe(info => {
        this.typesDmd = [
          {
            label: 'Nous contacter',
            value: 'Contact',
            disabled: info.infosBlocagesClient.isFonctionnaliteBloqueePourContrat(null, CONTACT)
          },
          {
            label: 'Faire une réclamation',
            value: 'Reclamation',
            disabled: info.infosBlocagesClient.isFonctionnaliteBloqueePourContrat(null, RECLAMATION)
          }];
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  selectTypeDmd(typeDmd: Reponse<TypeContact>) {
    this.store.dispatch(new SelectionTypeContact(typeDmd.value));

    if (typeDmd.value === 'Contact') {
      this.router.navigate(['../contact'], {relativeTo: this.route});
    }
    if (typeDmd.value === 'Reclamation') {
      this.router.navigate(['../reclamation'], {relativeTo: this.route});
    }
  }
}

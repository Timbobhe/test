/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormulaireCommunComponent } from './formulaire-commun.component';
import { testingModule } from '../../../../test/ecrs-testing';
import { ReactiveFormsModule } from '@angular/forms';
import { initialStateWithClientInfos } from '../../../../test/store-states.mock';
import { RouterTestingModule } from '@angular/router/testing';
import { Globals } from '@ag2rlamondiale/transverse-metier-ng';

describe('FormulaireCommunComponent', () => {
  let component: FormulaireCommunComponent;
  let fixture: ComponentFixture<FormulaireCommunComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithClientInfos}, {
      imports: [
        RouterTestingModule.withRoutes([
            {
              path: '',
              redirectTo: 'nous-contacter',
              pathMatch: 'full'
            }
          ]
        ),
        ReactiveFormsModule],
      declarations: [FormulaireCommunComponent],
      providers: [Globals]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormulaireCommunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

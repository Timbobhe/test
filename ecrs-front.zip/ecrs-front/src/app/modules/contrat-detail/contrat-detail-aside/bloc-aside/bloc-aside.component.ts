import { DeviceSize, PartenaireInfo, tracking } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { DOCUMENTS, GESTION_COMPTE, GESTION_FINANCIERE, SIMULATEUR_FISCAL_MDP, SIMULATEUR_RENTE_VIF } from '@app/consts/fonctionnalites.const';
import { ContratId } from '@app/models/client/contrat.model';
import { Menu } from '@app/models/client/menu.model';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { FonctionnaliteRedirectService } from '@app/modules/ecrs-common/services/fonctionnalite-redirect.service';
import { selectPartenaire } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-bloc-aside',
  templateUrl: './bloc-aside.component.html',
  styleUrls: ['./bloc-aside.component.scss']
})
export class BlocAsideComponent implements OnInit, OnDestroy {

  @Input() carouselItem: any;
  @Input() contrat: ContratDetail;
  @Input() link: string;
  @Input() menu: Menu;
  @Input() device: DeviceSize;
  contratId: ContratId;
  subscriptions: Subscription[] = [];
  partenaire: PartenaireInfo;

  constructor(private readonly store: Store<GlobalState>,
              private readonly redirectService: FonctionnaliteRedirectService,
              private readonly download: DownloadService) { }

  ngOnInit(): void {
    this.contratId = { ...this.contrat } as ContratId;

    this.subscriptions.push(
      selectPartenaire(this.store).subscribe(partenaire => {
       this.partenaire = partenaire;
      })
    );
  }


  clickToMember(event: 'simulateur' | 'documents') {
    switch (event) {
      case 'simulateur': this.goToSimulateur(this.menu);
        break;
      case 'documents': this.goToDocuments(this.menu);
        break;
    }

  }

  goToSimulateur(menu: Menu) {
    if (this.contrat.codeSilo === 'ERE') {
      this.redirectService.navigateTo(SIMULATEUR_RENTE_VIF, menu);
    } else {
      window.location.href = SIMULATEUR_FISCAL_MDP;
    }
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.simulezRente, 'Voir le simulateur de rente'));
  }

  goToDocuments(menu: Menu) {
    this.redirectService.navigateTo(DOCUMENTS, menu);
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.consultationDocuments, 'Voir tous vos documents'));
  }

  goToGestionCompte(menu: Menu) {
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.plusSurContrat, 'Tout savoir sur la gestion de mon compte'));
    this.redirectService.navigateTo(GESTION_COMPTE, menu);
  }

  goToGestionFinanciere(menu: Menu) {
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.plusSurContrat, 'Consulter la gestion financière de mon contrat'));
    this.redirectService.navigateToWithContratId(GESTION_FINANCIERE, menu, this.contratId);
  }

  downloadDocumentNotice() {
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.plusSurContrat, 'Télécharger votre note d\'information financière'));
    this.download.downloadDocument({
      codeDocument: 'NF',
      contratId: this.contratId,
      lienFiche: this.link
    });
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContratDetailComponent } from './contrat-detail.component';

const routes: Routes = [
  {
    path: '',
    component: ContratDetailComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContratDetailRoutingModule {}

import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GetDetailContrat } from '@app/actions/details-contrats.action';
import { ContratsDetailInfo } from '@app/models/contrat-detail.model';
import { selectBasicContratDetail } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { filter, switchMap, tap } from 'rxjs/operators';

@Component({
  selector: 'app-contrat-detail',
  templateUrl: './contrat-detail.component.html',
  styleUrls: ['./contrat-detail.component.scss'],
})
export class ContratDetailComponent implements OnInit, OnDestroy {
  contratsDetails: ContratsDetailInfo;
  subscriptions: Subscription[] = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly reduxApi: ReduxApiService,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.subscriptions.push(
      this.route.queryParams
        .pipe(
          tap(e => this.contratsDetails = null),
          switchMap((e) => this.reduxApi.execute(new GetDetailContrat())),
          switchMap(() => this.store.select(selectBasicContratDetail)),
          filter((res) => !!res.contratsDetails.fetched)
        )
        .subscribe((res) => {
          this.contratsDetails = res.contratsDetails.data;
        })
    );
  }

  ngOnDestroy() {
    this.unsubscribe();
  }

  private unsubscribe() {
    this.subscriptions.forEach((s) => s && s.unsubscribe());
  }
}

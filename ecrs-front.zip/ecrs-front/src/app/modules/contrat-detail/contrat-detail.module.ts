import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { SharedModule } from '@ag2rlamondiale/transverse-metier-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TooltipModule } from 'primeng/tooltip';
import { TableModule } from 'primeng/table';
import { EcrsCommonModule } from '@app/modules/ecrs-common/ecrs-common.module';
import { ContratDetailAsideComponent } from './contrat-detail-aside/contrat-detail-aside.component';
import { ContratDetailAutresContratsComponent } from './contrat-detail-autres-contrats/contrat-detail-autres-contrats.component';
import { ContratDetailInfoPrincipaleComponent } from './contrat-detail-info-principale/contrat-detail-info-principale.component';
import { TableSupportInvestissementComponent } from './contrat-detail-main/contrat-detail-gestion-financiere-pacte/table-support-investissement/table-support-investissement.component';
import { ContratDetailEvolutionSupportComponent } from './contrat-detail-main/contrat-detail-gestion-financiere/contrat-detail-evolution-support/contrat-detail-evolution-support.component';
import { ContratDetailMainComponent } from './contrat-detail-main/contrat-detail-main.component';
import { EvolutionEcoursComponent } from './contrat-detail-main/evolution-ecours/evolution-ecours.component';
import { ListDetailsOperationsComponent } from './contrat-detail-main/suivi-operations/list-details-operations/list-details-operations.component';
import { ListOperationsChoixCompartimentComponent } from './contrat-detail-main/suivi-operations/list-operations-choix-compartiment/list-operations-choix-compartiment.component';
import { OperationTypeComponent } from './contrat-detail-main/suivi-operations/operation-type/operation-type.component';
import { PopUpDetailsAutreOperationComponent } from './contrat-detail-main/suivi-operations/pop-up-details-autre-operation/pop-up-details-autre-operation.component';
import { PopUpDetailsOperationComponent } from './contrat-detail-main/suivi-operations/pop-up-details-operation/pop-up-details-operation.component';
import { SuiviOperationsComponent } from './contrat-detail-main/suivi-operations/suivi-operations.component';
import { ContratDetailRoutingModule } from './contrat-detail-routing.module';
import { ContratDetailComponent } from './contrat-detail.component';
import { ContratDetailGestionFinancierePacteListeComponent } from './contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte-liste/contrat-detail-gestion-financiere-pacte-liste.component';
import { ContratDetailGestionFinancierePacteComponent } from './contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte.component';
import { ContratDetailGestionFinancierePacteDonutComponent } from './contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte-donut/contrat-detail-gestion-financiere-pacte-donut.component';
import { ContratDetailCompartimentsComponent } from './contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-compartiments/contrat-detail-compartiments.component';
import { ContratDetailGestionFinanciereComponent } from './contrat-detail-main/contrat-detail-gestion-financiere/contrat-detail-gestion-financiere.component';
import { ContratDetailDonutNonPacteComponent } from './contrat-detail-main/contrat-detail-gestion-financiere/contrat-detail-donut-non-pacte/contrat-detail-donut-non-pacte.component';
import { ContratDetailSupportInvestissementComponent } from './contrat-detail-main/contrat-detail-gestion-financiere/contrat-detail-support-investissement/contrat-detail-support-investissement.component';
import { DetailsGestionFinanciereNonPacteListeComponent } from './contrat-detail-main/contrat-detail-gestion-financiere/details-gestion-financiere-non-pacte-liste/details-gestion-financiere-non-pacte-liste.component';
import { BlocAsideComponent } from './contrat-detail-aside/bloc-aside/bloc-aside.component';

@NgModule({
  declarations: [
    ContratDetailComponent,
    ContratDetailInfoPrincipaleComponent,
    ContratDetailMainComponent,
    ContratDetailAsideComponent,
    ContratDetailAutresContratsComponent,
    SuiviOperationsComponent,
    OperationTypeComponent,
    PopUpDetailsOperationComponent,
    PopUpDetailsAutreOperationComponent,
    ListDetailsOperationsComponent,
    ListOperationsChoixCompartimentComponent,
    TableSupportInvestissementComponent,
    EvolutionEcoursComponent,
    ContratDetailEvolutionSupportComponent,
    ContratDetailGestionFinancierePacteListeComponent,
    ContratDetailGestionFinancierePacteComponent,
    ContratDetailGestionFinancierePacteDonutComponent,
    ContratDetailCompartimentsComponent,
    ContratDetailGestionFinanciereComponent,
    ContratDetailDonutNonPacteComponent,
    ContratDetailSupportInvestissementComponent,
    DetailsGestionFinanciereNonPacteListeComponent,
    BlocAsideComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    JahiaNgModule,
    EcrsCommonModule,
    SharedModule,
    ContratDetailRoutingModule,
    SelectButtonModule,
    ButtonModule,
    TableModule,
    TooltipModule
  ]
})
export class ContratDetailModule {
}

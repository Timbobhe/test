import { InfoCompartimentDto } from '@app/models/contrat-detail.model';

export class Part {
  encours = 0;
  pourcentage = 0;
}

export class ContratDetailGestionFinancierePacteModel {
  versementsVolontaires: Part;
  deductibleC1: InfoCompartimentDto;
  nonDeductibleC4: InfoCompartimentDto;

  epargneSalarialeC2: InfoCompartimentDto;

  versementsObligatoires: Part;
  listeC3: InfoCompartimentDto[];
}

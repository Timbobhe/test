import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { ContratDetailGestionFinancierePacteModel } from '../contrat-detail-gestion-financiere-pacte.model';

@Component({
  selector: 'app-contrat-detail-gestion-financiere-pacte-liste',
  templateUrl: './contrat-detail-gestion-financiere-pacte-liste.component.html',
  styleUrls: ['./contrat-detail-gestion-financiere-pacte-liste.component.scss']
})
export class ContratDetailGestionFinancierePacteListeComponent implements OnInit {

  @Input() contrat: ContratDetail;
  @Input() model: ContratDetailGestionFinancierePacteModel;

  constructor() {
  }

  ngOnInit(): void {
  }

}

import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import {
  DeviceSize,
  ResponsiveService,
  ThemeService,
  toQueryParamsContratIdRouter,
  tracking
} from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ContratDetail, InfoCompartimentDto } from '@app/models/contrat-detail.model';
import { SelectItem } from 'primeng/api';
import { Observable, Subscription } from 'rxjs';
import { ContratDetailGestionFinancierePacteModel } from '@app/modules/contrat-detail/contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte.model';
import { Arbitrages, Versements } from '@app/consts/fonctionnalites.const';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { GetCompartimentDetailGestionFinanciere } from '@app/actions/details-contrats.action';
import { CompartimentType } from '@app/models/client/contrat.model';

@Component({
  selector: 'app-contrat-detail-gestion-financiere-pacte',
  templateUrl: './contrat-detail-gestion-financiere-pacte.component.html',
  styleUrls: ['./contrat-detail-gestion-financiere-pacte.component.scss']
})
export class ContratDetailGestionFinancierePacteComponent implements OnInit, OnDestroy {

  @Input() contrat: ContratDetail;

  selectedVue = 'chart';
  vueOptions: SelectItem[];
  onResize$: Observable<DeviceSize>;
  model: ContratDetailGestionFinancierePacteModel;
  isSmallTablet = window.innerWidth >= 700 && window.innerWidth <= 992;


  subscriptions: Subscription[] = [];

  fonctionnalites = {Arbitrages, Versements};

  constructor(
    private readonly router: Router,
    private readonly store: Store<GlobalState>,
    private readonly reduxApiService: ReduxApiService,
    private readonly themeService: ThemeService,
    private readonly responsive: ResponsiveService
  ) {
    this.onResize$ = this.responsive.onResize$;
    this.vueOptions = [{label: 'Vue graphique', value: 'chart'}, {label: 'Vue liste', value: 'list'}];
  }

  ngOnInit() {
    let contrat = this.contrat;
    // Immutable
    contrat = {
      ...contrat,
      infoCompartiments: contrat.infoCompartiments
        .map(e => {
          const ic = Object.assign(new InfoCompartimentDto(), e);
          this.setGestionFinanciereCompartiment$(ic);
          return ic;
        })
    };
    this.model = new ContratDetailGestionFinancierePacteModel();

    // Versements volontaires C1,C4
    this.model.deductibleC1 = contrat.infoCompartiments.find((i) => i.type === 'C1');
    this.model.nonDeductibleC4 = contrat.infoCompartiments.find((i) => i.type === 'C4');
    this.model.versementsVolontaires = {
      encours: this.sommeEncours(contrat.infoCompartiments, ['C1', 'C4']),
      pourcentage: this.sommePourcentage(contrat.infoCompartiments, ['C1', 'C4'])
    };

    // Epargne salariale C2
    this.model.epargneSalarialeC2 = contrat.infoCompartiments.find((i) => i.type === 'C2');

    // Versements Obligatoires C3
    this.model.versementsObligatoires = {
      encours: this.sommeEncours(contrat.infoCompartiments, ['C3']),
      pourcentage: this.sommePourcentage(contrat.infoCompartiments, ['C3'])
    };
    this.model.listeC3 = contrat.infoCompartiments.filter((i) => i.type === 'C3');
  }


  onClick(vue: 'chart' | 'list') {
    this.selectedVue = vue;
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.constitutionContrat, vue === 'chart' ? 'Vue graphique' : 'Vue liste'));
  }


  setGestionFinanciereCompartiment$(compartiment: InfoCompartimentDto) {
    compartiment.gestFinCompartiment$ = this.reduxApiService.execution(new GetCompartimentDetailGestionFinanciere({
      idAssure: compartiment.idAssure,
      nomContrat: null,
      compartimentType: compartiment.type,
    }));
  }

  goToVersement(libelleCta: string) {
    this.store.dispatch(tracking(Categorie.contratDetail, TypeOriginAction.clic, libelleCta));
    this.router.navigate(['/versement'], {queryParams: toQueryParamsContratIdRouter(this.contrat)});
  }

  goToArbitrage() {
    this.router.navigate(['../modification-gestion-financiere'], {queryParams: toQueryParamsContratIdRouter(this.contrat)});
  }


  ngOnDestroy() {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }


  private sommeEncours(infos: InfoCompartimentDto[], compartimentType: CompartimentType[]) {
    return infos
      .filter(e => compartimentType.indexOf(e.type) >= 0)
      .map((c) => c.encours)
      .reduce((a, b) => a + b, 0);
  }

  private sommePourcentage(infos: InfoCompartimentDto[], compartimentType: CompartimentType[]) {
    return infos
      .filter(e => compartimentType.indexOf(e.type) >= 0)
      .map((c) => c.pourcentage)
      .reduce((a, b) => a + b, 0);
  }
}

import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, Input, OnInit } from '@angular/core';
import {
  ContratDetail,
  GestionFinanciereDetailContratDto, InfoCompartimentDto,
  SupportDetailContratDto
} from '@app/models/contrat-detail.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-table-support-investissement',
  templateUrl: './table-support-investissement.component.html',
  styleUrls: ['./table-support-investissement.component.scss'],
})
export class TableSupportInvestissementComponent implements OnInit {
  @Input() infoCompartiment: InfoCompartimentDto;

  onResize$: Observable<DeviceSize>;
  isEvolutionSupportDisplayed = false;
  codeIsinSupportSelected: string;
  supports: SupportDetailContratDto[] = [];

  constructor(private readonly responsive: ResponsiveService) {
    this.onResize$ = this.responsive.onResize$;
  }

  _gestFinCompartiment: GestionFinanciereDetailContratDto;

  get gestFinCompartiment() {
    return this._gestFinCompartiment;
  }

  @Input()
  set gestFinCompartiment(gestFinCompartiment: GestionFinanciereDetailContratDto) {
    this._gestFinCompartiment = gestFinCompartiment;
    if (this.gestFinCompartiment && this.gestFinCompartiment.supports) {
      this.supports = [...this.gestFinCompartiment.supports];
      this.supports = this.supports.sort(
        (s1, s2) => s2.pourcentageRepartition - s1.pourcentageRepartition
      );
    }
  }

  ngOnInit() {
  }

  displayEvolutionSupport(codeIsin: string) {
    this.isEvolutionSupportDisplayed = true;
    this.codeIsinSupportSelected = codeIsin;
  }

  disablePopIn() {
    this.isEvolutionSupportDisplayed = false;
  }
}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  DetailsOperationDto,
  OperationDetailContrat,
  OperationDetailInfoDto
} from '@app/models/client/details-contrats.models';
import { DateUtils } from '@app/utils/dateUtils';

@Component({
  selector: 'app-pop-up-details-autre-operation',
  templateUrl: './pop-up-details-autre-operation.component.html',
  styleUrls: ['./pop-up-details-autre-operation.component.scss']
})
export class PopUpDetailsAutreOperationComponent implements OnInit {
  @Output() hideDetails = new EventEmitter<boolean>();
  @Input() detailsOperation: OperationDetailInfoDto[];
  @Input() operation: OperationDetailContrat;
  notDisplay = false;

  constructor() {}

  ngOnInit() {
  }
}

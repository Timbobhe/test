import { Component, Input, OnInit } from '@angular/core';
import { OperationDetailContrat } from '@app/models/client/details-contrats.models';
import { interpreterUnicode } from '@app/utils/stringUtils';

@Component({
  selector: 'app-operation-type',
  templateUrl: './operation-type.component.html',
  styleUrls: ['./operation-type.component.scss'],
})
export class OperationTypeComponent implements OnInit {
  @Input() operation: OperationDetailContrat;
  compratiments: string;

  constructor() {}

  ngOnInit() {
    if (this.operation.contrat.compartimentType === 'C1' || this.operation.contrat.compartimentType === 'C4') {
      if (this.operation.contrat.deductible) {
        this.compratiments = 'Vos versements volontaires - Déductibles';
      } else {
        this.compratiments = 'Vos versements volontaires - Non déductibles';
      }
    } else if (this.operation.contrat.compartimentType === 'C2') {
      this.compratiments = ' Votre épargne salariale';
    } else if (this.operation.contrat.compartimentType === 'C3' && this.operation.contrat.codeSilo === 'ERE' && this.operation.contrat.college.length > 40) {
      this.compratiments =
        ' Vos versements obligatoires' +
        ' - ' +
        interpreterUnicode (this.operation.contrat.college).substr(0, 40) +
        '...';
    } else if (this.operation.contrat.codeSilo === 'ERE') {
      this.compratiments = ' Vos versements obligatoires' + ' - ' + interpreterUnicode(this.operation.contrat.college);
    } else {
      this.compratiments = ' Vos versements obligatoires';
    }
  }
}

import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { GetOperationsContrat } from '@app/actions/details-contrats.action';
import { OperationDetailContrat, OperationDetailInfoDto } from '@app/models/client/details-contrats.models';
import { GlobalState } from '@app/reducers/_index';
import { DateUtils } from '@app/utils/dateUtils';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { DetailsOperationDto } from '@app/models/client/details-contrats.models';

@Component({
  selector: 'app-pop-up-details-operation',
  templateUrl: './pop-up-details-operation.component.html',
  styleUrls: ['./pop-up-details-operation.component.scss']
})
export class PopUpDetailsOperationComponent implements OnInit {
  @Input() displayPop = true;
  @Input() operation: OperationDetailContrat;
  @Output() hideDetails = new EventEmitter<boolean>();

  utils = DateUtils;

  detailsOperation$: Observable<OperationDetailInfoDto[]>;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly reduxApi: ReduxApiService
  ) {
  }

  ngOnInit() {
    this.detailsOperation$ = this.reduxApi
      .execute(new GetOperationsContrat(this.operation.operationId, this.operation.contrat.codeSilo))
      .pipe(
        switchMap(x => this.store.select('contratsDetails')),
        tap(c => {
          if (!c.detailsOperation.loading && !c.detailsOperation.fetched && !c.detailsOperation.error) {
            this.store.dispatch(new GetOperationsContrat(this.operation.operationId, this.operation.contrat.codeSilo));
          }
        }),
        filter(c => c.detailsOperation.fetched),
        map(c => c.detailsOperation.data)
      );
  }

  closePopUp(event: boolean) {
    this.displayPop = event;
    this.hideDetails.emit(true);
  }
}

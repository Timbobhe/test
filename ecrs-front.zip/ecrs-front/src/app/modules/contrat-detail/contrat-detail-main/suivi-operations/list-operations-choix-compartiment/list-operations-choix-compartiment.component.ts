import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-list-operations-choix-compartiment',
  templateUrl: './list-operations-choix-compartiment.component.html',
  styleUrls: ['./list-operations-choix-compartiment.component.scss']
})
export class ListOperationsChoixCompartimentComponent implements OnInit {
  categoriesOptions: SelectItem[];
  @Output() selectedTypeToEmit = new EventEmitter<string>();
  selectedType = 'ALL';
  constructor() {
    this.categoriesOptions = [
      { label: 'Voir tout', value: 'ALL' },
      { label: 'Versements volontaires', value: ['C1', 'C4'] },
      { label: 'Epargne salariale', value: 'C2' },
      { label: 'Versements obligatoires', value: 'C3' }
    ];
  }

  ngOnInit() {}

  onClick(value: string) {
    this.selectedTypeToEmit.emit(value);
  }
}

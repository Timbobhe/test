import { DataStatus, ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { DeviceSize, ThemeService } from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ClearEvolutionsEncours, GetEvolutionEncours } from '@app/actions/details-contrats.action';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import { Periodicite } from '@app/models/client/details-contrats.models';
import { EvolutionEncours } from '@app/models/client/evolution-encours.model';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { EvolutionsEncoursParPeriodicite } from '@app/reducers/details-contrats.reducer';
import { selectContratEvolutionsEncours } from '@app/reducers/ecrs.selectors';
import { DateUtils } from '@app/utils/dateUtils';
import { Store } from '@ngrx/store';
import { SelectItem } from 'primeng/api';
import { EMPTY, of, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { EcrsBarChartComponent } from '@app/modules/ecrs-common/components/ecrs-bar-chart/ecrs-bar-chart.component';

@Component({
  selector: 'app-evolution-ecours',
  templateUrl: './evolution-ecours.component.html',
  styleUrls: ['./evolution-ecours.component.scss']
})
export class EvolutionEcoursComponent implements OnInit, OnDestroy {
  @Input() device: DeviceSize;

  loading = false;
  hasData: boolean;
  evolutionEncours: EvolutionEncours[];
  selectedBarIndex = 0;
  currentEvolutionEncours: EvolutionEncours;
  periodicite: keyof Periodicite = 'MENSUELLE';
  vueOptions: SelectItem[] = [
    {label: '12 derniers mois', value: 'MENSUELLE'},
    {label: '12 derniers trimestres', value: 'TRIMESTRIELLE'},
    {label: '12 derniers semestres', value: 'SEMESTRIELLE'},
    {label: '12 dernières années', value: 'ANNUELLE'}
  ];
  data: any = null;
  chartOptions: any;
  // pour lazyloading
  noDataBars: number[] = [1, 3, 3, 4, 5, 3.5, 4.5, 3.5, 5.5, 7, 8, 10].map(e => e * 30);
  subscriptions: Subscription[] = [];

  @ViewChild('chart') chart: EcrsBarChartComponent;

  constructor(
    private readonly cd: ChangeDetectorRef,
    private readonly store: Store<GlobalState>,
    private readonly reduxApiService: ReduxApiService,
    public themeService: ThemeService,
    public currencyPipe: CurrencyPipe,
    public datePipe: DatePipe) {
  }

  _contrat: ContratDetail;

  get contrat() {
    return this._contrat;
  }

  @Input() set contrat(contrat: ContratDetail) {
    this._contrat = contrat;
    this.initialiseData();
  }

  ngOnInit(): void {
  }

  initialiseData() {
    this.reinit('MENSUELLE');
    this.unsubscribe();
    this.store.dispatch(new ClearEvolutionsEncours());
    this.loadEvolutionByPeriodicite('MENSUELLE');
  }

  changeOnglet(periodicite: keyof Periodicite) {
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.evolutionEncours, periodicite));
    this.loadEvolutionByPeriodicite(periodicite);
  }

  loadEvolutionByPeriodicite(periodicite: keyof Periodicite) {
    this.reinit(periodicite);
    this.unsubscribe();

    this.subscriptions.push(
      this.store.select(selectContratEvolutionsEncours)
        .pipe(
          switchMap((res) => {
            const evolutionsEncoursParPeriodicite: EvolutionsEncoursParPeriodicite = res;
            const evol: DataStatus<EvolutionEncours[]> = evolutionsEncoursParPeriodicite ? evolutionsEncoursParPeriodicite[periodicite] : null;

            if (evol && evol.data) {
              this.evolutionEncours = evol.data.filter(value => value.encours.montantEncours !== 0);
              this.selectedBarIndex = this.evolutionEncours.length - 1;
              this.currentEvolutionEncours = this.evolutionEncours[this.selectedBarIndex];
              this.initialiseChart(this.evolutionEncours);
              this.loading = false;
              return of(evol.data);
            } else if (!evol) {
              return this.reduxApiService.execute(new GetEvolutionEncours(this.contrat, periodicite));
            } else {
              return EMPTY;
            }
          })
        ).subscribe()
    );
  }

  gotoEvolutionEncours(index: number) {
    this.currentEvolutionEncours = this.evolutionEncours[index];
    this.selectedBarIndex = index;
  }

  initialiseChart(evolutionEncours: EvolutionEncours[]) {
    this.hasData = evolutionEncours.filter(evol => evol.encours.montantEncours > 0).length > 1;
    // if set to NaN the graph won't set color for the the selectedBar and corlor bars will be taken from this component's options
    this.selectedBarIndex = this.hasData ? this.selectedBarIndex : Number.NaN;
    const theme = this.themeService.theme.palette;
    evolutionEncours.forEach(value => {
      try {
        value.encours.dateEncours = this.datePipe.transform(DateUtils.convertedStringToDate(value.encours.dateEncours), 'dd/MM/yyyy', '', 'fr-FR');
      } catch (error) {
      }
    });
    const listDateEncours = evolutionEncours.map(ev => ev.encours.dateEncours, this.periodicite);
    const listMontantEncours = evolutionEncours.map(ev => ev.encours.montantEncours);
    const listDateEncoursLength = listDateEncours.length;
    if (listDateEncoursLength < 12) {
      for (let i = 0; i < (12 - listDateEncoursLength); i++) {
        listDateEncours.push('');
        listMontantEncours.push(null);
      }
    }
    this.data = {
      labels: listDateEncours,
      datasets: [
        {
          backgroundColor: this.hasData ? theme.info1.active.main : theme.info1.disabled.light,
          borderColor: this.hasData ? theme.info1.active.main : theme.info1.disabled.light,
          data: this.hasData ? listMontantEncours : this.noDataBars,

        }
      ]
    };
    this.chartOptions = {
      title: {display: false},
      legend: {display: false},
      scales: {
        xAxes: [{
          ticks: {
            callback: (value: any, index: any, values: any) => {
              return this.formateDate(value);
            }
          },
          display: true,
          color: '#ccc',
          gridLines: {
            drawOnChartArea: false
          }
        }],
        yAxes: [{
          ticks: {
            beginAtZero: true,
            callback: (value) => {
              return `${this.currencyPipe.transform(value, 'EUR', 'symbol', '1.0-2', 'fr')}`;
            }
          },
          display: true,
          gridLines: {
            drawOnChartArea: false
          }
        }]
      },
      responsive: true,
      tooltips: {
        enabled: this.hasData,
        callbacks: {
          title: (tooltipItem, data) => this.formateDate(tooltipItem[0].label),
          label: (tooltipItem, data) => `${this.currencyPipe.transform(tooltipItem.value, 'EUR', 'symbol', '1.0-2', 'fr')}`
        },
        yAlign: 'center',
        xAlign: 'center'
      },
      hover: {mode: this.hasData ? 'index' : null},
      plugins: {
        labels: [{render: () => ''}]
      },
      onHover: (e) => {
        const activeElement = this.chart.chart.chart.getElementAtEvent(e);
        if (activeElement && activeElement.length > 0) {
          e.target.style.cursor = 'pointer';
        } else {
          e.target.style.cursor = 'default';
        }
      }
    };
  }

  ngOnDestroy(): void {
    this.unsubscribe();
  }

  private formateDate(value: any) {
    return typeof value === 'string' ? value : this.datePipe.transform(value, 'dd/MM/yyyy', '', 'fr-FR');
  }

  private reinit(periodicite: keyof Periodicite) {
    this.loading = true;
    this.evolutionEncours = null;
    this.selectedBarIndex = 0;
    this.currentEvolutionEncours = null;
    this.periodicite = periodicite;

  }

  private unsubscribe() {
    if (this.subscriptions) {
      this.subscriptions.forEach(s => s && s.unsubscribe());
    }
    this.subscriptions = [];
  }
}

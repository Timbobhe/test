import { Observable } from 'rxjs';
import { Component, Input } from '@angular/core';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-contrat-detail-main',
  templateUrl: './contrat-detail-main.component.html',
  styleUrls: ['./contrat-detail-main.component.scss'],
})
export class ContratDetailMainComponent {
  @Input() contrat: ContratDetail;

  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }
}

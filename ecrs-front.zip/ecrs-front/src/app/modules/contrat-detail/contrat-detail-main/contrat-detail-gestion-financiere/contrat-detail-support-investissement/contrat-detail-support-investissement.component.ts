import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail, GestionFinanciereDetailContratDto } from '@app/models/contrat-detail.model';

@Component({
  selector: 'app-contrat-detail-support-investissement',
  templateUrl: './contrat-detail-support-investissement.component.html',
  styleUrls: ['./contrat-detail-support-investissement.component.scss']
})
export class ContratDetailSupportInvestissementComponent implements OnInit {
  @Input() gestionFinanciereDonut: GestionFinanciereDetailContratDto;
  @Input() contrat: ContratDetail;
  isEvolutionSupportDisplayed = false;
  codeIsinSupportSelected: string;
  constructor() { }

  ngOnInit(): void {
  }

  displayEvolutionSupport(codeIsin: string) {
    this.isEvolutionSupportDisplayed = true;
    this.codeIsinSupportSelected = codeIsin;
  }

  disablePopIn() {
    this.isEvolutionSupportDisplayed = false;
  }

}

import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail, GestionFinanciereDetailContratDto } from '@app/models/contrat-detail.model';
import { DeviceSize } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-details-gestion-financiere-non-pacte-liste',
  templateUrl: './details-gestion-financiere-non-pacte-liste.component.html',
  styleUrls: ['./details-gestion-financiere-non-pacte-liste.component.scss']
})
export class DetailsGestionFinanciereNonPacteListeComponent implements OnInit {
  @Input() contrat: ContratDetail;
  @Input() device: DeviceSize;
  @Input() gestFin: GestionFinanciereDetailContratDto;
  isEvolutionSupportDisplayed = false;
  codeIsinSupportSelected: string;
  constructor() { }

  ngOnInit(): void {
  }
  displayEvolutionSupport(codeIsin: string) {
    this.isEvolutionSupportDisplayed = true;
    this.codeIsinSupportSelected = codeIsin;
  }

  disablePopIn() {
    this.isEvolutionSupportDisplayed = false;
  }
}

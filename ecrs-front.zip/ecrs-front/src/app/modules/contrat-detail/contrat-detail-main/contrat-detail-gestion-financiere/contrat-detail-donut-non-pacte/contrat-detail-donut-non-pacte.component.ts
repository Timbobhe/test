import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail, GestionFinanciereDetailContratDto } from '@app/models/contrat-detail.model';
import {
  initDonutOptions,
  LegendDonut,
  TitleDonut,
  TooltipDonut
} from '@app/modules/ecrs-common/components/ecrs-donut/ecrs-donut.component';
import { Observable } from 'rxjs';
import { DeviceSize, ResponsiveService, ThemeService } from '@ag2rlamondiale/transverse-metier-ng';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';

@Component({
  selector: 'app-contrat-detail-donut-non-pacte',
  templateUrl: './contrat-detail-donut-non-pacte.component.html',
  styleUrls: ['./contrat-detail-donut-non-pacte.component.scss']
})
export class ContratDetailDonutNonPacteComponent implements OnInit {

  @Input() contrat: ContratDetail;
  @Input() dataDonut: any;
  @Input() gestionFinanciereDonut: GestionFinanciereDetailContratDto;
  @Input() montantLength: number;

  titleDonut: TitleDonut = {display: false};
  legendDonut: LegendDonut = {display: false};
  toolTipDonut: TooltipDonut = {enabled: false};
  onResize$: Observable<DeviceSize>;

  options = initDonutOptions({
    title: this.titleDonut,
    legend: this.legendDonut,
    tooltip: this.toolTipDonut,
    isHalfDonut: false,
    animation: false,
  });


  constructor(
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly store: Store<GlobalState>,
    private readonly reduxApiService: ReduxApiService,
    private readonly themeService: ThemeService,
    private readonly responsive: ResponsiveService
  ) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit() {
  }

}

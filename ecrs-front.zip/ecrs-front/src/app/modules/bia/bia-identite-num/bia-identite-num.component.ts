import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { SetParcoursManuscritBia, SetSubtitleBia } from '@app/actions/bia.action';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { ActivatedRoute, Router } from '@angular/router';
import { StartIdentiteNumAction } from '@ag2rlamondiale/transverse-metier-ng';
import { IdentiteNumIntegrationComponent } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-bia-identite-num',
  templateUrl: './bia-identite-num.component.html',
  styleUrls: ['./bia-identite-num.component.scss']
})
export class BiaIdentiteNumComponent implements OnInit, OnDestroy {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly jahiaService: JahiaService,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'identiteNum', 'prevalidation');
    this.store.dispatch(new StartIdentiteNumAction({urlRetourOk: '/bulletin-affiliation'}));
    this.store.dispatch(new SetSubtitleBia({id: 'cancelLink', url: '/bulletin-affiliation'}));
  }

  setCurrentComponent(componentReference: IdentiteNumIntegrationComponent) {
    componentReference.setOnParcoursManuscrit(() => {
        this.store.dispatch(new SetParcoursManuscritBia(true));
        this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute});
      }
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new SetSubtitleBia(null));
  }
}

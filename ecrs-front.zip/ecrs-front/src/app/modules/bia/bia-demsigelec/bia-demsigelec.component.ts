import { Component, OnInit } from '@angular/core';
import { OperationType } from '@app/models/client/operation.model';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { DemandeSigElec } from '@app/actions/sig-elec.action';

@Component({
  selector: 'app-bia-demsigelec',
  templateUrl: './bia-demsigelec.component.html',
  styleUrls: ['./bia-demsigelec.component.scss']
})
export class BiaDemsigelecComponent implements OnInit {
  fonctionnalite: OperationType = 'EBIA';
  demandeEncours: DemandeSigElec;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.store.select('sigElec').subscribe(sigDem => {
      if (sigDem.demande != null) {
        this.demandeEncours = sigDem.demande;
      }
    });
  }
}

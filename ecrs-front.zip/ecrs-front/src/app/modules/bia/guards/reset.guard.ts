import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { ResetStateAction } from '@app/actions/global.actions';
import { BiaComponent } from '@app/modules/bia/bia.component';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { CodeSiloERE } from '@app/models/client/contrat.model';
import { TrackingState } from '@ag2rlamondiale/transverse-metier-ng';

@Injectable({
  providedIn: 'root'
})
export class ResetGuard implements CanDeactivate<BiaComponent>, CanActivate {
  constructor(private readonly store: Store<GlobalState>) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.store.dispatch(new ResetStateAction({
      qad: {},
      bia: {},
      identNumMatchAccount: {},
      sigElec: {},
      tracking: (s: TrackingState) => Object.assign({info: s.info, envTemplate: [CodeSiloERE]})
    }));
    return true;
  }

  canDeactivate(component: BiaComponent,
                currentRoute: ActivatedRouteSnapshot,
                currentState: RouterStateSnapshot,
                nextState?: RouterStateSnapshot) {
    setTimeout(() => this.store.dispatch(new ResetStateAction({
      qad: {},
      bia: {},
      identNumMatchAccount: {},
      sigElec: {},
      tracking: (state: TrackingState) => Object.assign({info: state.info})
    })), 1000);
    return true;
  }
}

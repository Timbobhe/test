import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

@Injectable()
export class ChoixBiaGuard implements CanActivateChild {

  constructor(private readonly store: Store<GlobalState>, private readonly router: Router) {
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot,
                   state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    return selectBia(this.store).pipe(
      take(1),
      map(x => this.isOnStepChoixClauseBeneficiaire(x)
        || this.isOnStepChoixGestionFinanciere(x)
        || this.isOnStepConfirmationChoixClient(x)),
      map((isOnStepsBia: boolean) => {
        if (!isOnStepsBia) {
          return this.router.parseUrl('/bulletin-affiliation/ma-demande');
        } else {
          return true;
        }
      }));
  }


  private isOnStepChoixClauseBeneficiaire(x) {
    return 0 === x.bia.etapeBia.etape && x.router.state.url.endsWith('/choix-clause-beneficiaire');
  }

  private isOnStepChoixGestionFinanciere(x) {
    return 1 === x.bia.etapeBia.etape && x.router.state.url.endsWith('/choix-gestion-financiere');
  }

  private isOnStepConfirmationChoixClient(x) {
    return 2 === x.bia.etapeBia.etape && x.router.state.url.endsWith('/confirmation-choix-client');
  }
}

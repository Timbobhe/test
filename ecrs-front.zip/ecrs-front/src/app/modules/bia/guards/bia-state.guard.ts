import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take, tap } from 'rxjs/operators';
import { isRetourSigElec, UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';

@Injectable({
  providedIn: 'root'
})
export class BiaStateGuard implements CanActivateChild {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    trace('BiaStateGuard#start');
    return selectBia(this.store).pipe(
      take(1),
      map(x =>
        !(x.sigElec.demande !== null && x.router.state.url.endsWith('/demande-signature-electronique'))
        && !isRetourSigElec(x.router.state)
        && !x.bia.isFetched && (!x.router.state.url.startsWith('/bulletin-affiliation/ma-demande'))),
      map(failed => {
        if (failed) {
          const qs = UrlUtils.paramsToQueryString(state.root.queryParams, true);
          return this.router.parseUrl(`/bulletin-affiliation/ma-demande${qs}`);
        } else {
          return true;
        }
      }),
      tap(r => trace('BiaStateGuard#end', r))
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoBiaContrat } from '@app/models/client/bia.model';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PushEtapeBia } from '@app/actions/bia.action';

@Component({
  selector: 'bia-selected-contrat',
  templateUrl: './bia-selected-contrat.component.html',
  styleUrls: ['./bia-selected-contrat.component.scss']
})
export class BiaSelectedContratComponent implements OnInit {
  info$: Observable<{ infoContrats: InfoBiaContrat[], infoContrat: InfoBiaContrat }>;


  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  ngOnInit() {
    this.info$ = selectBia(this.store).pipe(
      map(x => {
        const infoContrats = x.bia.biaModel.bias;
        const infoContrat = x.bia.contratSelected;
        return {infoContrats, infoContrat};
      })
    );
  }

  goToChoixContrat() {
    this.router.navigate(['/bulletin-affiliation/choix-contrat'], {queryParamsHandling: 'preserve'});
    this.store.dispatch(new PushEtapeBia({etape: 0}));
  }
}

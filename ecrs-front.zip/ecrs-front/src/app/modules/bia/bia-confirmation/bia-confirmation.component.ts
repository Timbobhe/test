import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ContratBia } from '@app/models/client/bia.model';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
// @ts-ignore
import baseDocumentStyle from '../../../../styles/document/base-document.css';
import { toCompartimentId } from '@app/models/client/contrat.model';
import { PartenaireIframeService, STEP_COMPLETED } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-bia-confirmation',
  templateUrl: './bia-confirmation.component.html',
  styleUrls: ['./bia-confirmation.component.scss']
})
export class BiaConfirmationComponent implements OnInit, OnDestroy {
  contratSelected: ContratBia;
  subscriptions: Subscription[] = [];
  htmlContentBIA: string;
  htmlContentQAD: string;

  constructor(
    private readonly download: DownloadService,
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly partenaireIframe: PartenaireIframeService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      selectBia(this.store).subscribe(x => {
        this.contratSelected = x.bia.contratSelected.contrat;
        this.htmlContentQAD = x.qad.htmlContent;
      })
    );

    this.htmlContentBIA = document.getElementsByClassName('confirmation-choix-client').item(0).innerHTML;

    this.partenaireIframe.postStep(STEP_COMPLETED);
  }

  downloadDocuments() {
    this.downloadBIA();
    this.downloadQad();
  }

  downloadBIA() {
    this.download.downloadDocument({
      codeDocument: 'PARCOURS_BIA', contratId: this.contratSelected,
      compartimentId: toCompartimentId(this.contratSelected),
      htmlContent: this.htmlContentBIA, htmlStyle: baseDocumentStyle
    });
  }

  downloadQad() {
    if (this.htmlContentQAD != null) {
      this.download.downloadDocument({
        codeDocument: 'RESULTAT_QUAD', contratId: this.contratSelected,
        compartimentId: toCompartimentId(this.contratSelected),
        htmlContent: this.htmlContentQAD, htmlStyle: baseDocumentStyle
      });
    }
  }

  goToPreviousStep() {
    this.router.navigate(['../mes-choix/choix-gestion-financiere'], {relativeTo: this.activeRoute});
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}

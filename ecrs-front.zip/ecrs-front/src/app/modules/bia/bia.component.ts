import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnInit } from '@angular/core';
import { Subtitle } from '@app/models/ui.model';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Observable } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';
import { GetBiaStart } from '@app/actions/bia.action';


@Component({
  selector: 'app-bia',
  templateUrl: './bia.component.html',
  styleUrls: ['./bia.component.scss']
})
export class BiaComponent implements OnInit {
  subtitle$: Observable<Subtitle>;

  constructor(private readonly jahiaService: JahiaService, private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'bia', 'prevalidation', 'identiteNum', 'qad');
    this.subtitle$ = selectBia(this.store).pipe(
      map(x => x.bia.subtitle),
      distinctUntilChanged());

    this.store.dispatch(new GetBiaStart());
  }
}

import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BiaChoixContratComponent } from '@app/modules/bia/bia-choix-contrat/bia-choix-contrat.component';
import { QadModule } from '@app/modules/qad/qad.module';
import { Globals } from '@ag2rlamondiale/transverse-metier-ng';
import { EcrsCommonModule } from '@app/modules/ecrs-common/ecrs-common.module';
import { SharedModule } from '@ag2rlamondiale/transverse-metier-ng';
import { AccordionModule } from 'primeng/accordion';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { BiaChoixComponent } from './bia-choix/bia-choix.component';
import { BiaChoixClauseBeneficiaireComponent } from './bia-choix/bia-choix-clause-beneficiaire/bia-choix-clause-beneficiaire.component';
import { ChoixGestionFinanciereComponent } from './bia-choix/choix-gestion-financiere/choix-gestion-financiere.component';
import { ConfirmationChoixClientBiaComponent } from './bia-choix/confirmation-choix-client-bia/confirmation-choix-client-bia.component';
import { BiaDetailChoixClientComponent } from './bia-choix/bia-detail-choix-client/bia-detail-choix-client.component';
import { BiaConfirmationComponent } from './bia-confirmation/bia-confirmation.component';
import { BiaDemandeComponent } from './bia-demande/bia-demande.component';
import { BiaDemsigelecComponent } from './bia-demsigelec/bia-demsigelec.component';
import { BiaIdentiteNumComponent } from './bia-identite-num/bia-identite-num.component';
import { BiaMatchAccountComponent } from './bia-match-account/bia-match-account.component';
import { BiaQadComponent } from './bia-qad/bia-qad.component';
import { BiaRoutingModule } from './bia-routing.module';
import { BiaSelectedContratComponent } from './bia-selected-contrat/bia-selected-contrat.component';
import { BiaSigelecRedirectComponent } from './bia-sigelec-redirect/bia-sigelec-redirect.component';
import { BiaComponent } from './bia.component';
import { ChoixBiaGuard } from './guards/choix-bia.guard';
import { EffectsModule } from '@ngrx/effects';
import { BiaPartenaireTrackingService } from '@app/modules/bia/bia-partenaire-tracking.service';
import { IdentiteNumModule } from '@ag2rlamondiale/transverse-metier-ng';

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    EffectsModule.forFeature([BiaPartenaireTrackingService]),
    EcrsCommonModule,
    SharedModule,
    JahiaNgModule,
    BiaRoutingModule,
    RouterModule,
    AccordionModule,
    InputTextareaModule,
    IdentiteNumModule,
    QadModule
  ],
  providers: [ChoixBiaGuard, Globals],
  declarations: [
    BiaComponent,
    BiaDemandeComponent,
    BiaChoixContratComponent,
    BiaChoixClauseBeneficiaireComponent,
    BiaChoixComponent,
    ChoixGestionFinanciereComponent,
    BiaMatchAccountComponent,
    ConfirmationChoixClientBiaComponent,
    BiaDetailChoixClientComponent,
    BiaIdentiteNumComponent,
    BiaQadComponent,
    BiaConfirmationComponent,
    BiaSelectedContratComponent,
    BiaSigelecRedirectComponent,
    BiaDemsigelecComponent
  ],
  exports: [
    BiaComponent,
    BiaDemandeComponent,
    BiaChoixContratComponent,
    BiaChoixClauseBeneficiaireComponent,
    BiaChoixComponent,
    BiaMatchAccountComponent,
    BiaConfirmationComponent,
    BiaSelectedContratComponent
  ]
})
export class BiaModule {
}

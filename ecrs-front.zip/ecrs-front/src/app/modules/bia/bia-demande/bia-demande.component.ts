import { Component, OnDestroy, OnInit } from '@angular/core';
import { SetParcoursManuscritBia } from '@app/actions/bia.action';
import { selectBasicBia } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { filter, take } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bia-demande',
  templateUrl: './bia-demande.component.html',
  styleUrls: ['./bia-demande.component.scss']
})
export class BiaDemandeComponent implements OnInit, OnDestroy {
  subscriptions = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select(selectBasicBia).pipe(
        filter(x => x.isFetched && x.biaModel && x.biaModel.sigElecOff),
        take(1))
        .subscribe(x => {
          this.router.navigate(['../choix-contrat'], {
            relativeTo: this.activeRoute,
            queryParamsHandling: 'preserve'
          });
        }));
  }

  updateParcoursManuscrit(event: { isBlockedSigElec: boolean; isManuscrit: boolean }) {
    this.store.dispatch(new SetParcoursManuscritBia(event.isManuscrit));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}

import { Component, Input, NO_ERRORS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { BiaChoixComponent } from './bia-choix.component';

@Component({ selector: 'jahia-dico', template: '' })
class JahiaDicoStubComponent {
  @Input() dicoId: string;
  @Input() title: string;
  valeur = function () { };
}

@Component({selector: 'app-bia-choix', template: ''})
class DummyComponent {}

describe('BiaChoixComponent', () => {
  let component: BiaChoixComponent;
  let fixture: ComponentFixture<BiaChoixComponent>;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ StoreModule.forRoot(fromRoot.reducers),
        RouterTestingModule.withRoutes([{
          path: '**',
          component: DummyComponent
        }])],
      declarations: [BiaChoixComponent, JahiaDicoStubComponent, DummyComponent],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaChoixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

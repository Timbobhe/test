import { Component, OnDestroy, OnInit } from '@angular/core';
import { PushEtapeBia, SetSubtitleBia } from '@app/actions/bia.action';
import { ContratBia, InfoBiaContrat } from '@app/models/client/bia.model';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Observable, Subscription } from 'rxjs';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';

@Component({
  selector: 'app-bia-choix',
  templateUrl: './bia-choix.component.html',
  styleUrls: ['./bia-choix.component.scss']
})
export class BiaChoixComponent implements OnInit, OnDestroy {
  currentPage = 0;
  subscriptions: Subscription[] = [];
  infoContrats: InfoBiaContrat[];
  contratBia: ContratBia;
  idContrat: string;
  onResize$: Observable<DeviceSize>;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly responsive: ResponsiveService) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit() {
    this.store.dispatch(new SetSubtitleBia({id: 'selectedContrat'}));
    this.subscriptions.push(
      selectBia(this.store).subscribe(x => {
        this.infoContrats = x.bia.biaModel.bias;
        this.contratBia = x.bia.contratSelected.contrat;
        this.currentPage = x.bia.etapeBia.etape;
      })
    );
  }

  onActivate(event: any) {
    if (event.next) {
      event.next.subscribe(x => {
        this.currentPage = x;
        this.store.dispatch(new PushEtapeBia({etape: this.currentPage}));
      });
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
    this.store.dispatch(new SetSubtitleBia(null));
  }

  handleClickDownload() {
    this.store.dispatch(tracking(Categorie.bia, TypeOriginAction.downloadDocument, 'notice_information_salarie'));
  }
}

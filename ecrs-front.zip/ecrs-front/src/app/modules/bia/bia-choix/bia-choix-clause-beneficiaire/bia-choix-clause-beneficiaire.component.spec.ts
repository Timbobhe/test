import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { testingModule } from '../../../../../test/ecrs-testing';
import { initialStateWithBiaEtape0 } from '../../../../../test/store-states.mock';
import { BiaChoixClauseBeneficiaireComponent } from './bia-choix-clause-beneficiaire.component';


describe('BiaChoixClauseBeneficiaireComponent', () => {
  let component: BiaChoixClauseBeneficiaireComponent;
  let fixture: ComponentFixture<BiaChoixClauseBeneficiaireComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({ ...initialStateWithBiaEtape0 }, {
      declarations: [BiaChoixClauseBeneficiaireComponent],
      providers: [BiaChoixClauseBeneficiaireComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaChoixClauseBeneficiaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

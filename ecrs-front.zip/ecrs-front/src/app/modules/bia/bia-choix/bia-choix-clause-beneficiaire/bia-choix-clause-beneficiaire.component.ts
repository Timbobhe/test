import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { PushClauseSelected } from '@app/actions/bia.action';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import { CLAUSE_SPECIFIQUE, ClauseBeneficiaireModel, TypeClause } from '@app/models/client/clause-beneficiaire.model';


@Component({
  selector: 'app-bia-choix-clause-beneficiaire',
  templateUrl: './bia-choix-clause-beneficiaire.component.html',
  styleUrls: ['./bia-choix-clause-beneficiaire.component.scss']
})
export class BiaChoixClauseBeneficiaireComponent implements OnInit, OnDestroy {
  @Output() next: EventEmitter<any> = new EventEmitter;
  subscriptions = [];
  nomContrat: string;
  isClauseStandard: boolean;
  contenuClause: string;
  contenuSpecifique: string;
  descClauseBenef: string;

  tc_category_bia = Categorie.bia;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.subscriptions.push(this.store.select('bia').subscribe(bia => {
      this.isClauseStandard = bia.choixClauseBeneficiaire.clauseStandard;
      if (!this.isClauseStandard) {
        this.contenuSpecifique = bia.choixClauseBeneficiaire.contenuClause;
      }
      this.nomContrat = bia.contratSelected.contrat.nomContrat;
      this.descClauseBenef = bia.contratSelected.contrat.descClauseBenef;
    }));
  }

  goToNextStep(event: ClauseBeneficiaireModel) {
    if (event.typeClause === CLAUSE_SPECIFIQUE) {
      this.store.dispatch(tracking(Categorie.bia, TypeOriginAction.clauseSpecifique, 'validation'));
    }

    this.store.dispatch(new PushClauseSelected(event));
    this.router.navigate(['../choix-gestion-financiere'], {relativeTo: this.activeRoute});
    this.next.emit(1);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  handleChangeTypeClause(typeClause: TypeClause) {
    if (typeClause === CLAUSE_SPECIFIQUE) {
      this.store.dispatch(tracking(Categorie.bia, TypeOriginAction.clauseSpecifique, 'redaction'));
    }
  }
}

import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { initialStateWithBiaEtape1 } from '../../../../../test/store-states.mock';
import { ChoixGestionFinanciereComponent } from './choix-gestion-financiere.component';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { Subscription } from 'rxjs';
import { DownloadDocument } from '@app/models/client/download-document.model';
import { testingModule } from '../../../../../test/ecrs-testing';


describe('ChoixGestionFinanciereComponent', () => {
  let component: ChoixGestionFinanciereComponent;
  let fixture: ComponentFixture<ChoixGestionFinanciereComponent>;
  let downloadServiceStub: Partial<DownloadService>;

  downloadServiceStub = {
    downloadDocument({contratId, codeDocument, htmlContent, htmlStyle}: DownloadDocument) {
      return new Subscription();
    }
  };


  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithBiaEtape1}, {
      providers: [
        {provide: DownloadService, useValue: downloadServiceStub}
      ],
      declarations: [ChoixGestionFinanciereComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoixGestionFinanciereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

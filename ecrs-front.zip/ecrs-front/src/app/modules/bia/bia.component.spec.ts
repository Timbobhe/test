import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { BiaComponent } from './bia.component';
import { RouterTestingModule } from '@angular/router/testing';
import { testingModule } from '../../../test/ecrs-testing';

describe('BiaComponent', () => {
  let component: BiaComponent;
  let fixture: ComponentFixture<BiaComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [BiaComponent],
      // imports: [RouterTestingModule.withRoutes([])],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

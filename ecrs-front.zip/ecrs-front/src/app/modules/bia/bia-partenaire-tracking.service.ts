import { Injectable } from '@angular/core';
import { PartenaireIframeService, STEP_SIGELEC, STEP_STARTED  } from '@ag2rlamondiale/transverse-metier-ng';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { BIA_START, BIA_TERMINATE } from '@app/actions/bia.action';
import { API, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { catchError, filter, map, takeUntil, tap } from 'rxjs/operators';
import { EMPTY } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BiaPartenaireTrackingService {

  @Effect({dispatch: false})
  started$ = this.actions$.pipe(
    ofType(API),
    map(a => a as ApiAction<any>),
    filter(a => a.payload.label === BIA_START),
    takeUntil(this.partenaireIframe.inactive$()),
    tap(a => this.partenaireIframe.postStep(STEP_STARTED)),
    catchError(e => {
      console.error('Error partenaireIframe BIA', STEP_STARTED, e);
      return EMPTY;
    })
  );

  @Effect({dispatch: false})
  sigelec$ = this.actions$.pipe(
    ofType(API),
    map(a => a as ApiAction<any>),
    filter(a => a.payload.label === BIA_TERMINATE),
    takeUntil(this.partenaireIframe.inactive$()),
    tap(a => this.partenaireIframe.postStep(STEP_SIGELEC)),
    catchError(e => {
      console.error('Error partenaireIframe BIA', STEP_SIGELEC, e);
      return EMPTY;
    })
  );


  constructor(
    private readonly actions$: Actions,
    private readonly partenaireIframe: PartenaireIframeService) {
  }
}

import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PushContratSelected, SetParcoursManuscritBia } from '@app/actions/bia.action';
import { ContratBia, InfoBiaContrat } from '@app/models/client/bia.model';
import { MiniContrat } from '@app/models/client/contrat.model';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-bia-choix-contrat',
  templateUrl: './bia-choix-contrat.component.html',
  styleUrls: ['./bia-choix-contrat.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BiaChoixContratComponent implements OnInit, OnDestroy {
  subscriptions = [];
  infoContrats: InfoBiaContrat[];
  contratsbia: ContratBia[] = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly cd: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.cd.detach();
    this.subscriptions.push(
      selectBia(this.store).subscribe(x => {
        this.infoContrats = x.bia.biaModel.bias;
        this.contratsbia = x.bia.biaModel.bias.map(b => b.contrat);
        this.cd.detectChanges();
      })
    );
  }

  goToNextStep(event: MiniContrat) {
    const infoContrat: InfoBiaContrat = this.infoContrats.find(c => c.contrat === event);
    if (infoContrat.sigElecOff) {
      this.store.dispatch(new SetParcoursManuscritBia(true));
    }
    this.store.dispatch(new PushContratSelected(infoContrat));
    this.router.navigate(['../mes-choix'], {relativeTo: this.activeRoute});
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { BiaChoixContratComponent } from './bia-choix-contrat.component';



describe('BiaChoixContratComponent', () => {
  let component: BiaChoixContratComponent;
  let fixture: ComponentFixture<BiaChoixContratComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(fromRoot.reducers),
        RouterModule.forRoot([])],
      declarations: [BiaChoixContratComponent],
      providers: [BiaChoixContratComponent],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaChoixContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

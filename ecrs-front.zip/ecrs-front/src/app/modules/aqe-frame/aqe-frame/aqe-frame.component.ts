import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AqeaRedirectService } from '@app/services/aqea-redirect.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { map, tap, withLatestFrom } from 'rxjs/operators';
import { BehaviorSubject, Observable, Subscription, timer } from 'rxjs';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { PushError } from '@app/actions/ui.actions';
import { LEVEL_SEVERITY_MAJOR } from '@ag2rlamondiale/redux-api-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

@Component({
  selector: 'app-aqe-frame',
  templateUrl: './aqe-frame.component.html',
  styleUrls: ['./aqe-frame.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AqeFrameComponent implements OnInit, OnDestroy {
  target$: Observable<SafeUrl>;
  onResize$: Observable<DeviceSize>;
  isLoading$ = new BehaviorSubject<boolean>(true);

  subscriptions: Subscription[] = [];

  constructor(
    private readonly route: ActivatedRoute,
    private readonly aqeRedirectService: AqeaRedirectService,
    private readonly domSanitizer: DomSanitizer,
    private readonly responsive: ResponsiveService,
    private readonly store: Store<GlobalState>,
    private readonly configService: ConfigService) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit(): void {
    const pageId$ = this.route.paramMap.pipe(map(params => params.get('pageId')));
    const queryParams$ = this.route.queryParams;

    this.target$ = pageId$.pipe(
      withLatestFrom(queryParams$),
      map(([pageId, queryParams]) => this.aqeRedirectService.redirectToPage(pageId, queryParams, {
        redirect: false,
        frame: true,
        realUrl: true,
        appendFdi: false
      })),
      map(computedLink => this.domSanitizer.bypassSecurityTrustResourceUrl(computedLink.url)),
      // map(url => this.domSanitizer.bypassSecurityTrustResourceUrl('http://localhost:4200/?frame#/contrat-detail')),
      tap(e => console.log('URL', e))
    );

    // Force la fin de l'affichage du progress au bout de XX sec
    this.subscriptions.push(
      timer(this.configService.config.aqea_mode_iframe?.progressTime || 10000).subscribe(() => this.isLoading$.next(false))
    );
  }

  handleLoad($event: Event) {
    console.log('handleLoad', $event);
    // this.isLoading$.next(false);
  }

  handleError($event: ErrorEvent) {
    console.error('handleError', $event);
    this.store.dispatch(new PushError({
      error: new Error('Erreur pendant le chargement AQE'),
      errorType: 'FRONT',
      severity: LEVEL_SEVERITY_MAJOR
    }));
    this.isLoading$.next(false);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  handleAccessible() {
    this.isLoading$.next(false);
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { ResetStateAction } from '@app/actions/global.actions';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { TrackingState } from '@ag2rlamondiale/transverse-metier-ng';

@Injectable({
  providedIn: 'root'
})
export class ResetGuard implements CanActivate {
  constructor(private readonly store: Store<GlobalState>) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.store.dispatch(new ResetStateAction({
      arbitrage: {},
      sigElec: {},
      qad: {},
      tracking: (state: TrackingState) => Object.assign({info: state.info})
    }));
    return true;
  }
}

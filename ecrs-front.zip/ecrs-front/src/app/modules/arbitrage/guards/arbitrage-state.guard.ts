import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take, tap } from 'rxjs/operators';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { SetSubtitleArbitrage } from '@app/actions/arbitrage.action';
import { paramsToQueryString, isRetourSigElec } from '@ag2rlamondiale/transverse-metier-ng';

@Injectable({
  providedIn: 'root'
})
export class ArbitrageStateGuard implements CanActivateChild {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    trace('ArbitrageStateGuard#start');
    return selectArbitrage(this.store).pipe(
      take(1),
      tap(x => {
        console.log('demande en cours', x.sigElec.demande);
        if (x.router.state.url.startsWith('/modification-gestion-financiere/ma-demande')) {
          this.store.dispatch(new SetSubtitleArbitrage({id: null}));
        }
      }),
      map(x =>
        !(x.sigElec.demande !== null && x.router.state.url.endsWith('/demande-signature-electronique'))
        && !isRetourSigElec(x.router.state)
        && !x.arbitrage.isFetched && (!x.router.state.url.startsWith('/modification-gestion-financiere/ma-demande'))),
      map(failed => {
        if (failed) {
          const qs = paramsToQueryString(state.root.queryParams, true);
          return this.router.parseUrl(`/modification-gestion-financiere/ma-demande${qs}`);
        } else {
          return true;
        }
      }),
      tap(r => trace('ArbitrageStateGuard#end', r))
    );
  }
}

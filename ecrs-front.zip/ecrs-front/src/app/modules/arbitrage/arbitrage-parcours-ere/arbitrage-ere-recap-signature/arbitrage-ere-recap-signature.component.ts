import { Component, OnDestroy, OnInit } from '@angular/core';
import { Etape2, EtapeArbitrage, EtapeFin } from '@app/models/client/arbitrage.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ActivatedRoute, Router } from '@angular/router';
import { ArbitrageEtapeComponent } from '@app/modules/arbitrage/arbitrage-etape-component';
import { MiniContrat } from '@app/models/client/contrat.model';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
// @ts-ignore
import { ImpersonationService } from '@ag2rlamondiale/transverse-metier-ng';
import { PartenaireIframeService, STEP_SUMMARY } from '@ag2rlamondiale/transverse-metier-ng';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { filter } from 'rxjs/operators';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { QadState } from '@app/reducers/qad.reducer';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';
import { ClientInfoState } from '@app/reducers/client-infos.reducer';


@Component({
  selector: 'app-arbitrage-ere-recap-signature',
  templateUrl: './arbitrage-ere-recap-signature.component.html',
  styleUrls: ['./arbitrage-ere-recap-signature.component.scss']
})
export class ArbitrageEreRecapSignatureComponent implements OnInit, OnDestroy, ArbitrageEtapeComponent {

  etapeCourante = Etape2;
  contrat: MiniContrat;
  clientInfo: ClientInfoState;
  parcoursManuscrit: boolean;
  arbitragesClient: ArbitrageClient[];

  private questions: any;
  arbitrageState: ArbitrageState;
  qadState: QadState;

  subscriptions = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly impersonationService: ImpersonationService,
    private readonly arbitrageStateService: ArbitrageStateService,
    private readonly partenaireIframe: PartenaireIframeService,
    private readonly routeEtape: ArbitrageRouteEtapeService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      selectArbitrage(this.store).pipe(
        filter(x => !!x.arbitrage.questions.choixCompartimentERE.choix && !!x.arbitrage.questions.choixFluxStock.choix)
      ).subscribe(x => {
        this.contrat = x.arbitrage.contratSelected.contrat;
        this.questions = x.arbitrage.questions;
        this.parcoursManuscrit = x.arbitrage.parcoursManuscrit;
        this.arbitragesClient = x.arbitrage.arbitragesClient;
        this.arbitrageState = x.arbitrage;
        this.qadState = x.qad;
        this.clientInfo = x.info;
      })
    );

    this.partenaireIframe.postStep(STEP_SUMMARY);
  }

  canNext(etapeCourante: EtapeArbitrage): boolean {
    return true;
  }

  goToNext(etapeCourante: EtapeArbitrage): void {
    this.routeEtape.goToEtape(EtapeFin);
    if (this.parcoursManuscrit) {
      this.router.navigate(['../../confirmation-manuscrit'], {relativeTo: this.activeRoute});
    } else {
      this.arbitrageStateService.endArbitrageWithSigElec(this.arbitrageState, this.qadState, this.clientInfo);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

}

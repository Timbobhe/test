import { Component, OnInit } from '@angular/core';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Observable } from 'rxjs';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import {QadState} from '@app/reducers/qad.reducer';
import {QadProposition} from '@app/models/client/qad.model';
import {cleanLabelProposition} from '@app/modules/qad/qad-proposition/qad-proposition.component';

@Component({
  selector: 'app-arbitrage-detail-choix-client',
  templateUrl: './arbitrage-detail-choix-client.component.html',
  styleUrls: ['./arbitrage-detail-choix-client.component.scss']
})
export class ArbitrageDetailChoixClientComponent implements OnInit {
  info$: Observable<{ arbitrage: ArbitrageState, qad: QadState}>;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.info$ = selectArbitrage(this.store).pipe(
      map(x => {
        return {arbitrage: x.arbitrage, qad: x.qad};
      })
    );
  }

  filtrerSelected(repartition: RepartitionSupport[]) {
    return repartition.filter(e => e.selectionned);
  }


  dateEncours(info: ArbitrageState) {
    return info.contratSelected.contrat.encours.dateEncours;
  }

  label(qadProposition: QadProposition) {
    return cleanLabelProposition(qadProposition);
  }
}

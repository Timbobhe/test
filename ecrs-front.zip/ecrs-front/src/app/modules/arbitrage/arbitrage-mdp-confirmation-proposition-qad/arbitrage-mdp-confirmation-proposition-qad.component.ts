import { Component, OnInit } from '@angular/core';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {
  ChoixQadMdp,
  convertPropositionToRepartitionSupports,
  InfoQad,
  QadProposition
} from '@app/models/client/qad.model';
import { cleanLabelProposition } from '@app/modules/qad/qad-proposition/qad-proposition.component';
import { ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { ActivatedRoute, Router } from '@angular/router';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { PushChoixRepartitionSupport, SetConsentementAccept } from '@app/actions/arbitrage.action';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { ConsentementEvent } from '@app/modules/arbitrage/arbitrage-consentement/arbitrage-consentement.component';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { QadState } from '@app/reducers/qad.reducer';
import { ClientInfoState } from '@app/reducers/client-infos.reducer';

interface Info {
  choix: ChoixQadMdp;
  infoQad: InfoQad;
  nouvelleRepartitionDefined: boolean;
  consentementChecked: boolean;
  arbitrage: ArbitrageState;
  qad: QadState;
  clientInfo: ClientInfoState;
}

@Component({
  selector: 'app-arbitrage-mdp-confirmation-proposition-qad',
  templateUrl: './arbitrage-mdp-confirmation-proposition-qad.component.html',
  styleUrls: ['./arbitrage-mdp-confirmation-proposition-qad.component.scss']
})
export class ArbitrageMdpConfirmationPropositionQadComponent implements OnInit {

  info$: Observable<Info>;
  arbitragesClient$: Observable<ArbitrageClient[]>;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    public readonly responsive: ResponsiveService,
    private readonly arbitrageState: ArbitrageStateService) {
  }

  ngOnInit() {

    this.arbitragesClient$ = selectArbitrage(this.store).pipe(
      tap(x => console.log('ArbitrageMdpConfirmationPropositionQadComponent', x)),
      tap(x => this.arbitrageState.dispatchGestionsFinancieres(x.arbitrage)),
      switchMap(x => this.arbitrageState.createArbitragesClient$()));

    this.info$ = selectArbitrage(this.store).pipe(
      map(x => {
        if (x.arbitrage.arbitragesClient && x.arbitrage.arbitragesClient[0].nouvelleRepartition.isEmpty() && x.qad.choixPropositionMdp) {
          const nouvellesRepartitions = new Map<ArbitrageClient, RepartitionSupport[]>();
          nouvellesRepartitions.set(x.arbitrage.arbitragesClient[0],
            convertPropositionToRepartitionSupports(x.qad.choixPropositionMdp.proposition.typeProposition));
          this.store.dispatch(new PushChoixRepartitionSupport({reponse: nouvellesRepartitions}));
        }

        return {
          choix: x.qad.choixPropositionMdp,
          infoQad: {contratId: x.arbitrage.contratSelected.contrat},
          nouvelleRepartitionDefined: x.arbitrage.arbitragesClient && x.arbitrage.arbitragesClient[0].nouvelleRepartition.isNotEmpty(),
          consentementChecked: x.arbitrage.consentementsMdp && x.arbitrage.consentementsMdp.supportsInvestissement && x.arbitrage.consentementsMdp.tutelle,
          arbitrage: x.arbitrage,
          qad: x.qad,
          clientInfo: x.info
        };
      }),
      filter(x => !!x.choix && !!x.infoQad && x.nouvelleRepartitionDefined && !!x.arbitrage && !!x.qad)
    );
  }

  label(qadProposition: QadProposition) {
    return cleanLabelProposition(qadProposition);
  }

  handleChoixPropositionMdp(choix: ChoixQadMdp) {
    if (choix.arbitragePerso) {
      this.router.navigate(['../etape/choix-arbitrage'], {relativeTo: this.activeRoute});
    }
  }

  handleCheckConsentement(consentementEvent: ConsentementEvent) {
    if (consentementEvent && consentementEvent.enabled) {
      const consentementId = consentementEvent.consentementId;
      this.store.dispatch(new SetConsentementAccept({[consentementId]: consentementEvent.accepted}));
    }
  }

  next(info: Info) {
    if (info.arbitrage.parcoursManuscrit) {
      this.router.navigate(['../confirmation-manuscrit'], {relativeTo: this.activeRoute});
    } else {
      this.arbitrageState.endArbitrageWithSigElec(info.arbitrage, info.qad, info.clientInfo);
    }
  }
}

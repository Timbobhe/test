import { Reponse } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { QuestionReponses, QuestionState } from '@app/models/question-responses.model';

@Component({
  selector: 'app-arbitrage-choix-compartiment',
  templateUrl: './arbitrage-choix-compartiment.component.html',
  styleUrls: ['./arbitrage-choix-compartiment.component.scss']
})
export class ArbitrageChoixCompartimentComponent implements OnInit {

  @Input() questionState: QuestionState;

  @Input() isParcoursSimplifie = false;

  @Output() optionSelected = new EventEmitter<{ reponse: Reponse, goToNext: boolean }>();

  questionReponseToutCompart: QuestionReponses;

  questionReponseOtherCompart: QuestionReponses;

  showOtherChoices = false;

  ready = false;

  constructor() {
  }

  ngOnInit() {
    const propsToutCompartiment = this.questionState.questionReponse.propositions.find(p => p.value.tousCompartiments);
    this.questionReponseToutCompart = {...this.questionState.questionReponse};
    if (this.questionState && propsToutCompartiment) {
      this.questionReponseToutCompart.propositions = [propsToutCompartiment, this.propsOtherChoices()];
      this.questionReponseOtherCompart = {...this.questionState.questionReponse};
      this.questionReponseOtherCompart.propositions = this.questionState.questionReponse.propositions.filter(p => !p.value.tousCompartiments);
      this.questionReponseOtherCompart.question = {
        id: 'ARBITRAGE_CHOIX_COMPARTIMENT',
        jahiaDicoEntry: 'ARB_QUESTION_COMPARTIMENT_2'
      };
    }
    this.ready = true;
  }

  propsOtherChoices(): Reponse {
    const others = new Reponse();
    others.id = 'showOtherChoices';
    others.label = 'Choisir une partie de votre contrat (Avancé)';
    return others;
  }

  selectOption($event: { reponse: Reponse, goToNext: boolean }) {
    if ($event.reponse.id === 'showOtherChoices') {
      this.showOtherChoices = !this.showOtherChoices;
    } else {
      this.optionSelected.emit($event);
    }
  }

}

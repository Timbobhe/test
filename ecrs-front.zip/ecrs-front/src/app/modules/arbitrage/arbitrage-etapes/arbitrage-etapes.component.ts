import {Component, OnDestroy, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Etape0, Etape1, Etape2, EtapeArbitrage, EtapeInit } from '@app/models/client/arbitrage.model';
import { ArbitrageEtapeComponent } from '@app/modules/arbitrage/arbitrage-etape-component';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Step } from '@ag2rlamondiale/transverse-metier-ng';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Store } from '@ngrx/store';
import {Observable, Subscription} from 'rxjs';
import { map } from 'rxjs/operators';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';


@Component({
  selector: 'app-arbitrage-etapes',
  templateUrl: './arbitrage-etapes.component.html',
  styleUrls: ['./arbitrage-etapes.component.scss']
})
export class ArbitrageEtapesComponent implements OnInit, OnDestroy {
  steps: Array<Step> = [
    {index: 0, label: 'Choix de l\'arbitrage'},
    {index: 1, label: 'Choisir une répartition'},
    {index: 2, label: 'Récapitulatif et signature'}
  ];

  infoEtape$: Observable<{ etape: EtapeArbitrage; qad: boolean; parcoursManuscrit: boolean }>;
  componentEtapeReference: ArbitrageEtapeComponent;
  onResize$: Observable<DeviceSize>;
  subscriptions: Subscription[] = [];


  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly routeEtape: ArbitrageRouteEtapeService,
    private readonly responsiveService: ResponsiveService,
    public readonly arbitrageQadService: ArbitrageStateService
  ) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
    this.infoEtape$ = selectArbitrage(this.store).pipe(
      map(x => {
        return {etape: x.arbitrage.etape, qad: true, parcoursManuscrit: x.arbitrage.parcoursManuscrit};
        // return {etape: x.arbitrage.etape, qad: x.arbitrage.contratSelected.qadStatus !== 'IMPOSSIBLE'};
      })
    );
  }

  goToEtapePrecedente(etapeCourante: EtapeArbitrage) {
    switch (etapeCourante.index) {
      case 0:
        this.routeEtape.navigateToEtape(EtapeInit);
        break;

      case 1:
        this.routeEtape.navigateToEtape(Etape0);
        break;

      case 2:
        this.routeEtape.navigateToEtape(Etape1);
        break;
    }
  }

  goToEtapeSuivante(etapeCourante: EtapeArbitrage) {
    if (this.componentEtapeReference) {
      this.componentEtapeReference.goToNext(etapeCourante);
    }
  }

  hasEtapePrecedente(etapeCourante: EtapeArbitrage) {
    return etapeCourante.index >= 1;
  }

  setCurrentEtapeComponent(componentReference: any) {
    this.componentEtapeReference = componentReference;
  }

  ctaLabel(etapeCourante: EtapeArbitrage) {
    switch (etapeCourante.index) {
      case 0:
        return 'Continuer';

      case 1:
        return 'Valider';

      case 2:
      case 3:
        let ctaLabel = '';
        this.subscriptions.push(this.infoEtape$.subscribe(value => {
          ctaLabel = value.parcoursManuscrit ? 'Confirmer' : 'Confirmer et signer ma demande';
        }));
        return ctaLabel;
    }
    return null;
  }

  isCtaDisabled(etapeCourante: EtapeArbitrage) {
    if (this.componentEtapeReference) {
      return !this.componentEtapeReference.canNext(etapeCourante);
    }

    return true;
  }

  changeStep(step: Step) {
    switch (step.index) {
      case 0:
        this.routeEtape.navigateToEtape(Etape0);
        break;

      case 1:
        this.routeEtape.navigateToEtape(Etape1);
        break;

      case 2:
        this.routeEtape.navigateToEtape(Etape2);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

}

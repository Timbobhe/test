import { EtapeArbitrage } from '@app/models/client/arbitrage.model';

export interface ArbitrageEtapeComponent {
  canNext(etapeCourante: EtapeArbitrage): boolean;

  goToNext(etapeCourante: EtapeArbitrage): void;
}

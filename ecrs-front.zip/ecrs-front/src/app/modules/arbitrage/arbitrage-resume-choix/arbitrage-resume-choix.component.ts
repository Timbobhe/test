import { Component, Input, OnInit } from '@angular/core';
import {
  EtapeArbitrage,
  findEtapeForQuestion,
  findEtapesPrecedentes,
  QuestionModel
} from '@app/models/client/arbitrage.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import { CodeSiloType, ContratId } from '@app/models/client/contrat.model';
import { ChoixQuestion, QuestionState, QuestionType } from '@app/models/question-responses.model';
import { Observable } from 'rxjs';
import { ModifierReponse } from '@app/actions/arbitrage.action';
import { ActivatedRoute, Router } from '@angular/router';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';


export type VarianteResume = 'EtapeCourante' | 'EtapePrecedente' | 'EtapeFinale';

@Component({
  selector: 'app-arbitrage-resume-choix',
  templateUrl: './arbitrage-resume-choix.component.html',
  styleUrls: ['./arbitrage-resume-choix.component.scss']
})
export class ArbitrageResumeChoixComponent implements OnInit {

  @Input() contrat: ContratId = null;
  @Input() collapsed: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly routeEtape: ArbitrageRouteEtapeService) {
  }

  get etapeCourante(): EtapeArbitrage {
    return this._etapeCourante;
  }

  @Input() set etapeCourante(value: EtapeArbitrage) {
    this._etapeCourante = value;
    this.resetQuestionsState();
  }

  get variante(): VarianteResume {
    return this._variante;
  }

  @Input() set variante(value: VarianteResume) {
    this._variante = value;
    this.resetQuestionsState();
  }

  @Input() closable = true;

  private _etapeCourante: EtapeArbitrage;
  private _variante: VarianteResume;
  questionsState$: Observable<{ choixQuestions: QuestionState[], silo: CodeSiloType | string }>;

  private static filterQuestionAffichable(type: QuestionType) {
    return type !== 'ARBITRAGE_CHOIX_EUROSPOURCENT';
  }

  ngOnInit() {
  }

  private resetQuestionsState() {
    if (this._etapeCourante && this._variante) {
      this.questionsState$ = selectArbitrage(this.store).pipe(
        map(x => {
          return {
            choixQuestions: this.selectQuestions(x.arbitrage.questions, x.arbitrage.contratSelected.contrat.codeSilo),
            silo: x.arbitrage.contratSelected.contrat.codeSilo
          };
        })
      );
    }
  }


  private selectQuestions(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    if (this._variante === 'EtapeCourante') {
      return this.selectQuestionsEtapeCourante(questions, silo);
    } else if (this._variante === 'EtapePrecedente') {
      return this.selectQuestionsEtapePrecedente(questions, silo);
    } else if (this._variante === 'EtapeFinale') {
      return this.selectQuestionsEtapePrecedente(questions, silo);
    }

    return [];
  }

  private selectQuestionsEtapeCourante(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    return this._etapeCourante.questionsType[silo]
      .filter(type => ArbitrageResumeChoixComponent.filterQuestionAffichable(type))
      .map(type => questions.fromType(type))
      .filter(qs => qs.isFetched && qs.value);
  }

  private selectQuestionsEtapePrecedente(questions: QuestionModel, silo: CodeSiloType | string): QuestionState[] {
    const res: QuestionState[] = [];

    findEtapesPrecedentes(this._etapeCourante)
      .filter(e => !!e.questionsType)
      .map(e => e.questionsType[silo])
      .filter(e => !!e)
      .forEach(types => {
        types
          .filter(type => ArbitrageResumeChoixComponent.filterQuestionAffichable(type))
          .map(type => questions.fromType(type))
          .filter(qs => qs.isFetched && qs.value)
          .forEach(qs => res.push(qs));
      });

    return res;
  }


  handleModifierChoix(choixQuestion: ChoixQuestion, silo: CodeSiloType) {
    const target = findEtapeForQuestion(choixQuestion.questionReponse.question.id, silo);
    this.store.dispatch(new ModifierReponse({
      questionType: choixQuestion.questionReponse.question.id,
      etape: target,
      deplacement: this.etapeCourante.index > target.index ? 'prev' : 'next'
    }));
    this.routeEtape.navigateToEtape(target);
  }

}

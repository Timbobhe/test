import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { PushContratSelected, SetParcoursManuscritArbitrage } from '@app/actions/arbitrage.action';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { InfoArbitrageContrat } from '@app/models/client/arbitrage.model';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';
import { DeviceSize, ResponsiveService, InfosBlocagesClient } from '@ag2rlamondiale/transverse-metier-ng';
import { ChoixQadMdp, InfoQad } from '@app/models/client/qad.model';

@Component({
  // @ts-ignore
  moduleId: module.id,
  selector: 'app-arbitrage-choix-contrat',
  templateUrl: 'arbitrage-choix-contrat.component.html',
  styleUrls: ['arbitrage-choix-contrat.component.scss']
})
export class ArbitrageChoixContratComponent implements OnInit, OnDestroy {

  onResize$: Observable<DeviceSize>;

  choixContrats$: Observable<{ arbitrages: InfoArbitrageContrat[], blocage: InfosBlocagesClient }>;
  subscriptions = [];

  infoQadAutoLaunch$: Observable<InfoQad>;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly arbitrageQadService: ArbitrageStateService,
    private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
    this.choixContrats$ = selectArbitrage(this.store).pipe(
      map(x => {
        const arbitrages = x.arbitrage.arbitrageModel ? x.arbitrage.arbitrageModel.arbitrages : [];
        return {arbitrages, blocage: x.info.infosBlocagesClient};
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  goToNextStep(infoArbitrageContrat: InfoArbitrageContrat) {
    if (infoArbitrageContrat.sigElecOff) {
      this.store.dispatch(new SetParcoursManuscritArbitrage(true));
    }
    if (infoArbitrageContrat.qadStatus === 'OBLIGATOIRE') {
      this.store.dispatch(new PushContratSelected({info: infoArbitrageContrat, setSubtitle: true}));
      this.infoQadAutoLaunch$ = this.arbitrageQadService.infoQadAutoLaunch$();

    } else {
      this.infoQadAutoLaunch$ = null;
      this.store.dispatch(new PushContratSelected({info: infoArbitrageContrat, setSubtitle: true}));
      this.router.navigate(['../etape/choix-arbitrage'], {relativeTo: this.activeRoute, queryParamsHandling: 'preserve'});
    }
  }

  handleCloseQad() {
    this.infoQadAutoLaunch$ = null;
  }

  handleChoixPropositionMdp(choix: ChoixQadMdp) {
    if (!choix.arbitragePerso) {
      this.router.navigate(['../confirmation-proposition'], {relativeTo: this.activeRoute});
    } else {
      this.router.navigate(['../etape/choix-arbitrage'], {relativeTo: this.activeRoute});
    }
  }
}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { SetParcoursManuscritArbitrage, SetSubtitleArbitrage } from '@app/actions/arbitrage.action';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { ActivatedRoute, Router } from '@angular/router';
import { StartIdentiteNumAction } from '@ag2rlamondiale/transverse-metier-ng';
import { IdentiteNumIntegrationComponent } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-arbitrage-identite-num',
  templateUrl: './arbitrage-identite-num.component.html',
  styleUrls: ['./arbitrage-identite-num.component.scss']
})
export class ArbitrageIdentiteNumComponent implements OnInit, OnDestroy {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly jahiaService: JahiaService,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.jahiaService.prefetchPathsDomaines('common', 'identiteNum', 'prevalidation');
    this.store.dispatch(new StartIdentiteNumAction({urlRetourOk: '/modification-gestion-financiere/ma-demande'}));
    this.store.dispatch(new SetSubtitleArbitrage({
      id: 'cancelLink',
      url: '/modification-gestion-financiere/ma-demande'
    }));
  }

  setCurrentComponent(componentReference: IdentiteNumIntegrationComponent) {
    componentReference.setOnParcoursManuscrit(() => {
        this.store.dispatch(new SetParcoursManuscritArbitrage(true));
        this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute});
      }
    );
  }

  ngOnDestroy(): void {
    this.store.dispatch(new SetSubtitleArbitrage(null));
  }
}

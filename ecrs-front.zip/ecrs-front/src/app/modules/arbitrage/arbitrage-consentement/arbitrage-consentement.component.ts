import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {ConsentementId, ConsentementsJahia, ConsentementsMdp, EngagementsEre} from '@app/models/client/arbitrage.model';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface ConsentementEvent {
  consentementId: keyof ConsentementsMdp | keyof EngagementsEre;
  accepted: boolean;
  enabled: boolean; // indique si le consentement est utile pour l'arbitrage en cours.
}

@Component({
  selector: 'app-arbitrage-consentement',
  templateUrl: './arbitrage-consentement.component.html',
  styleUrls: ['./arbitrage-consentement.component.scss']
})
/**
 * Gère les règles de gestion d'affichage du consentementId.
 * Emmet un even si le consentement est ignoré (cad pas affiché dans le contexte) ou bien accepté par le client.
 */
export class ArbitrageConsentementComponent implements OnInit {

  @Input() consentementId: ConsentementId;
  @Input() variante: 'Formulaire' | 'Document';
  @Output() onChange = new EventEmitter<ConsentementEvent>();

  jahiaEntries = ConsentementsJahia;
  showConsentementLecture$: Observable<boolean>;

  constructor(
    private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    if (this.variante === 'Document') {
      this.showConsentementLecture$ = selectArbitrage(this.store).pipe(
        map(x => x.arbitrage.consentementsMdp && x.arbitrage.consentementsMdp[this.consentementId])
      );
    }
  }


  handleCheck(checked: boolean) {
    this.onChange.emit({consentementId: this.consentementId, accepted: checked, enabled: true});
  }

}

import { FileUploadModel, FileUploadResponseModel, IdentiteNum } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { DonneePersonnelJustificatif } from '@app/models/client/donnee-personnelle.model';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-donnee-personnelle-justificatif',
  templateUrl: './donnee-personnelle-justificatif.component.html',
  styleUrls: ['./donnee-personnelle-justificatif.component.scss']
})
export class DonneePersonnelleJustificatifComponent implements OnInit {
  @Output() onUpload = new EventEmitter<DonneePersonnelJustificatif>();




  identiteNum: IdentiteNum = new IdentiteNum();
  pieceJointes: FileUploadModel[];

  confirmationOptions: SelectItem[];

  choixSelected = '';

  constructor() {
    this.confirmationOptions = [];

    this.confirmationOptions.push({label: 'Carte d\'identité', value: 'C'});
    this.confirmationOptions.push({label: 'Passeport', value: 'P'});
    this.confirmationOptions.push({label: 'Titre de séjour', value: 'T'});
  }

  ngOnInit() {
    this.identiteNum.pieceJointes = [];
  }

  updateUploadedFiles1(value: FileUploadResponseModel) {
    if (value) {
      this.changePiecesJointes(pj => pj[0] = value);
      if ((this.identiteNum.typeDoc === 'PASSEPORT' && this.validePieces(1)) ||
        (this.identiteNum.typeDoc !== 'PASSEPORT' && this.validePieces(2))) {
        this.onUpload.emit({
          isCompleted: true,
          piecesIdendite: this.identiteNum.pieceJointes,
          typePj: this.identiteNum.typeDoc
        })
      }
    }
  }

  updateUploadedFiles2(value: FileUploadResponseModel) {
    if (value) {
      this.changePiecesJointes(pj => pj[1] = value);
      if (this.identiteNum.typeDoc !== 'PASSEPORT' && this.validePieces(2)) {
        this.onUpload.emit({
          isCompleted: true,
          piecesIdendite: this.identiteNum.pieceJointes,
          typePj: this.identiteNum.typeDoc
        })
      }
    }
  }

  private validePieces(nombre: number) {
    return this.identiteNum.pieceJointes.length === nombre && this.identiteNum.pieceJointes.findIndex(e => !e) === -1;
  }

  changePiecesJointes(operation: (pieceJointes: FileUploadModel[]) => any) {
    const pj = [...this.identiteNum.pieceJointes];
    operation(pj);
    this.identiteNum = Object.assign(new IdentiteNum(), this.identiteNum, {pieceJointes: pj});
  }


  deleteFile1(event: FileUploadResponseModel) {
    this.changePiecesJointes(pj => pj[0] = null);
    this.onUpload.emit({
      isCompleted: false,
      piecesIdendite: this.identiteNum.pieceJointes,
      typePj: this.identiteNum.typeDoc
    })
  }



  deleteFile2(event: FileUploadResponseModel) {
    this.changePiecesJointes(pj => pj[1] = null);
    this.onUpload.emit({
      isCompleted: false,
      piecesIdendite: this.identiteNum.pieceJointes,
      typePj: this.identiteNum.typeDoc
    })
  }

  resetChoix() {
    this.onUpload.emit({
      isCompleted: false,
      piecesIdendite: this.identiteNum.pieceJointes,
      typePj: this.identiteNum.typeDoc
    })
    switch (this.choixSelected) {
      case 'C':
        this.identiteNum.typeDoc = 'CIN';
        break;
      case 'P':
        this.identiteNum.typeDoc = 'PASSEPORT';
        break;
      case 'T':
        this.identiteNum.typeDoc = 'CIN';
        break;
    }
    this.identiteNum.pieceJointes = [];
  }
}

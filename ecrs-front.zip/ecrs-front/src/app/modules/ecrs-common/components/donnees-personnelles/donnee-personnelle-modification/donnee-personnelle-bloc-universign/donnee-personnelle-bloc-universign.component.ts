import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-donnee-personnelle-bloc-universign',
  templateUrl: './donnee-personnelle-bloc-universign.component.html',
  styleUrls: ['./donnee-personnelle-bloc-universign.component.scss']
})
export class DonneePersonnelleBlocUniversignComponent implements OnInit, OnChanges {
  @Input() blocDisplay: boolean;
  @Input() waitingOCR: boolean;
  @Output() isCtaDisabled = new EventEmitter<boolean>();
  @Output() universignChoixToEmit = new EventEmitter<boolean>();

  universignChoix = '';
  choixUniversign: SelectItem[];

  constructor() {
    this.choixUniversign = [
      {label: 'Oui', value: true},
      {label: 'Non', value: false}
    ];
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.blocDisplay) {
      this.universignChoix = '';
    }
  }

  onChangeUniversignChoix(value: boolean) {
    this.universignChoixToEmit.emit(value);
    this.isCtaDisabled.emit(false);
  }
}

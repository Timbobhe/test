import { ContentFromExternalHtmlComponent } from '@app/modules/ecrs-common/components/content-from-external-html/content-from-external-html.component';
import { waitForAsync, TestBed } from '@angular/core/testing';
import { Store, StoreModule } from '@ngrx/store';
import * as fromRoot from '@app/reducers/_index';
import { GlobalState } from '@app/reducers/_index';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('ContentFromExternalHtmlComponent', () => {
  let component: ContentFromExternalHtmlComponent;
  let store: Store<GlobalState>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(fromRoot.reducers, {
          initialState: {}
        })
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    store = TestBed.inject(Store);
    component = new ContentFromExternalHtmlComponent(store);
  });

  it('should create an instance', () => {
    expect(component).toBeTruthy();
  });

});

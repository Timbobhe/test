import { ThemeService } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {

  @Input() data: any;
  @Input() options: any;
  @Input() selectedBarIndex: number = 0;

  @Output() onBarSelected: EventEmitter<number> = new EventEmitter();

  constructor(public themeService: ThemeService) { }

  ngOnInit() {
    console.log(this.data);
  }

  onSelectBar(index: number) {
    this.onBarSelected.emit(index);
  }
}

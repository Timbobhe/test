import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoixContratComponent } from './choix-contrat.component';
import { testingModule } from '../../../../../test/ecrs-testing';

describe('ChoixContratComponent', () => {
  let component: ChoixContratComponent;
  let fixture: ComponentFixture<ChoixContratComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [ChoixContratComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoixContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

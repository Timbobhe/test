/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { CardWithPictoContribComponent } from './card-with-picto-contrib.component';


describe('CardWithPictoContribComponent', () => {
  let component: CardWithPictoContribComponent;
  let fixture: ComponentFixture<CardWithPictoContribComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterModule.forRoot([]), StoreModule.forRoot(fromRoot.reducers)],
      declarations: [ CardWithPictoContribComponent ],
      providers: [CardWithPictoContribComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardWithPictoContribComponent);
    component = fixture.componentInstance;
    component.color = 'pink';
    component.icon = 'ag2r-icon';
    component.jahiaContribId = 'CONTENU_VERIFIER_DEMANDE';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

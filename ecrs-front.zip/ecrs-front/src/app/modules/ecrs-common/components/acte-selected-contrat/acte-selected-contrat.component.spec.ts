import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActeSelectedContratComponent } from './acte-selected-contrat.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { of } from 'rxjs';
import { CompartimentType } from '@app/models/client/contrat.model';
import { AffichageType } from '@ag2rlamondiale/transverse-metier-ng';

const affichageType: AffichageType = 'NORMAL';

describe('ActeSelectedContratComponent', () => {
  let component: ActeSelectedContratComponent;
  let fixture: ComponentFixture<ActeSelectedContratComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ActeSelectedContratComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActeSelectedContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not have modifier link', () => {
    const c3: CompartimentType = 'C3';
    component.info$ = of({
      contrats: [{
        'nomContrat': 'RG151236289',
        'college': 'Ingénieurs, cadres et assimilés cadres',
        'identifiantAssure': '541845',
        'description': 'Plan d\'Epargne Retraite Entreprises',
        'raisonSociale': 'COMPAGNIE IBM FRANCE',
        'codeSilo': 'ERE',
        'idAdherente': '',
        'idContractante': 'S4164948',
        'compartimentType': c3,
        affichageType
      }], contratSelected: {
        'nomContrat': 'RG151236289',
        'college': 'Ingénieurs, cadres et assimilés cadres',
        'identifiantAssure': '541845',
        'description': 'Plan d\'Epargne Retraite Entreprises',
        'raisonSociale': 'COMPAGNIE IBM FRANCE',
        'codeSilo': 'ERE',
        'idAdherente': '',
        'idContractante': 'S4164948',
        'compartimentType': c3,
        affichageType
      }
    });
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.getElementsByClassName('link').length).toBe(0);
  });

  it('should have modifier link', () => {
    const c3: CompartimentType = 'C3';
    component.info$ = of({
      contrats: [{
        'nomContrat': 'RG151236289',
        'college': 'Ingénieurs, cadres et assimilés cadres',
        'identifiantAssure': '541845',
        'description': 'Plan d\'Epargne Retraite Entreprises',
        'raisonSociale': 'COMPAGNIE IBM FRANCE',
        'codeSilo': 'ERE',
        'idAdherente': '',
        'idContractante': 'S4164948',
        'compartimentType': c3,
        affichageType
      }, {
        'nomContrat': 'RG151236289',
        'college': 'Ingénieurs, cadres et assimilés cadres',
        'identifiantAssure': '541845',
        'description': 'Plan d\'Epargne Retraite Entreprises',
        'raisonSociale': 'COMPAGNIE IBM FRANCE',
        'codeSilo': 'ERE',
        'idAdherente': '',
        'idContractante': 'S4164948',
        'compartimentType': c3,
        affichageType
      }], contratSelected: {
        'nomContrat': 'RG151236289',
        'college': 'Ingénieurs, cadres et assimilés cadres',
        'identifiantAssure': '541845',
        'description': 'Plan d\'Epargne Retraite Entreprises',
        'raisonSociale': 'COMPAGNIE IBM FRANCE',
        'codeSilo': 'ERE',
        'idAdherente': '',
        'idContractante': 'S4164948',
        'compartimentType': c3,
        affichageType
      }
    });
    fixture.detectChanges();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.getElementsByClassName('link').length).toBe(1);
  });
});

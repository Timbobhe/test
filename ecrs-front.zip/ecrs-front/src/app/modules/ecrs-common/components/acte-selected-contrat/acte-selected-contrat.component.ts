import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-acte-selected-contrat',
  templateUrl: './acte-selected-contrat.component.html',
  styleUrls: ['./acte-selected-contrat.component.scss']
})
export class ActeSelectedContratComponent implements OnInit {
  @Input() info$: Observable<{ contrats: MiniContrat[], contratSelected: MiniContrat }>;
  @Input() afficherEncours = false;
  @Output() goToChoixContratStep: EventEmitter<any> = new EventEmitter<any>();
  @Input() title = 'Pour le contrat';

  constructor() { }

  ngOnInit() { }

  goToChoixContrat() {
    this.goToChoixContratStep.emit();
  }
}

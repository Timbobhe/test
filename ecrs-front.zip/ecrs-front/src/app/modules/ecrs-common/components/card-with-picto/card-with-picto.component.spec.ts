import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { initialStateWithHttpError } from '@app/../test/store-states.mock';
import * as fromRoot from '@app/reducers/_index';
import { CardWithPictoComponent } from './card-with-picto.component';
import { StoreModule } from '@ngrx/store';

describe('CardWithPictoComponent', () => {
  let component: CardWithPictoComponent;
  let fixture: ComponentFixture<CardWithPictoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(fromRoot.reducers, initialStateWithHttpError)],
      declarations: [ CardWithPictoComponent ],
      providers: [CardWithPictoComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardWithPictoComponent);
    component = fixture.componentInstance;
    component.color = '#FFFFFF';
    component.icon = 'ag2r-icon';
    component.sujet = { idSujet: 1, titre: 'Comprendre', typeSujet: 'COMPRENDRE', sousSujets: [] };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

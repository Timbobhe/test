import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Sujet } from '@app/models/client/sujets.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-card-with-picto',
  templateUrl: './card-with-picto.component.html',
  styleUrls: ['./card-with-picto.component.scss']
})
export class CardWithPictoComponent implements OnInit {
  @Input() sujet: Sujet;
  @Input() color: string;
  @Input() textColor: string;
  @Input() icon: string;
  @Input() urlIcon:string;
  @Input() iconInChart:boolean = true;
  @Output() isCardSelected: EventEmitter<any> = new EventEmitter();
  subscriptions: Subscription[] = [];
  cardSujetsSelectionnes: number[] = [];
  selected = false;
  index: number;

  constructor(private readonly store: Store<GlobalState>) { }

  ngOnInit() {
    this.subscriptions.push(this.store.select('ui').subscribe(ui => {
      this.cardSujetsSelectionnes = ui.cardSujetsSelectionnes;
      this.index = this.cardSujetsSelectionnes.indexOf(this.sujet.idSujet);
      this.preselect(this.index);
      this.iconInChart == false ? this.urlIcon : this.icon;
    }));
  }

  preselect(index: number) {
    if (index !== -1) {
      this.selected = true;
    }
  }

  selectCard(event) {
    this.selected = this.selected === false;
    this.isCardSelected.emit();
  }
}

import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ClearSubjectObjectif, PushSelectedSubjectObjectif } from '@app/actions/objectif-synthese.action';
import {
  ClearCardsSujets,
  CreateSujetParUtilisateur,
  GetObjectifsParUtilisateur,
  GetSujets,
  PushCardSujetSelected
} from '@app/actions/sujets.actions';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import { ResetTour } from '@app/actions/ui.actions';
import { Evenement } from '@app/models/client/evenement.model';
import { LectureSujet, Sujet } from '@app/models/client/sujets.model';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { ThemeService } from '@ag2rlamondiale/transverse-metier-ng';
import { filter, switchMap } from 'rxjs/operators';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';


const lienSyntheseDesComptes = '/synthese-des-comptes';

@Component({
  selector: 'app-objectif-modification',
  templateUrl: './objectif-modification.component.html',
  styleUrls: ['./objectif-modification.component.scss']
})
export class ObjectifModificationComponent implements OnInit, OnDestroy {
  @Output() goToSynthesePage: EventEmitter<any> = new EventEmitter();
  sujetsSelectionnes: number[] = [];
  subscriptions: Subscription[] = [];
  lectureSujets: LectureSujet[] = [];
  cardSujetsSelectionnes: number[] = [];

  sujets: Sujet[] = [];
  evenement: Evenement;

  impersonation: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    readonly themeService: ThemeService,
    private readonly reduxApi: ReduxApiService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select('sujets').pipe(
        filter(s => s.isFetched === false),
        switchMap(s => this.reduxApi.execute(new GetSujets()))
      ).subscribe(),

      this.store.select('sujets').pipe(
        filter(s => s.isFetched),
      ).subscribe(s => {
        this.sujets = s.data;
      }),

      this.store.select('lectureSujets').pipe(
        filter(s => s.isFetched === false),
        switchMap(s => this.reduxApi.execute(new GetObjectifsParUtilisateur()))
      ).subscribe(),

      this.store.select('lectureSujets').pipe(
        filter(s => s.isFetched),
      ).subscribe(s => {
        this.lectureSujets = s.data;
        this.objectifPreSelected();
      })
    );


    this.subscriptions.push(this.store.select('objectifSynthese').subscribe(sujet => {
      this.sujetsSelectionnes = sujet.userData.sujetsSelectionnes;
    }));

    this.subscriptions.push(this.store.select('ui').subscribe(ui => {
      this.cardSujetsSelectionnes = ui.cardSujetsSelectionnes;
    }));

    this.subscriptions.push(
      this.store.select('clientInfos').subscribe(info => {
        this.impersonation = info.impersonation;
      })
    );
  }

  objectifPreSelected() {
    const idList: number[] = [];
    for (const lectureSujet of this.lectureSujets) {
      idList.push(lectureSujet.idSujet);
      this.store.dispatch(new PushCardSujetSelected(lectureSujet.idSujet));
      for (const sousLectureSujet of lectureSujet.sousSujets) {
        idList.push(sousLectureSujet.idSujet);
      }
    }
    this.store.dispatch(new PushSelectedSubjectObjectif(idList));
  }

  addToSubjectSelected(sujet: Sujet) {
    const index = this.sujetsSelectionnes.indexOf(sujet.idSujet);
    let idList: number[] = [];
    idList.push(sujet.idSujet);
    idList = idList.concat(sujet.sousSujets);

    if (index === -1) {
      this.store.dispatch(new PushSelectedSubjectObjectif(idList));
    } else {
      this.store.dispatch(new ClearSubjectObjectif(idList));
    }
  }

  validate(): void {
    if (!this.impersonation) {
      this.store.dispatch(tracking(Categorie.modificationObjectif, TypeOriginAction.objectifValidation));
      const sujet = new CreateSujetParUtilisateur({idSujets: this.sujetsSelectionnes});
      this.store.dispatch(sujet);
      this.store.dispatch(new ClearSubjectObjectif(this.sujetsSelectionnes));
      this.store.dispatch(new ClearCardsSujets(this.cardSujetsSelectionnes));
      this.store.dispatch(new ResetTour());
      this.router.navigate([lienSyntheseDesComptes]);
    } else {
      this.router.navigate([lienSyntheseDesComptes]);
    }
  }

  goToSynthese() {
    if (!this.impersonation) {
      this.store.dispatch(new ClearSubjectObjectif(this.sujetsSelectionnes));
      const sujet = new CreateSujetParUtilisateur({idSujets: []});
      this.store.dispatch(sujet);
      this.store.dispatch(new ClearCardsSujets(this.cardSujetsSelectionnes));
      this.router.navigate([lienSyntheseDesComptes]);
    } else {
      this.router.navigate([lienSyntheseDesComptes]);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}

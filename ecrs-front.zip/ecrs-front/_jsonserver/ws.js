var express = require('express');
var router = express.Router();

const ROOT_DIRNAME = `${__dirname}/data-ws`;
const HEADERS = { 'Content-Type': 'text/xml' };

const JDD = 'P4737509';

const services = [
  { path: 'GestInfoFin_1/ConsulterStructInv_3', response: 'same' },
  { path: 'GestPersPhys_2/RechercherPPReduit_3', response: 'same', jdd: JDD },
  { path: 'GestPersPhys_3/ConsulterPersPhysClient_3', response: 'same', jdd: JDD },
  { path: 'GestPersPhys_3/ModifierPPSilo_1', response: 'same' },
];

router.get('/', function (req, res) {
  let liste = services.sort((a, b) => a.path.localeCompare(b.path)).map(s => `<li><a href='service/${s.path}'>${s.path}</a></li>`);
  let html = `
    <!doctype html>
    <html>
      <head><title>WS PFS</title></head>
      <body>
        <h1>WS PFS</h1>
        <div>
          <ul>
            ${liste.join('')}
          </ul>
        </div>
      </body>
    </html>
  `;
  res.send(html);
});

services.forEach(srv => {
  let fileResponse = srv.response === 'same' ? `${srv.path}.xml` : srv.response;
  if (srv.response === 'same' && srv.jdd) {
    fileResponse = `${srv.path}.${srv.jdd}.xml`;
  } else if (srv.response === 'same') {
    fileResponse = `${srv.path}.xml`;
  } else {
    fileResponse = srv.response;
  }

  router.post(`/${srv.path}`, function (req, res) {
    const file = fileResponse;
    res.sendFile(file, { root: ROOT_DIRNAME, headers: HEADERS });
  });

  router.get(`/${srv.path}`, function (req, res) {
    const file = fileResponse;
    res.sendFile(file, { root: ROOT_DIRNAME, headers: HEADERS });
  });
});

module.exports = router;
